import {build} from 'vite';
import {readFile,readdir,mkdir,writeFile,rm} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {products,franchises,categories} from '../src/data.js';
import {validateCatalog} from '../src/catalog.js';

const root=fileURLToPath(new URL('../',import.meta.url));
validateCatalog(products);
if(products.length!==42||franchises.length!==14||products.some(p=>p.retailer!=='Hot Topic'||p.image||p.productPhoto||p.price))throw Error('Unexpected application catalog');
const art={};
for(const name of await readdir(path.join(root,'public/assets'))){
 if(!name.endsWith('.svg'))throw Error('Only authored SVG artwork belongs in this edition');
 const source=await readFile(path.join(root,'public/assets',name),'utf8');
 if(/<image\b|<script\b|<foreignObject\b|https?:\/\/(?!www\.w3\.org)/i.test(source))throw Error('Unexpected image or external reference');
 art[path.basename(name,'.svg')]=`data:image/svg+xml;base64,${Buffer.from(source).toString('base64')}`;
}
const result=await build({root,configFile:false,publicDir:false,build:{write:false,minify:true,modulePreload:false,rollupOptions:{input:path.join(root,'src/site-entry.js'),output:{inlineDynamicImports:true,entryFileNames:'site.js'}}}});
const chunks=result.output.filter(item=>item.type==='chunk');if(chunks.length!==1)throw Error('Single-file build expected');
const css=result.output.filter(item=>item.type==='asset'&&item.fileName.endsWith('.css')).map(item=>item.source).join('\n');
let html=await readFile(path.join(root,'index.html'),'utf8');
html=html.replace('href="/assets/mark.svg"',`href="${art.mark}"`).replace('</head>',()=>`<style>${css.replace(/<\/style/gi,'<\\/style')}</style><script>window.NEXORI_ART=${JSON.stringify(art).replace(/</g,'\\u003c')};</script></head>`).replace('<script type="module" src="/src/site-entry.js"></script>',()=>`<script type="module">${chunks[0].code.replace(/<\/script/gi,'<\\/script')}</script>`);
if(/firestore|firebaseapp|nexori-development|AIza|catalog-.*\.(?:jpg|webp)|data:image\/(?:png|jpeg|webp)|Authentic Anime|permissions are pending/.test(html))throw Error('Old cloud or retailer-image content entered the public build');
await rm(path.join(root,'dist'),{recursive:true,force:true});await mkdir(path.join(root,'dist'),{recursive:true});
await writeFile(path.join(root,'dist/index.html'),html);
await writeFile(path.join(root,'dist/NEXORI-application.html'),html);
console.log(JSON.stringify({htmlBytes:Buffer.byteLength(html),products:products.length,anime:franchises.length,categories:categories.length,originalSvgAssets:Object.keys(art).length,firebase:false,retailerImages:false}));

export const categories = [
  {
    "id": "figures",
    "label": "Figures & collectibles",
    "short": "Figures",
    "description": "Display figures, poseable figures and model kits.",
    "icon": "cube",
    "color": "violet",
    "types": [
      {
        "id": "display-figures",
        "name": "Display figures",
        "examples": "Prize figures, scale figures, statues and display busts"
      }
    ]
  },
  {
    "id": "style",
    "label": "Apparel & style",
    "short": "Apparel",
    "description": "T-shirts, hoodies, jackets, hats and lounge bottoms.",
    "icon": "shirt",
    "color": "pink",
    "types": [
      {
        "id": "t-shirts",
        "name": "T-shirts",
        "examples": "Everyday shirts with a clear size chart"
      },
      {
        "id": "hoodies",
        "name": "Hoodies",
        "examples": "Hoodies and sweatshirts with fabric and fit details"
      },
      {
        "id": "hats",
        "name": "Hats",
        "examples": "Caps and beanies"
      }
    ]
  },
  {
    "id": "desk",
    "label": "Desk & room",
    "short": "Desk & room",
    "description": "Desk mats, art prints and room decor.",
    "icon": "monitor",
    "color": "cyan",
    "types": [
      {
        "id": "desk-mats",
        "name": "Desk mats",
        "examples": "Mouse pads and extended desk mats"
      },
      {
        "id": "room-decor",
        "name": "Room decor",
        "examples": "Decorative lights, cushions and other room accents"
      }
    ]
  },
  {
    "id": "accessories",
    "label": "Accessories & small finds",
    "short": "Accessories",
    "description": "Keychains, bags, pins, jewellery and belts.",
    "icon": "spark",
    "color": "violet",
    "types": [
      {
        "id": "keychains",
        "name": "Keychains",
        "examples": "Keychains and bag charms"
      },
      {
        "id": "pins",
        "name": "Pins & badges",
        "examples": "Small collectible pins and badges"
      },
      {
        "id": "jewellery",
        "name": "Jewellery",
        "examples": "Necklaces, bracelets and other wearable accessories"
      },
      {
        "id": "belts",
        "name": "Belts",
        "examples": "Everyday belts with clear length, buckle and fit details"
      }
    ]
  }
];

export const franchises = [
  {
    "id": "one-piece",
    "name": "One Piece",
    "subtitle": "For the adventure",
    "symbol": "☸︎",
    "color": "#edb37e"
  },
  {
    "id": "naruto",
    "name": "Naruto",
    "subtitle": "Follow your own path",
    "symbol": "◉",
    "color": "#eab369"
  },
  {
    "id": "demon-slayer",
    "name": "Demon Slayer",
    "subtitle": "A cut above",
    "symbol": "✳",
    "color": "#72cbb9"
  },
  {
    "id": "jujutsu-kaisen",
    "name": "Jujutsu Kaisen",
    "subtitle": "Embrace the energy",
    "symbol": "✺",
    "color": "#bda0f2"
  },
  {
    "id": "dragon-ball",
    "name": "Dragon Ball",
    "subtitle": "Beyond your limits",
    "symbol": "★",
    "color": "#e99278"
  },
  {
    "id": "attack-on-titan",
    "name": "Attack on Titan",
    "subtitle": "Beyond the walls",
    "symbol": "◈",
    "color": "#9faed1"
  },
  {
    "id": "my-hero-academia",
    "name": "My Hero Academia",
    "subtitle": "Go beyond your limits",
    "symbol": "✧",
    "color": "#66ad89"
  },
  {
    "id": "bleach",
    "name": "Bleach",
    "subtitle": "Awaken your inner power",
    "symbol": "✴",
    "color": "#e5a073"
  },
  {
    "id": "chainsaw-man",
    "name": "Chainsaw Man",
    "subtitle": "Live a little louder",
    "symbol": "✣",
    "color": "#dc8e77"
  },
  {
    "id": "blue-lock",
    "name": "Blue Lock",
    "subtitle": "Find your winning instinct",
    "symbol": "◇",
    "color": "#7aa9e5"
  },
  {
    "id": "solo-leveling",
    "name": "Solo Leveling",
    "subtitle": "Arise to the next level",
    "symbol": "✶",
    "color": "#a993e5"
  },
  {
    "id": "pokemon",
    "name": "Pokémon",
    "subtitle": "Your next adventure awaits",
    "symbol": "ϟ",
    "color": "#d6a73e"
  },
  {
    "id": "hunter-x-hunter",
    "name": "Hunter × Hunter",
    "subtitle": "Follow your own adventure",
    "symbol": "⌖",
    "color": "#78b388"
  },
  {
    "id": "death-note",
    "name": "Death Note",
    "subtitle": "A darker kind of story",
    "symbol": "☾",
    "color": "#a0a0c2"
  }
];

export const guides = [
  {
    "id": "first-figure",
    "title": "Your first anime figure. A little less guesswork.",
    "eyebrow": "THE COLLECTOR’S GUIDE",
    "description": "Prize, scale, or articulated? Find the right starting point for your shelf and your budget.",
    "time": "4 min read",
    "art": "journal-collect",
    "color": "#aa80e0",
    "sections": [
      [
        "Start with a character you love",
        "A collection does not need to begin with a rare or expensive piece. Choose a character or design you will enjoy seeing every day, then decide how much space and money you want to dedicate to it."
      ],
      [
        "Understand the different formats",
        "Prize figures are often a more accessible entry point, although quality varies. Scale figures usually focus on sculpt and finish, while articulated figures trade a seamless silhouette for poses. Model kits add the experience of building the collectible yourself."
      ],
      [
        "Check dimensions, not just the photo",
        "A close-up photograph can make a small figure look enormous. Compare the listed height with your shelf, and allow room for the base, accessories, and any extended weapons or clothing."
      ],
      [
        "Buy from a seller you can verify",
        "Look for a named manufacturer, a clear product code, licensing information, and an understandable returns policy. Prices far below comparable listings deserve extra research. Images alone do not establish authenticity."
      ],
      [
        "Consider the complete cost",
        "Shipping, taxes, customs, and currency conversion can change the total. For a preorder, read the cancellation policy and expected release window before paying."
      ]
    ]
  },
  {
    "id": "anime-space",
    "title": "A better anime setup, one detail at a time.",
    "eyebrow": "ROOM & DESK",
    "description": "Build a space that feels personal without filling every surface.",
    "time": "3 min read",
    "art": "journal-space",
    "color": "#6eafb7",
    "sections": [
      [
        "Choose one focal point",
        "Start with one display figure, art print, or desk mat that sets the mood. A few deliberate choices often work better than many competing decorations."
      ],
      [
        "Keep your setup useful",
        "Measure the area where your keyboard, mouse, and monitor sit. Make sure collectibles do not obstruct ventilation, speakers, or the space you need to work."
      ],
      [
        "Use light sparingly",
        "A soft light behind a monitor or shelf can help highlight a display. Keep bright lights away from your eyes and avoid lighting that causes glare on your screen."
      ],
      [
        "Leave room to grow",
        "A little empty shelf space makes individual pieces easier to appreciate. Protect prints and figures from direct sunlight, dust, and heat, and follow the manufacturer’s cleaning advice."
      ]
    ]
  },
  {
    "id": "buying-safely",
    "title": "Before you click buy: the collector’s checklist.",
    "eyebrow": "BUY SMARTER",
    "description": "A practical check for sellers, shipping, and listings that look too good to be true.",
    "time": "3 min read",
    "art": "journal-check",
    "color": "#9a9fdb",
    "sections": [
      [
        "Identify the seller",
        "A familiar marketplace name is not the same as a verified third-party seller. Check who sells and ships the product, their recent feedback, and how the platform handles disputes."
      ],
      [
        "Compare the listing details",
        "Match the manufacturer, item code, dimensions, and materials with official product information when available. Ask for clarification when a listing uses vague language or inconsistent photos."
      ],
      [
        "Read the shipping and returns terms",
        "Confirm delivery to your country, estimated costs, and whether import charges are included. Read the conditions for damaged items, returns, cancellations, and preorders."
      ],
      [
        "Recognize uncertainty",
        "An affiliate recommendation is a discovery aid, not a guarantee of quality or availability. Check the current listing at the retailer and keep a copy of your order details."
      ]
    ]
  }
];

export const products = [
  {
    "id": "midnight-ronin",
    "worldId": "one-piece",
    "category": "figures",
    "typeId": "display-figures",
    "status": "retailer-preview",
    "name": "Luffy Gear 5 — King of Artist",
    "series": "One Piece",
    "type": "Display figure",
    "color": "#a582e6",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/banpresto-one-piece-king-of-artist-monkey-d.-luffy-gear-5-special-ver.-ii-figure/36073801.html",
    "description": "A collectible figure listing for fans who want a focal point for a shelf or display. Compare its dimensions, materials, and included accessories on the retailer’s page before choosing a spot.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "off-duty-hoodie",
    "worldId": "one-piece",
    "category": "style",
    "typeId": "t-shirts",
    "status": "retailer-preview",
    "name": "Luffy Wanted Poster T-Shirt",
    "series": "One Piece",
    "type": "Cotton T-shirt",
    "color": "#dc89b1",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/one-piece-luffy-wanted-poster-grey-dark-wash-t-shirt/36649561.html",
    "description": "An anime apparel listing for bringing a favorite story into an everyday outfit. Read the retailer’s current size chart, fabric details, and care instructions before choosing a size.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "after-hours-desk",
    "worldId": "one-piece",
    "category": "desk",
    "typeId": "desk-mats",
    "status": "retailer-preview",
    "name": "One Piece Memories Desk Mat",
    "series": "One Piece",
    "type": "Extended desk mat",
    "color": "#73c9d2",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/abystyle-one-piece-memories-game-mat/35130452.html",
    "description": "A home or desk listing for adding a small detail to your personal space. Check the item’s exact dimensions, materials, and intended use on the retailer’s page.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "naruto-rasenshuriken",
    "worldId": "naruto",
    "category": "figures",
    "typeId": "display-figures",
    "status": "retailer-preview",
    "name": "Naruto Rasenshuriken Figure",
    "series": "Naruto",
    "type": "Display figure",
    "color": "#a582e6",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/naruto-shippuden-naruto-uzumaki-rasenshuriken-figure/36368225.html",
    "description": "A collectible figure listing for fans who want a focal point for a shelf or display. Compare its dimensions, materials, and included accessories on the retailer’s page before choosing a spot.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "naruto-kakashi-shirt",
    "worldId": "naruto",
    "category": "style",
    "typeId": "t-shirts",
    "status": "retailer-preview",
    "name": "Kakashi Lightning T-Shirt",
    "series": "Naruto",
    "type": "Cotton T-shirt",
    "color": "#a582e6",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/naruto-shippuden-kakashi-lightning-gothic-t-shirt/36796390.html",
    "description": "An anime apparel listing for bringing a favorite story into an everyday outfit. Read the retailer’s current size chart, fabric details, and care instructions before choosing a size.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "ht-35541847",
    "worldId": "naruto",
    "category": "accessories",
    "typeId": "pins",
    "status": "retailer-preview",
    "name": "Naruto Uzumaki Enamel Pin",
    "series": "Naruto",
    "type": "Pin / patch",
    "color": "#b794e8",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/naruto-uzumaki-enamel-pin/35541847.html",
    "description": "An anime accessory listing for a small everyday detail or a gift. Check the size, attachment, materials, and included pieces on the retailer’s page before ordering.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "demon-tanjiro-figure",
    "worldId": "demon-slayer",
    "category": "figures",
    "typeId": "display-figures",
    "status": "retailer-preview",
    "name": "Tanjiro Kamado Xross Link Figure",
    "series": "Demon Slayer",
    "type": "Display figure",
    "color": "#a582e6",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/sega-demon-slayer-kimetsu-no-yaiba-tanjiro-kamado-xross-link-figure/35583251.html",
    "description": "A collectible figure listing for fans who want a focal point for a shelf or display. Compare its dimensions, materials, and included accessories on the retailer’s page before choosing a spot.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "demon-hashira-shirt",
    "worldId": "demon-slayer",
    "category": "style",
    "typeId": "t-shirts",
    "status": "retailer-preview",
    "name": "Hashira Dark Wash T-Shirt",
    "series": "Demon Slayer",
    "type": "Cotton T-shirt",
    "color": "#a582e6",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/demon-slayer-kimetsu-no-yaiba-hashira-dark-wash-t-shirt/33178672.html",
    "description": "An anime apparel listing for bringing a favorite story into an everyday outfit. Read the retailer’s current size chart, fabric details, and care instructions before choosing a size.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "demon-kanao-bracelet",
    "worldId": "demon-slayer",
    "category": "accessories",
    "typeId": "jewellery",
    "status": "retailer-preview",
    "name": "Kanao Butterfly Ring Bracelet",
    "series": "Demon Slayer",
    "type": "Jewellery accessory",
    "color": "#a582e6",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/demon-slayer-kimetsu-no-yaiba-kanao-butterfly-hand-ring-bracelet/36164567.html",
    "description": "An anime accessory listing for a small everyday detail or a gift. Check the size, attachment, materials, and included pieces on the retailer’s page before ordering.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "jjk-megumi-figure",
    "worldId": "jujutsu-kaisen",
    "category": "figures",
    "typeId": "display-figures",
    "status": "retailer-preview",
    "name": "Megumi Fushiguro Maximatic Figure",
    "series": "Jujutsu Kaisen",
    "type": "Display figure",
    "color": "#a582e6",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/banpresto-jujutsu-kaisen-maximatic-megumi-fushiguro-the-culling-game-figure/36209857.html",
    "description": "A collectible figure listing for fans who want a focal point for a shelf or display. Compare its dimensions, materials, and included accessories on the retailer’s page before choosing a spot.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "jjk-choso-shirt",
    "worldId": "jujutsu-kaisen",
    "category": "style",
    "typeId": "t-shirts",
    "status": "retailer-preview",
    "name": "Choso Foil Print T-Shirt",
    "series": "Jujutsu Kaisen",
    "type": "Cotton T-shirt",
    "color": "#a582e6",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/jujutsu-kaisen-choso-foil-print-t-shirt/32713505.html",
    "description": "An anime apparel listing for bringing a favorite story into an everyday outfit. Read the retailer’s current size chart, fabric details, and care instructions before choosing a size.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "jjk-gojo-keychain",
    "worldId": "jujutsu-kaisen",
    "category": "accessories",
    "typeId": "keychains",
    "status": "retailer-preview",
    "name": "Gojo Chibi Metal Keychain",
    "series": "Jujutsu Kaisen",
    "type": "Metal keychain",
    "color": "#a582e6",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/jujutsu-kaisen-gojo-chibi-metal-keychain/36275812.html",
    "description": "An anime accessory listing for a small everyday detail or a gift. Check the size, attachment, materials, and included pieces on the retailer’s page before ordering.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "db-piccolo-figure",
    "worldId": "dragon-ball",
    "category": "figures",
    "typeId": "display-figures",
    "status": "retailer-preview",
    "name": "Piccolo Solid Edge Works Figure",
    "series": "Dragon Ball",
    "type": "Display figure",
    "color": "#a582e6",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/dragon-ball-z-solid-edge-works-piccolo-figure/36368240.html",
    "description": "A collectible figure listing for fans who want a focal point for a shelf or display. Compare its dimensions, materials, and included accessories on the retailer’s page before choosing a spot.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "db-goku-shirt",
    "worldId": "dragon-ball",
    "category": "style",
    "typeId": "t-shirts",
    "status": "retailer-preview",
    "name": "Goku Foil Mineral Wash T-Shirt",
    "series": "Dragon Ball",
    "type": "Cotton T-shirt",
    "color": "#a582e6",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/dragon-ball-super-goku-foil-mineral-wash-t-shirt/30752730.html",
    "description": "An anime apparel listing for bringing a favorite story into an everyday outfit. Read the retailer’s current size chart, fabric details, and care instructions before choosing a size.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "ht-36275754",
    "worldId": "dragon-ball",
    "category": "accessories",
    "typeId": "keychains",
    "status": "retailer-preview",
    "name": "Dragon Ball Super Vegeta Keychain",
    "series": "Dragon Ball",
    "type": "Keychain / charm",
    "color": "#b794e8",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/dragon-ball-super-vegeta-keychain/36275754.html",
    "description": "An anime accessory listing for a small everyday detail or a gift. Check the size, attachment, materials, and included pieces on the retailer’s page before ordering.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "aot-eren-figure",
    "worldId": "attack-on-titan",
    "category": "figures",
    "typeId": "display-figures",
    "status": "retailer-preview",
    "name": "Eren Jaeger Attack Titan Funko Pop!",
    "series": "Attack On Titan",
    "type": "Display figure",
    "color": "#a582e6",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/funko-attack-on-titan-pop-animation-eren-jaeger-attack-titan-vinyl-figure/36287401.html",
    "description": "A collectible figure listing for fans who want a focal point for a shelf or display. Compare its dimensions, materials, and included accessories on the retailer’s page before choosing a spot.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "aot-levi-shirt",
    "worldId": "attack-on-titan",
    "category": "style",
    "typeId": "t-shirts",
    "status": "retailer-preview",
    "name": "Levi Tonal Double-Sided T-Shirt",
    "series": "Attack On Titan",
    "type": "Cotton T-shirt",
    "color": "#a582e6",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/attack-on-titan-levi-tonal-double-sided-t-shirt/34833701.html",
    "description": "An anime apparel listing for bringing a favorite story into an everyday outfit. Read the retailer’s current size chart, fabric details, and care instructions before choosing a size.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "ht-31001863",
    "worldId": "attack-on-titan",
    "category": "accessories",
    "typeId": "keychains",
    "status": "retailer-preview",
    "name": "Attack On Titan Scouts Cap and Keychain Set",
    "series": "Attack on Titan",
    "type": "Keychain / charm",
    "color": "#b794e8",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/attack-on-titan-scouts-cap-and-keychain-set/31001863.html",
    "description": "An anime accessory listing for a small everyday detail or a gift. Check the size, attachment, materials, and included pieces on the retailer’s page before ordering.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-36073792",
    "worldId": "my-hero-academia",
    "category": "figures",
    "typeId": "display-figures",
    "status": "retailer-preview",
    "name": "Banpresto My Hero Academia Izuku Midoriya Figure",
    "series": "My Hero Academia",
    "type": "Display figure",
    "color": "#66ad89",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/banpresto-my-hero-academia-izuku-midoriya-figure/36073792.html",
    "description": "A collectible figure listing for fans who want a focal point for a shelf or display. Compare its dimensions, materials, and included accessories on the retailer’s page before choosing a spot.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-34583302",
    "worldId": "my-hero-academia",
    "category": "style",
    "typeId": "hoodies",
    "status": "retailer-preview",
    "name": "My Hero Academia Students Grid Sweatshirt",
    "series": "My Hero Academia",
    "type": "Hoodie / sweatshirt",
    "color": "#66ad89",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/my-hero-academia-students-grid-sweatshirt/34583302.html",
    "description": "An anime apparel listing for bringing a favorite story into an everyday outfit. Read the retailer’s current size chart, fabric details, and care instructions before choosing a size.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-34343659",
    "worldId": "my-hero-academia",
    "category": "accessories",
    "typeId": "belts",
    "status": "retailer-preview",
    "name": "My Hero Academia the Big 3 Action Poses Light Blue Seatbelt Buckle Belt",
    "series": "My Hero Academia",
    "type": "Belt / wearable accessory",
    "color": "#66ad89",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/my-hero-academia-the-big-3-action-poses-light-blue-seatbelt-buckle-belt/34343659.html",
    "description": "An anime accessory listing for a small everyday detail or a gift. Check the size, attachment, materials, and included pieces on the retailer’s page before ordering.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-35533278",
    "worldId": "bleach",
    "category": "figures",
    "typeId": "display-figures",
    "status": "retailer-preview",
    "name": "Funko BLEACH: Thousand-Year Blood War Pop! Animation Yhwach Vinyl Figure",
    "series": "Bleach",
    "type": "Display figure",
    "color": "#e5a073",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/funko-bleach-thousand-year-blood-war-pop-animation-yhwach-vinyl-figure/35533278.html",
    "description": "A collectible figure listing for fans who want a focal point for a shelf or display. Compare its dimensions, materials, and included accessories on the retailer’s page before choosing a spot.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-36319234",
    "worldId": "bleach",
    "category": "style",
    "typeId": "t-shirts",
    "status": "retailer-preview",
    "name": "BLEACH Rukia Panel Bold T-Shirt",
    "series": "Bleach",
    "type": "T-shirt / casual top",
    "color": "#e5a073",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/bleach-rukia-panel-bold-t-shirt/36319234.html",
    "description": "An anime apparel listing for bringing a favorite story into an everyday outfit. Read the retailer’s current size chart, fabric details, and care instructions before choosing a size.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-36154504",
    "worldId": "bleach",
    "category": "desk",
    "typeId": "room-decor",
    "status": "retailer-preview",
    "name": "FigureKey Bleach Ichigo Kurosaki (Bankai) Plush Figure 8\"H",
    "series": "Bleach",
    "type": "Room / desk accessory",
    "color": "#e5a073",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/figurekey-bleach-ichigo-kurosaki-bankai-plush-figure-8h/36154504.html",
    "description": "A home or desk listing for adding a small detail to your personal space. Check the item’s exact dimensions, materials, and intended use on the retailer’s page.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-34693358",
    "worldId": "chainsaw-man",
    "category": "figures",
    "typeId": "display-figures",
    "status": "retailer-preview",
    "name": "Chainsaw Man Power Vinyl Figure",
    "series": "Chainsaw Man",
    "type": "Display figure",
    "color": "#dc8e77",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/chainsaw-man-power-vinyl-figure/34693358.html",
    "description": "A collectible figure listing for fans who want a focal point for a shelf or display. Compare its dimensions, materials, and included accessories on the retailer’s page before choosing a spot.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-35314734",
    "worldId": "chainsaw-man",
    "category": "style",
    "typeId": "t-shirts",
    "status": "retailer-preview",
    "name": "Chainsaw Man Power Stained Glass Portrait T-Shirt",
    "series": "Chainsaw Man",
    "type": "T-shirt / casual top",
    "color": "#dc8e77",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/chainsaw-man-power-stained-glass-portrait-t-shirt/35314734.html",
    "description": "An anime apparel listing for bringing a favorite story into an everyday outfit. Read the retailer’s current size chart, fabric details, and care instructions before choosing a size.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-36817254",
    "worldId": "chainsaw-man",
    "category": "accessories",
    "typeId": "keychains",
    "status": "retailer-preview",
    "name": "FigureKey Chainsaw Man Chainsaw Man Fight Plush 8\"H",
    "series": "Chainsaw Man",
    "type": "Keychain / charm",
    "color": "#dc8e77",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/figurekey-chainsaw-man-chainsaw-man-fight-plush-8h/36817254.html",
    "description": "An anime accessory listing for a small everyday detail or a gift. Check the size, attachment, materials, and included pieces on the retailer’s page before ordering.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-37178001",
    "worldId": "blue-lock",
    "category": "style",
    "typeId": "hoodies",
    "status": "retailer-preview",
    "name": "Blue Lock Goal! Mineral Wash Hoodie",
    "series": "Blue Lock",
    "type": "Hoodie / sweatshirt",
    "color": "#7aa9e5",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/blue-lock-goal-mineral-wash-hoodie/37178001.html",
    "description": "An anime apparel listing for bringing a favorite story into an everyday outfit. Read the retailer’s current size chart, fabric details, and care instructions before choosing a size.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-31162618",
    "worldId": "blue-lock",
    "category": "style",
    "typeId": "t-shirts",
    "status": "retailer-preview",
    "name": "Blue Lock Eyes Locked T-Shirt",
    "series": "Blue Lock",
    "type": "T-shirt / casual top",
    "color": "#7aa9e5",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/blue-lock-eyes-locked-t-shirt/31162618.html",
    "description": "An anime apparel listing for bringing a favorite story into an everyday outfit. Read the retailer’s current size chart, fabric details, and care instructions before choosing a size.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-37178019",
    "worldId": "blue-lock",
    "category": "style",
    "typeId": "hoodies",
    "status": "retailer-preview",
    "name": "Blue Lock U 20 Emo Mineral Wash Hoodie",
    "series": "Blue Lock",
    "type": "Hoodie / sweatshirt",
    "color": "#7aa9e5",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/blue-lock-u-20-emo-mineral-wash-hoodie/37178019.html",
    "description": "An anime apparel listing for bringing a favorite story into an everyday outfit. Read the retailer’s current size chart, fabric details, and care instructions before choosing a size.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-36164176",
    "worldId": "solo-leveling",
    "category": "style",
    "typeId": "t-shirts",
    "status": "retailer-preview",
    "name": "CVLA X Solo Leveling Beru T-Shirt",
    "series": "Solo Leveling",
    "type": "T-shirt / casual top",
    "color": "#a993e5",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/cvla-x-solo-leveling-beru-t-shirt/36164176.html",
    "description": "An anime apparel listing for bringing a favorite story into an everyday outfit. Read the retailer’s current size chart, fabric details, and care instructions before choosing a size.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-36582085",
    "worldId": "solo-leveling",
    "category": "desk",
    "typeId": "room-decor",
    "status": "retailer-preview",
    "name": "Solo Leveling Mug Bundle",
    "series": "Solo Leveling",
    "type": "Room / desk accessory",
    "color": "#a993e5",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/solo-leveling-mug-bundle/36582085.html",
    "description": "A home or desk listing for adding a small detail to your personal space. Check the item’s exact dimensions, materials, and intended use on the retailer’s page.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-33970130",
    "worldId": "solo-leveling",
    "category": "style",
    "typeId": "t-shirts",
    "status": "retailer-preview",
    "name": "Solo Leveling Statue Of God T-Shirt",
    "series": "Solo Leveling",
    "type": "T-shirt / casual top",
    "color": "#a993e5",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/solo-leveling-statue-of-god-t-shirt/33970130.html",
    "description": "An anime apparel listing for bringing a favorite story into an everyday outfit. Read the retailer’s current size chart, fabric details, and care instructions before choosing a size.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-35656521",
    "worldId": "pokemon",
    "category": "figures",
    "typeId": "display-figures",
    "status": "retailer-preview",
    "name": "Funko Pop! Games Pokémon Lycanroc (Midday Form) Vinyl Figure",
    "series": "Pokémon",
    "type": "Display figure",
    "color": "#d6a73e",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/funko-pop-games-pokemon-lycanroc-midday-form-vinyl-figure/35656521.html",
    "description": "A collectible figure listing for fans who want a focal point for a shelf or display. Compare its dimensions, materials, and included accessories on the retailer’s page before choosing a spot.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-36269886",
    "worldId": "pokemon",
    "category": "style",
    "typeId": "hats",
    "status": "retailer-preview",
    "name": "Pokémon Eevee Dad Cap",
    "series": "Pokémon",
    "type": "Hat / headwear",
    "color": "#d6a73e",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/pokemon-eevee-dad-cap/36269886.html",
    "description": "An anime apparel listing for bringing a favorite story into an everyday outfit. Read the retailer’s current size chart, fabric details, and care instructions before choosing a size.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-35501500",
    "worldId": "pokemon",
    "category": "accessories",
    "typeId": "keychains",
    "status": "retailer-preview",
    "name": "Pokémon Blind Assorted Plush Keychain",
    "series": "Pokémon",
    "type": "Keychain / charm",
    "color": "#d6a73e",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/pokemon-blind-assorted-plush-keychain/35501500.html",
    "description": "An anime accessory listing for a small everyday detail or a gift. Check the size, attachment, materials, and included pieces on the retailer’s page before ordering.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-16620143",
    "worldId": "hunter-x-hunter",
    "category": "figures",
    "typeId": "display-figures",
    "status": "retailer-preview",
    "name": "Hunter x Hunter Hisoka Figure",
    "series": "Hunter × Hunter",
    "type": "Display figure",
    "color": "#78b388",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/hunter-x-hunter-hisoka-figure/16620143.html",
    "description": "A collectible figure listing for fans who want a focal point for a shelf or display. Compare its dimensions, materials, and included accessories on the retailer’s page before choosing a spot.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-36008731",
    "worldId": "hunter-x-hunter",
    "category": "style",
    "typeId": "hats",
    "status": "retailer-preview",
    "name": "Hunter X Hunter Logo Dad Cap",
    "series": "Hunter × Hunter",
    "type": "Hat / headwear",
    "color": "#78b388",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/hunter-x-hunter-logo-dad-cap/36008731.html",
    "description": "An anime apparel listing for bringing a favorite story into an everyday outfit. Read the retailer’s current size chart, fabric details, and care instructions before choosing a size.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-34658937",
    "worldId": "hunter-x-hunter",
    "category": "accessories",
    "typeId": "keychains",
    "status": "retailer-preview",
    "name": "Hunter X Hunter Gon Keychain",
    "series": "Hunter × Hunter",
    "type": "Keychain / charm",
    "color": "#78b388",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/hunter-x-hunter-gon-keychain/34658937.html",
    "description": "An anime accessory listing for a small everyday detail or a gift. Check the size, attachment, materials, and included pieces on the retailer’s page before ordering.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-37252376",
    "worldId": "death-note",
    "category": "figures",
    "typeId": "display-figures",
    "status": "retailer-preview",
    "name": "Death Note L Figure",
    "series": "Death Note",
    "type": "Display figure",
    "color": "#a0a0c2",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/death-note-l-figure/37252376.html",
    "description": "A collectible figure listing for fans who want a focal point for a shelf or display. Compare its dimensions, materials, and included accessories on the retailer’s page before choosing a spot.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-36151066",
    "worldId": "death-note",
    "category": "style",
    "typeId": "t-shirts",
    "status": "retailer-preview",
    "name": "Death Note Chibi Trio T-Shirt",
    "series": "Death Note",
    "type": "T-shirt / casual top",
    "color": "#a0a0c2",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/death-note-chibi-trio-t-shirt/36151066.html",
    "description": "An anime apparel listing for bringing a favorite story into an everyday outfit. Read the retailer’s current size chart, fabric details, and care instructions before choosing a size.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  },
  {
    "id": "expand-ht-35763042",
    "worldId": "death-note",
    "category": "accessories",
    "typeId": "jewellery",
    "status": "retailer-preview",
    "name": "Death Note Icon Necklace Set",
    "series": "Death Note",
    "type": "Jewellery / wearable accessory",
    "color": "#a0a0c2",
    "retailer": "Hot Topic",
    "seller": "Hot Topic",
    "sourceUrl": "https://www.hottopic.com/product/death-note-icon-necklace-set/35763042.html",
    "description": "An anime accessory listing for a small everyday detail or a gift. Check the size, attachment, materials, and included pieces on the retailer’s page before ordering.",
    "tips": [
      "Check the exact model, dimensions, and included items.",
      "Confirm current price, availability, shipping, and returns at Hot Topic.",
      "Read the retailer’s product details and any licensing statements; NEXORI has not physically tested this item."
    ]
  }
];
import {build} from 'vite';
import {readFile,readdir,mkdir,writeFile,rm} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {products,franchises,categories} from '../src/data.js';
import {validateCatalog} from '../src/catalog.js';

const root=fileURLToPath(new URL('../',import.meta.url));
validateCatalog(products);
if(products.length!==43||franchises.length!==14||products.some(p=>!['Hot Topic','eBay'].includes(p.retailer)||p.image||p.productPhoto||p.price))throw Error('Unexpected affiliate catalog');
const affiliateProducts=products.filter(p=>p.affiliateUrl);
if(affiliateProducts.length!==1||affiliateProducts[0].retailer!=='eBay'||affiliateProducts[0].sourceUrl!=='https://www.ebay.com/itm/197978173286')throw Error('Unexpected affiliate placement');
const supplied=(await readFile(path.join(root,'affiliate-link-supplied.txt'),'utf8')).trim();
if(affiliateProducts[0].affiliateUrl!==supplied)throw Error('Supplied affiliate link changed');
const tracking=new URL(supplied);
if(tracking.protocol!=='https:'||tracking.hostname!=='www.ebay.com'||tracking.pathname!=='/itm/197978173286'||tracking.searchParams.get('campid')!=='5339230513'||tracking.searchParams.get('customid')!=='nexorifirstfigure'||tracking.searchParams.get('toolid')!=='10001'||tracking.searchParams.get('mkevt')!=='1')throw Error('Unexpected affiliate tracking parameters');
const art={};
for(const name of await readdir(path.join(root,'public/assets'))){
 if(!name.endsWith('.svg'))throw Error('Only authored SVG artwork belongs in this edition');
 const source=await readFile(path.join(root,'public/assets',name),'utf8');
 if(/<image\b|<script\b|<foreignObject\b|https?:\/\/(?!www\.w3\.org)/i.test(source))throw Error('Unexpected image or external reference');
 art[path.basename(name,'.svg')]=`data:image/svg+xml;base64,${Buffer.from(source).toString('base64')}`;
}
const result=await build({root,configFile:false,publicDir:false,build:{write:false,minify:true,modulePreload:false,rollupOptions:{input:path.join(root,'src/site-entry.js'),output:{inlineDynamicImports:true,entryFileNames:'site.js'}}}});
const chunks=result.output.filter(item=>item.type==='chunk');if(chunks.length!==1)throw Error('Single-file build expected');
const css=result.output.filter(item=>item.type==='asset'&&item.fileName.endsWith('.css')).map(item=>item.source).join('\n');
let html=await readFile(path.join(root,'index.html'),'utf8');
html=html.replace('href="/assets/mark.svg"',`href="${art.mark}"`).replace('</head>',()=>`<style>${css.replace(/<\/style/gi,'<\\/style')}</style><script>window.NEXORI_ART=${JSON.stringify(art).replace(/</g,'\\u003c')};</script></head>`).replace('<script type="module" src="/src/site-entry.js"></script>',()=>`<script type="module">${chunks[0].code.replace(/<\/script/gi,'<\\/script')}</script>`);
if(/firestore|firebaseapp|nexori-development|AIza|catalog-.*\.(?:jpg|webp)|data:image\/(?:png|jpeg|webp)|Authentic Anime|permissions are pending/.test(html))throw Error('Old cloud or retailer-image content entered the public build');
await rm(path.join(root,'dist'),{recursive:true,force:true});await mkdir(path.join(root,'dist'),{recursive:true});
await writeFile(path.join(root,'dist/index.html'),html);
await writeFile(path.join(root,'dist/NEXORI-application.html'),html);
console.log(JSON.stringify({htmlBytes:Buffer.byteLength(html),products:products.length,anime:franchises.length,categories:categories.length,originalSvgAssets:Object.keys(art).length,affiliateLinks:affiliateProducts.length,firebase:false,retailerImages:false}));

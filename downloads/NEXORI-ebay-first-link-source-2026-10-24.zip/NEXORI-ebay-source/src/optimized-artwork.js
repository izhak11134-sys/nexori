export const optimizedArtwork = {};

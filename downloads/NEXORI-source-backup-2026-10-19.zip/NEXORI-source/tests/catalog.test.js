import test from 'node:test';
import assert from 'node:assert/strict';
import { categories, franchises, products } from '../src/data.js';
import { catalogDefaults, readCatalogFilters, catalogHref, selectCatalogProducts, validateCatalog } from '../src/catalog.js';

test('all preview records have a unique place and cannot appear as franchise merchandise', () => {
  assert.equal(validateCatalog(products),true);
  const concepts=products.filter(p=>p.status==='concept');
  for (const world of franchises) assert(selectCatalogProducts(products,{...catalogDefaults,world:world.id}).every(p=>p.status!=='concept'));
  assert.equal(selectCatalogProducts(products,{...catalogDefaults,world:'original'}).length,concepts.length);
});

test('combined category, type and world filters keep one record per result', () => {
  // Synthetic records test future classification; these are not retail listings.
  const records = [
    {id:'fixture-a',name:'Figure A',category:'figures',typeId:'display-figures',worldId:'one-piece',type:'Figure'},
    {id:'fixture-b',name:'Figure B',category:'figures',typeId:'display-figures',worldId:'naruto',type:'Figure'},
    {id:'fixture-c',name:'Shirt A',category:'style',typeId:'t-shirts',worldId:'one-piece',type:'T-shirt'},
  ];
  assert.equal(validateCatalog(records),true);
  assert.deepEqual(selectCatalogProducts(records,{...catalogDefaults,world:'one-piece'}).map(x=>x.id),['fixture-a','fixture-c']);
  assert.deepEqual(selectCatalogProducts(records,{...catalogDefaults,world:'one-piece',category:'figures',type:'display-figures'}).map(x=>x.id),['fixture-a']);
  assert.deepEqual(selectCatalogProducts(records,{...catalogDefaults,world:'one-piece',category:'desk'}),[]);
});

test('filters round-trip through a shareable URL including literal search characters', () => {
  const filters={category:'desk',world:'original',type:'desk-mats',query:'desk & <room>',sort:'az'};
  assert.deepEqual(readCatalogFilters(new URL(catalogHref(filters),'https://example.test').searchParams),filters);
});

test('unknown filters and incompatible category/type combinations are normalized', () => {
  assert.deepEqual(readCatalogFilters(new URLSearchParams('category=unknown&world=unknown&type=unknown&sort=unknown')),catalogDefaults);
  assert.equal(readCatalogFilters(new URLSearchParams('category=style&type=desk-mats')).type,'all');
  assert.equal(readCatalogFilters(new URLSearchParams({q:'x'.repeat(300)})).query.length,100);
});

test('records with duplicate IDs, invalid placement or mislabelled concepts are rejected', () => {
  assert.throws(()=>validateCatalog([products[0],products[0]]),/duplicate/);
  assert.throws(()=>validateCatalog([{...products[0],typeId:'hoodies'}]),/Invalid category/);
  assert.throws(()=>validateCatalog([{...products[0],worldId:'unknown'}]),/Unknown world/);
  assert.throws(()=>validateCatalog([{...products[0],status:'concept',worldId:'one-piece'}]),/Unverified concept/);
});

test('search and alphabetical sorting do not mutate the original catalog order', () => {
  const before=products.map(p=>p.id);
  const result=selectCatalogProducts(products,{...catalogDefaults,query:'desk',sort:'az'});
  assert(result.some(p=>p.id==='after-hours-desk'));
  assert(result[0].name.localeCompare(result.at(-1).name)<=0);
  assert.deepEqual(products.map(p=>p.id),before);
});

test('every category has a unique set of usable product types', () => {
  const ids=categories.flatMap(c=>c.types.map(t=>t.id));
  assert.equal(new Set(ids).size,ids.length);
  for (const category of categories) assert(category.types.length>0);
});

 test('retailer selections have dated prices, original concepts remain identifiable and sword variants have separate destinations',()=>{
  const picks=products.filter(p=>p.status==='retailer-preview');assert.equal(picks.length,360);
  assert.equal(new Set(products.map(p=>p.worldId)).size,6);
  for(const p of picks){assert.equal(p.photoPermission,'pending');assert(Number(p.price)>0);assert.match(p.priceCheckedOn,/^\d{4}-\d{2}-\d{2}$/);assert.equal(new URL(p.sourceUrl).protocol,'https:');assert(p.productPhoto);}
  assert.equal(new Set(picks.filter(p=>p.id.startsWith('zoro-')||p.id==='moonlight-blade').map(p=>p.sourceUrl)).size,4);
 });

 test('each anime has twelve distinct products in every category, with local product photos',async()=>{
  const {access}=await import('node:fs/promises');
  for(const world of new Set(products.map(p=>p.worldId)))for(const category of categories)
    assert.equal(products.filter(p=>p.worldId===world&&p.category===category.id).length,12,`${world}/${category.id}`);
  assert.equal(new Set(products.map(p=>p.sourceUrl)).size,products.length);
  for(const p of products)await access(new URL('../public'+p.productPhoto,import.meta.url));
 });

 test('eBay selections carry qualifying seller evidence and disclose pre-owned condition',()=>{
  const listings=products.filter(p=>p.retailer==='eBay');assert(listings.length>0);
  for(const p of listings){
    const r=p.sellerReview;assert(r,`Missing seller review: ${p.id}`);
    assert(r.positivePercent>=99,`Low seller feedback: ${p.id}`);
    assert(r.feedbackScore>=500,`Insufficient feedback history: ${p.id}`);
    assert(r.returnDays>=30||(r.returnDays>=14&&r.positivePercent===100),`Return terms do not meet the screen: ${p.id}`);
    assert.match(r.checkedOn,/^\d{4}-\d{2}-\d{2}$/);assert(p.seller&&p.seller!=='Marketplace seller');
    assert(p.variantNote.includes(`${r.returnDays} days`));
    if(r.condition==='Pre-owned'){assert.match(p.name,/pre-owned/i);assert.match(p.variantNote,/pre-owned/i);}
  }
 });

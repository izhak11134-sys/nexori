export const contactEmail = 'nexoriofficialon@gmail.com';
export const contactLink = `<a class="policy-link" href="mailto:${contactEmail}">${contactEmail}</a>`;
export const policyDate = '2026-10-23';
export const previewNotice = 'Explore a small selection of Hot Topic listings with original shopping guidance. Product photographs are not displayed. Follow the retailer link for product images, current prices, availability, and terms. No affiliate commissions are active.';
export const franchiseNotice = 'NEXORI is an independent discovery website. It is not endorsed by or affiliated with Hot Topic or the anime franchises referenced here. Names and trademarks belong to their respective owners.';
export const policies = {
  disclosure: {
    eyebrow:'CLEAR FROM THE START', title:'Affiliate disclosure.',
    intro:'Understand our links before you follow them.',
    sections:[
      ['Our links today','The links in this collection are ordinary links to Hot Topic. NEXORI is not currently an approved Hot Topic affiliate and does not earn a commission from these links. There are no paid placements in this version.'],
      ['How future affiliate links will work','If we join an affiliate program, we may earn a commission when you make a qualifying purchase through an identified affiliate link. We will update this notice and clearly disclose the relationship near the recommendations before activating those links.'],
      ['How we choose','The collection is an editorial selection of retailer listings across anime worlds and product categories. We provide general buying considerations and do not claim that items have been physically tested. Selection is not a certification of product authenticity or licensing.'],
      ['Prices and availability','Current prices are shown at the retailer. Availability, selected variants, delivery costs, taxes, and returns can change. Check the exact listing and checkout terms before ordering.'],
      ['Questions',`For questions about a recommendation or a commercial relationship, contact ${contactLink}.`],
    ],
  },
  privacy: {
    eyebrow:'YOUR SPACE. YOUR CHOICE.',title:'Privacy, in plain language.',
    intro:'The information used by this version of NEXORI.',
    sections:[
      ['Who to contact',`NEXORI is operated by ITZHAK KEDMA, based in Israel, primarily for English-speaking anime fans. Contact ${contactLink} about privacy or your information.`],
      ['Saved finds','When you save an item, its identifier is stored in this browser under nexori.application.saved.v1. It is not sent to NEXORI by this feature and is not shared between devices. Remove items, use Clear saved finds below, or clear the site’s browser data to delete the list. If browser storage is unavailable, saving may last only for the current visit.'],
      ['Motion preferences','The Reduce visual motion control stores your choice in this browser under nexori.application.motion.v1. The site also respects your browser’s reduced-motion setting. Clearing this site’s browser data removes its saved preference.'],
      ['Search and site features','Search and filters run locally over the included collection. Navigation and search selections are kept in the URL fragment and browser history. This version does not add visitor registration, checkout, a contact form, analytics, advertising pixels, a newsletter, a Firebase connection, or third-party image loading.'],
      ['Hosting with Netlify','NEXORI uses Netlify to host and deliver the website at https://nexori-collection.netlify.app. To deliver pages and operate its infrastructure, the hosting service may process technical information such as IP address, browser details, requested URLs, request times, and service logs. Hosting infrastructure and service providers may process information outside your country, including outside Israel. Provider processing and retention are subject to the applicable service arrangements and Netlify’s privacy practices; this notice does not promise a fixed hosting-log retention period. Read <a class="policy-link" href="https://www.netlify.com/privacy/" target="_blank" rel="noopener noreferrer">Netlify’s privacy statement</a> for its description of provider processing.'],
      ['When you email us','The contact link opens your email application. Emailing NEXORI shares your address and the message you choose to send. Messages are handled through Gmail and the email providers involved. Do not send passwords, identification documents, card information, or other unnecessary sensitive details. An inquiry does not subscribe you to marketing. Correspondence should be retained only as needed to handle the inquiry, follow-up, and applicable obligations.'],
      ['Retailer websites','Following a retailer link opens a separate website governed by its own privacy policy and terms. These are ordinary retailer links, not active affiliate tracking links. Before introducing affiliate tracking or analytics, we will update this notice and address applicable disclosure and consent requirements.'],
      ['Your choices and requests',`Use the controls below to clear saved finds, or contact ${contactLink} for requests about information held through correspondence. Requests will be assessed under applicable law; proportionate verification may be needed.`],
    ],action:'clear-saved',
  },
  terms: {
    eyebrow:'A FEW THINGS TO KNOW',title:'Terms of use.',
    intro:'Information for using NEXORI and following retailer links.',
    sections:[
      ['What NEXORI provides','NEXORI provides an independent selection of external retailer listings and general shopping guides. It does not sell products, accept payment, or fulfil orders. Guidance is based on listing research and general buying considerations, not hands-on product testing.'],
      ['External purchases','Purchases take place at the retailer under its own terms. Confirm the exact item and variant, current price, taxes, shipping, availability, age restrictions, and returns before ordering. The retailer handles payment, fulfilment, and order support. This does not remove our responsibility for information we publish.'],
      ['Independent references',franchiseNotice],
      ['Illustrations and product listings','The decorative geometric illustrations were created for NEXORI and are not product photographs. Product names identify external listings. Product photographs and franchise character illustrations are not included in this version. Our selection does not establish a product’s authenticity, suitability, or licensing.'],
      ['Commercial relationships','No affiliate commissions or paid placements are active in this version. Any future material commercial relationship will be disclosed.'],
      ['Responsible use','Do not attempt unauthorized access, disrupt the website, or use it to infringe others’ rights. Do not send unnecessary sensitive information through email.'],
      ['Corrections and your rights',`Report inaccurate information or a rights concern to ${contactLink}, identifying the page and the issue. Nothing here excludes rights or obligations that cannot lawfully be excluded.`],
    ],
  },
  contact: {
    eyebrow:'LET’S KEEP IT REAL',title:'Get in touch.',
    intro:'Questions, corrections, and thoughtful feedback are welcome.',
    sections:[
      ['Contact NEXORI',`Email ${contactLink} for website questions, editorial corrections, partnership inquiries, privacy requests, accessibility feedback, or rights concerns. NEXORI is operated by ITZHAK KEDMA, based in Israel, and writes primarily for English-speaking anime fans.`],
      ['What to include','Include the page address and a short description of your question or concern. For accessibility issues, browser and device details may help. Please leave out passwords, card details, and other unnecessary sensitive information.'],
      ['Retailer orders','For payment, shipping, refunds, or returns relating to a Hot Topic purchase, contact Hot Topic directly. NEXORI does not have access to retailer order records.'],
      ['How email works','The email link opens your email application; this website does not submit a form. Contacting us does not subscribe you to marketing.'],
    ],
  },
  accessibility: {
    eyebrow:'A PLACE FOR EVERY FAN',title:'Accessibility.',
    intro:'Features that support browsing, and how to report a barrier.',
    sections:[
      ['Navigation','The website includes a skip-to-content link, keyboard-accessible controls, visible focus states, labelled navigation, and a search dialog that can be dismissed with Escape.'],
      ['Motion and display','Use Reduce visual motion to stop decorative motion. The site also respects your browser’s reduced-motion preference. Layouts adapt to smaller screens and support browser zoom. Product selections use text cards, not product photos.'],
      ['Assessment','A complete assessment with assistive technologies and against all applicable accessibility requirements has not been completed. This page is not a certification of legal or WCAG compliance.'],
      ['Report a barrier',`Contact ${contactLink} with the page, task, and difficulty. We will review the issue and discuss a suitable way to help.`],
    ],
  },
  rights: {
    eyebrow:'RESPECT FOR THE STORIES',title:'Content & franchise references.',
    intro:'A clear distinction between our illustrations and retailer products.',
    sections:[
      ['Independent references',franchiseNotice],
      ['Decorative artwork','The website uses geometric SVG artwork created in code for NEXORI: abstract portals, stars, shelves, and shopping-guide symbols. These graphics are decorative. They do not depict the products offered by the retailer or establish product appearance, authenticity, or licensing.'],
      ['Product images','Product and franchise character photographs or illustrations from retailers are not displayed in this version. Follow the identified retailer link to see the actual product images. Any future use of merchant images will require a suitable permitted content source or permission covering that use.'],
      ['Report a concern',`For a rights or trademark concern, contact ${contactLink} with the page, relevant material, and explanation of your interest. We will review the concern and supporting information.`],
    ],
  },
};

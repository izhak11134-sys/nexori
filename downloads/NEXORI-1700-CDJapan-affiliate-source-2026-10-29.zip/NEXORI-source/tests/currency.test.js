import test from 'node:test';
import assert from 'node:assert/strict';
import {usdEstimate,formatProductPrice,yenReference} from '../src/currency.js';
test('JPY estimate follows the dated source quote and changes with edited yen prices',()=>{
 assert.equal(usdEstimate(5100,'JPY'),32.35);
 assert.equal(usdEstimate(10200,'JPY'),64.70);
 assert.equal(formatProductPrice({price:'5100',currency:'JPY'}),'JPY\u00a05,100 (≈ US$32.35)');
 assert.equal(formatProductPrice({price:'10200',currency:'JPY'}),'JPY\u00a010,200 (≈ US$64.70)');
 assert.equal(yenReference.date,'2026-10-28');
});
test('USD prices remain unchanged and missing or invalid amounts do not become fake prices',()=>{
 assert.equal(formatProductPrice({price:'25',currency:'USD'}),'$25.00');
 assert.equal(usdEstimate(25,'USD'),null);
 for(const price of ['',undefined,null,'not a price',-1])assert.equal(formatProductPrice({price,currency:'JPY'}),'Check price at retailer');
});

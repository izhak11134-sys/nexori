import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {products} from '../src/data.js';
import {retailerDestination,cdjapanAffiliate} from '../src/affiliate-links.js';
const baseline=JSON.parse(await readFile(new URL('../docs/cdjapan-affiliate-2026-10-29/baseline.json',import.meta.url)));
const sha=value=>createHash('sha256').update(value).digest('hex');
test('all 133 product links retain the supplied identifiers and decode to their own catalogue destination',()=>{
 const rows=products.filter(p=>p.retailer==='CDJapan');assert.equal(rows.length,133);
 const urls=new Set();
 for(const p of rows){
  const d=retailerDestination(p),url=new URL(d.url),segments=url.pathname.split('/');
  assert.equal(d.affiliate,true);assert.equal(url.origin,'https://www.cdjapan.co.jp');
  assert.deepEqual(segments.slice(1,6),['aff','click.cgi','PytJTGW7Lok','7898','A934864']);
  assert.equal(url.search,'');assert.equal(url.hash,'');assert.equal(decodeURIComponent(segments[6]),new URL(p.sourceUrl).pathname.slice(1));
  assert.equal(segments.length,7);urls.add(d.url);
 }
 assert.equal(urls.size,133);assert.equal(cdjapanAffiliate.affiliateId,'A934864');
});
test('the first generated destination is identical to the full user-supplied link, including case and encoding',async()=>{
 const supplied=(await readFile(new URL('./fixtures/cdjapan-supplied-link.txt',import.meta.url),'utf8')).trim();
 assert.equal(retailerDestination(products.find(p=>p.id==='cdjapan-neogds-937972')).url,supplied);
});
test('all 1700 catalogue records, all 1567 eBay destinations and the existing Firestore rules are unchanged',async()=>{
 assert.equal(products.length,baseline.total);assert.equal(sha(JSON.stringify(products)),baseline.catalogSha256);
 const ebay=products.filter(p=>p.retailer==='eBay').map(p=>({id:p.id,...retailerDestination(p)}));
 assert.equal(ebay.length,1567);assert.equal(sha(JSON.stringify(ebay)),baseline.ebayDestinationsSha256);
 assert.equal(sha(await readFile(new URL('../firestore.rules',import.meta.url))),baseline.rulesSha256);
});
test('lookalikes, arbitrary pages, query variants and credentials never receive the CDJapan template',()=>{
 for(const sourceUrl of ['https://www.cdjapan.co.jp.evil.test/product/NEOGDS-937972','https://evil-cdjapan.co.jp/product/NEOGDS-937972','https://www.cdjapan.co.jp/','https://www.cdjapan.co.jp/aff/terms.html','https://www.cdjapan.co.jp/product/NEOGDS-937972?x=1','https://www.cdjapan.co.jp/product/NEOGDS-937972#x','https://www.cdjapan.co.jp/product/NEOGDS-937972%2F..%2Fx'])assert.equal(retailerDestination({retailer:'CDJapan',sourceUrl}).affiliate,false);
 for(const sourceUrl of ['http://www.cdjapan.co.jp/product/NEOGDS-937972','https://user:pass@www.cdjapan.co.jp/product/NEOGDS-937972','javascript:alert(1)'])assert.equal(retailerDestination({retailer:'CDJapan',sourceUrl}).url,'');
 assert.equal(retailerDestination({retailer:'eBay',sourceUrl:'https://www.cdjapan.co.jp/product/NEOGDS-937972'}).affiliate,false);
});

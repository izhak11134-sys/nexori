const assert=require('node:assert/strict');
const{readFileSync}=require('node:fs');
const{chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
(async()=>{const{products}=await import('../../src/data.js');const cd=products.filter(p=>p.retailer==='CDJapan');const supplied=readFileSync(__dirname+'/../fixtures/cdjapan-supplied-link.txt','utf8').trim();
const b=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});try{
 const c=await b.newContext({viewport:{width:1280,height:900}}),errors=[],blocked=[];
 await c.route(/^https?:/,r=>{if(['localhost','127.0.0.1'].includes(new URL(r.request().url()).hostname))return r.continue();blocked.push(r.request().url());return r.abort();});
 const p=await c.newPage();p.on('pageerror',e=>errors.push(e.message));const base=process.env.SITE_URL||'http://127.0.0.1:5203/NEXORI-1700-products.html',portable=base.endsWith('.html');await p.goto(portable?base+'#/product/'+cd[0].id:base+'/product/'+cd[0].id);await p.locator('.retail-offer').waitFor();
 for(const product of cd){
  await p.evaluate(({id,portable})=>{history.replaceState({},'',(portable?'#':'')+'/product/'+id);dispatchEvent(new PopStateEvent('popstate'));},{id:product.id,portable});
  const a=p.locator('.retail-offer a.button'),href=await a.getAttribute('href');
  assert.equal(href,'https://www.cdjapan.co.jp/aff/click.cgi/PytJTGW7Lok/7898/A934864/'+encodeURIComponent(new URL(product.sourceUrl).pathname.slice(1)));
  assert.match(await a.getAttribute('rel'),/sponsored/);assert.equal(await a.getAttribute('target'),'_blank');
  assert.match(await p.locator('.affiliate-disclosure').innerText(),/CDJapan affiliate/);assert.match(await p.locator('.retail-offer').innerText(),/checkout take place at CDJapan/);assert(!(await p.locator('.retail-offer').innerText()).includes('no affiliate commission'));
  assert.match(await p.locator('.retail-price').innerText(),/JPY.+≈ US\$/);
 }
 await p.evaluate(portable=>{history.replaceState({},'',(portable?'#':'')+'/product/cdjapan-neogds-937972');dispatchEvent(new PopStateEvent('popstate'));},portable);
 const a=p.locator('.retail-offer a.button');assert.equal(await a.getAttribute('href'),supplied);
 // A popup is inspected only with an intercept that blocks the request before it leaves Chromium.
 const[popup]=await Promise.all([p.waitForEvent('popup'),a.click()]);await popup.waitForLoadState('domcontentloaded').catch(()=>{});await popup.close();assert(blocked.includes(supplied));
 for(const path of ['/disclosure','/privacy']){await p.evaluate(({path,portable})=>{history.replaceState({},'',(portable?'#':'')+path);dispatchEvent(new PopStateEvent('popstate'));},{path,portable});const text=await p.locator('main').innerText();assert.match(text,/CDJapan/);assert(!/CDJapan.*(?:regular product|without NEXORI affiliate)/i.test(text));assert.match(await p.locator('.policy-date').innerText(),/October 29, 2026/);}
 await p.setViewportSize({width:390,height:844});await p.evaluate(portable=>{history.replaceState({},'',(portable?'#':'')+'/product/cdjapan-neogds-937972');dispatchEvent(new PopStateEvent('popstate'));},portable);assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);await p.screenshot({path:'/tmp/nexori-cdjapan-affiliate-mobile.png',fullPage:true});assert.deepEqual(errors,[]);
 console.log('PASS '+(portable?'portable':'source')+': all 133 rendered CDJapan purchase destinations, exact supplied first URL, sponsored rel, retailer-specific disclosure and checkout text, JPY+USD, updated policy dates, mobile layout and intercepted popup; no real affiliate request.');
}finally{await b.close()}})().catch(e=>{console.error(e);process.exitCode=1});

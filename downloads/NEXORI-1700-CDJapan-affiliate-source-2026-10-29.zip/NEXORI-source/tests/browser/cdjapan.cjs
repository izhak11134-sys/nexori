// The first 40 source fixtures remain covered by tests/cdjapan.test.js.
// Current browser coverage includes all 133 CDJapan products and paging.
require('./expanded-catalog.cjs');

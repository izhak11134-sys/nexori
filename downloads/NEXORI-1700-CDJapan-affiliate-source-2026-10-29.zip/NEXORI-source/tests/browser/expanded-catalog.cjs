const assert=require('node:assert/strict');
const{chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
(async()=>{const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});try{
 const context=await browser.newContext({viewport:{width:1440,height:1000}}),errors=[];
 await context.route(/^https?:/,r=>['localhost','127.0.0.1'].includes(new URL(r.request().url()).hostname)?r.continue():r.abort());
 // Deliberately keep cloud unavailable: catalogue and banner must remain usable.
 const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
 const base=process.env.SITE_URL||'http://127.0.0.1:5201',portable=base.endsWith('.html');
 const go=async path=>{await page.goto(portable?base+'#'+path:base+path);await page.locator('#main').waitFor();};
 await go('/');await page.locator('.banner-scene img').waitFor();assert(await page.locator('.banner-scene').isVisible());await page.locator('.banner-scene img').evaluate(img=>img.decode());assert.equal(await page.locator('.world-card').count(),14);
 assert.match(await page.locator('.cdjapan-section .section-heading a').innerText(),/133/);
 await go('/collection');assert.equal(await page.locator('.product-card').count(),48);assert.match(await page.locator('#result-count').innerText(),/^1700 finds/);
 const first=await page.locator('.product-card').first().getAttribute('data-content-id');await page.locator('[data-catalog-more]').click();assert.equal(await page.locator('.product-card').count(),96);assert.equal(await page.locator('.product-card').first().getAttribute('data-content-id'),first);
 await page.locator('#collection-retailer').selectOption('ebay');assert.equal(await page.locator('.product-card').count(),48);assert.match(await page.locator('#result-count').innerText(),/^1567 finds/);
 await page.locator('#collection-world').selectOption('one-piece');await page.locator('[data-category="figures"]').click();assert((await page.locator('.product-card').count())>0);assert((await page.locator('.product-card-info>.tiny-label').allTextContents()).every(t=>t.endsWith('eBay')));
 await go('/collection?retailer=cdjapan');assert.match(await page.locator('#result-count').innerText(),/^133 finds/);assert.equal(await page.locator('.product-card').count(),48);
 for(let i=0;i<2;i++)await page.locator('[data-catalog-more]').click();assert.equal(await page.locator('.product-card').count(),133);assert(!(await page.locator('[data-catalog-more]').isVisible()));
 assert((await page.locator('.product-card-bottom>span').allTextContents()).every(t=>/JPY.+≈ US\$/.test(t)));
 const bad=await page.locator('.product-card img').evaluateAll(async imgs=>(await Promise.all(imgs.map(async img=>{try{img.loading='eager';await img.decode();return img.naturalWidth?null:img.src}catch{return img.src}}))).filter(Boolean));assert.deepEqual(bad,[]);
 if(portable){const img=page.locator('.product-card img').first();assert.match(await img.getAttribute('srcset'),/assets\//);assert(!(await img.getAttribute('srcset')).includes('/assets/'));}
 await go('/product/cdjapan-neogds-937972');assert.match(await page.locator('.retail-price').innerText(),/JPY\s*5,100 \(≈ US\$32.35\)/);assert.equal(await page.locator('.retail-offer a.button').getAttribute('href'),'https://www.cdjapan.co.jp/aff/click.cgi/PytJTGW7Lok/7898/A934864/product%2FNEOGDS-937972');assert.match(await page.locator('.retail-offer a.button').getAttribute('rel'),/sponsored/);assert.match(await page.locator('.affiliate-disclosure').innerText(),/CDJapan affiliate/);assert.match(await page.locator('.currency-note').innerText(),/2026-10-28/);
 for(const width of [390,768,1440]){await page.setViewportSize({width,height:900});await go('/collection?retailer=cdjapan');assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);}
 await page.setViewportSize({width:390,height:844});await page.screenshot({path:'/tmp/nexori-1700-mobile.png'});await page.setViewportSize({width:1440,height:1000});await go('/');await page.screenshot({path:'/tmp/nexori-1700-desktop.png'});
 assert.deepEqual(errors,[]);console.log('PASS '+(portable?'portable':'source')+': banner visible without cloud, 48-card paging, 1700 total, 1567 EPN / 133 CDJapan affiliate links, combined filters, 133 decoded photos, JPY+USD, relative responsive images and mobile layout.');
}finally{await browser.close()}})().catch(e=>{console.error(e);process.exitCode=1});

import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,access} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {products,productRecords,categories,franchises} from '../src/data.js';
import {expandedProducts} from '../src/expanded-products.js';
import {retailerDestination} from '../src/affiliate-links.js';
import {validateCatalog} from '../src/catalog.js';
import {applyContentDraft,contentRecord} from '../src/content.js';
import {formatProductPrice} from '../src/currency.js';
const evidence=JSON.parse(await readFile(new URL('../docs/expansion-2026-10-28/product-evidence.json',import.meta.url)));
test('618 sourced additions produce exactly 1700 products without deleting legacy content slots',()=>{
 assert.equal(expandedProducts.length,618);assert.equal(products.length,1700);assert.equal(productRecords.length,2408);validateCatalog(products);
 assert.equal(new Set(products.map(p=>p.id)).size,1700);assert.equal(new Set(products.map(p=>p.sourceUrl)).size,1700);
 for(const world of franchises)assert(expandedProducts.some(p=>p.worldId===world.id&&p.category==='figures'),world.id);
 for(const type of categories.flatMap(c=>c.types))assert(expandedProducts.filter(p=>p.typeId===type.id).length>=15,type.id);
 for(const id of ['one-piece','dragon-ball','pokemon','bleach'])assert(expandedProducts.filter(p=>p.worldId===id).length>=90,id);
});
test('every new offer has individual-page price, stock and image evidence; tracking remains store-specific',async()=>{
 for(const p of expandedProducts){
  const e=evidence.find(r=>r.sourceUrl===p.sourceUrl);assert(e,p.id);assert.equal(p.sourceImage,e.imageSource);assert.equal(p.priceCheckedOn,'2026-10-28');
  const destination=retailerDestination(p);
  if(p.retailer==='eBay'){
   assert.equal(e.valid,true);assert.equal(e.availability,'https://schema.org/InStock');assert.equal(p.currency,'USD');assert.equal(Number(p.price),Number(e.priceUSD));
   assert(p.sellerReview.positivePercent>=99);assert(p.sellerReview.feedbackScore>=500);assert(p.seller);
   assert.equal(destination.affiliate,true);assert.equal(new URL(destination.url).searchParams.get('campid'),'5339230513');
   assert(p.variantNote.includes(p.sellerReview.condition));
  }else{
   assert.deepEqual(e.issues,[]);assert.equal(p.currency,'JPY');assert.equal(Number(p.price),e.priceJPY);assert.equal(p.manufacturer,e.manufacturer);assert.equal(destination.affiliate,true);assert.equal(decodeURIComponent(new URL(destination.url).pathname.split('/').at(-1)),'product/'+p.catalogNo);assert.match(p.availability,/in stock/i);
  }
  await access(new URL('../public'+p.productPhoto,import.meta.url));
 }
});
test('editing a new yen price recomputes its displayed USD estimate without mutating another listing',()=>{
 const p=expandedProducts.find(p=>p.currency==='JPY'),other=expandedProducts.find(p=>p.currency==='USD'),old=JSON.stringify(other);
 applyContentDraft({version:1,changes:{products:{[p.id]:{price:'5100'}}}});
 assert.equal(formatProductPrice(contentRecord('products',p.id)),'JPY\u00a05,100 (≈ US$32.35)');assert.equal(JSON.stringify(other),old);
 applyContentDraft({version:1,changes:{}});
});
test('all new local product photos have recorded provenance and exact matching file hashes',async()=>{
 const images=JSON.parse(await readFile(new URL('../docs/expansion-2026-10-28/image-evidence.json',import.meta.url)));
 assert.equal(images.length,618);assert.equal(new Set(images.map(i=>i.sourceSha256)).size,618);
 for(const image of images){const bytes=await readFile(new URL('../public'+image.optimized.src,import.meta.url));assert.equal(createHash('sha256').update(bytes).digest('hex'),image.localSha256);assert(image.originalDimensions.every(v=>v>=120));}
});

// Public campaign parameters taken from the user's EPN-generated link.
// No tracking script or visitor identifier is installed on NEXORI.
export const ebayCampaign = Object.freeze({
  mkcid:'1',mkrid:'711-53200-19255-0',siteid:'0',
  campid:'5339230513',toolid:'10001',mkevt:'1',
});
// Public identifiers preserved verbatim from the user's CDJapan-generated HTML.
// CDJapan's official FAQ permits changing the encoded destination in this format.
export const cdjapanAffiliate = Object.freeze({linkId:'PytJTGW7Lok',siteId:'7898',affiliateId:'A934864'});
const cdjapanPrefix = `https://www.cdjapan.co.jp/aff/click.cgi/${cdjapanAffiliate.linkId}/${cdjapanAffiliate.siteId}/${cdjapanAffiliate.affiliateId}/`;
const firstFigureLink = "https://www.ebay.com/itm/197978173286?amdata=enc%3AAQALAAAAoCHNgUiiE%2FjQhlDTaMiAde8CPowlDLT8dPhY%2F4DrYahoehOvU7P%2Fk72kQx4T3Nu8BEI2%2FPj8UBvaXwh%2B3eeOoi3SD5TUXGeumiZjVilPSr3JZhnPn85Y%2FXrAdhDMZt%2BqZzZHYV2nHQUEGdUCqsPiRm2wX3OYW7qSQTngNwQwo2xIkGAenfv7Y7nq%2BdsGd%2FGM1jTv3ymofa4LBhvF6Fib7pw%3D&mkcid=1&mkrid=711-53200-19255-0&siteid=0&campid=5339230513&customid=nexorifirstfigure&toolid=10001&mkevt=1";
const trackingKeys = [...Object.keys(ebayCampaign),'customid','amdata'];

export function retailerDestination(product) {
  let url;
  try {url=new URL(product.sourceUrl);} catch {return {url:'',affiliate:false,customId:''};}
  if(url.protocol!=='https:'||url.username||url.password)return {url:'',affiliate:false,customId:''};
  const regular={url:product.sourceUrl,affiliate:false,customId:''};
  if(product.retailer==='CDJapan' && url.hostname==='www.cdjapan.co.jp'
    && /^\/product\/[A-Z][A-Z0-9]*-\d+$/.test(url.pathname) && !url.search && !url.hash) {
    return {url:cdjapanPrefix+encodeURIComponent(url.pathname.slice(1)),affiliate:true,customId:''};
  }
  // Only US eBay item listings use the EPN campaign template.

  if(product.retailer!=='eBay'||!['www.ebay.com','ebay.com'].includes(url.hostname)||!/^\/itm\/(?:[^/]+\/)?\d{9,15}\/?$/.test(url.pathname))return regular;
  if(url.pathname==='/itm/197978173286'&&url.search===''&&url.hash==='')return {url:firstFigureLink,affiliate:true,customId:'nexorifirstfigure'};
  // Keep item/variation parameters; never copy a different listing's amdata token.
  for(const key of trackingKeys)url.searchParams.delete(key);
  for(const [key,value] of Object.entries(ebayCampaign))url.searchParams.set(key,value);
  const customId=`nexori-${product.id}`.replace(/[^a-zA-Z0-9_-]/g,'-').slice(0,256);
  url.searchParams.set('customid',customId);
  return {url:url.href,affiliate:true,customId};
}

export function productPurchaseTips(product) {
  if(product.retailer!=='eBay'||!retailerDestination(product).affiliate)return product.tips;
  return product.tips.map(tip=>tip.replace(/Image publication permissions? and affiliate acceptance remain pending\./g,'Image publication permissions remain pending.'));
}

// CDJapan displayed JPY 5,100 as US$32.35 on the source date.
// Reference estimate only, not a bank/card settlement rate.
export const yenReference = Object.freeze({jpy:5100,usd:32.35,date:'2026-10-28',source:'https://www.cdjapan.co.jp/product/NEOGDS-937972'});
export function usdEstimate(price,currency='USD') {
  const amount=Number(price);
  if(currency!=='JPY'||!Number.isFinite(amount)||amount<0)return null;
  return amount*yenReference.usd/yenReference.jpy;
}
export function formatProductPrice(product) {
  if(product.price===''||product.price==null)return 'Check price at retailer';
  const currency=product.currency||'USD',amount=Number(product.price);
  if(!Number.isFinite(amount)||amount<0)return 'Check price at retailer';
  const original=new Intl.NumberFormat('en-US',{style:'currency',currency,currencyDisplay:currency==='JPY'?'code':'symbol'}).format(amount);
  const usd=usdEstimate(amount,currency);
  return (product.priceFrom?'From ':'')+original+(usd===null?'':` (≈ US$${usd.toFixed(2)})`);
}

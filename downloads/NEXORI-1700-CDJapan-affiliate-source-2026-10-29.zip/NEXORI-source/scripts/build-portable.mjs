import {execFileSync} from 'node:child_process';
import {readFile,readdir,mkdir,copyFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {buildFirebaseHtml,isPublicArtwork} from './build-firebase-html.mjs';
import {products} from '../src/data.js';
import {optimizedArtwork} from '../src/optimized-artwork.js';
const root=fileURLToPath(new URL('../',import.meta.url)),dest=path.join(root,`.firebase/portable-${products.length}`);
await mkdir(path.join(dest,'assets'),{recursive:true});
await writeFile(path.join(root,'.firebase/delivery-image-jobs.json'),JSON.stringify(products.map(p=>({key:p.art,src:optimizedArtwork[p.art].src}))));
execFileSync('python3',[path.join(root,'scripts/prepare-delivery-images.py')],{cwd:root,stdio:'inherit'});
const delivery=Object.fromEntries(JSON.parse(await readFile(path.join(root,'.firebase/delivery-image-evidence.json'),'utf8')).map(r=>[r.key,r]));
const art={},responsiveAssets={};let bytes=0;
for(const name of await readdir(path.join(root,'public/assets'))){
 const ext=path.extname(name);if(!['.svg','.png','.jpg','.jpeg','.webp'].includes(ext))continue;
 const key=path.basename(name,ext),optimized=optimizedArtwork[key];
 if(!isPublicArtwork(key))continue;
 const source=delivery[key]?.path || (optimized?path.join(root,'public',optimized.src.slice(1)):path.join(root,'public/assets',name));
 const filename=key+path.extname(source);art[key]='assets/'+filename;
 await copyFile(source,path.join(dest,'assets',filename));bytes+=(await readFile(source)).length;
 if(optimized){responsiveAssets[key]={...optimized,src:art[key],...(delivery[key]?{width:delivery[key].width,height:delivery[key].height}:{})};if(optimized.small){
   const smallName=path.basename(optimized.small),smallSource=path.join(root,'public',optimized.small.slice(1));
   await copyFile(smallSource,path.join(dest,'assets',smallName));bytes+=(await readFile(smallSource)).length;
   responsiveAssets[key].small='assets/'+smallName;
 }}
}
const html=await buildFirebaseHtml(await readFile(path.join(root,'index.html'),'utf8'),art,{responsiveAssets});
if(!html.includes('nexori-development')||html.includes('nexori-2a8e1'))throw new Error('Incorrect public Firebase project');
await writeFile(path.join(dest,`NEXORI-${products.length}-products.html`),html);
console.log(JSON.stringify({folder:dest,htmlBytes:Buffer.byteLength(html),images:Object.keys(art).length,imageBytes:bytes}));

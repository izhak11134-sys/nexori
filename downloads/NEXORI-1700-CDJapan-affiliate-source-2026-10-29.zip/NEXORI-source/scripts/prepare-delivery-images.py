"""Smaller full-size product photos for the upload folder; source files stay intact."""
from pathlib import Path
from PIL import Image,ImageOps
from concurrent.futures import ThreadPoolExecutor
import json,io,hashlib
root=Path(__file__).resolve().parent.parent
jobs=json.loads((root/'.firebase/delivery-image-jobs.json').read_text());dest=root/'.firebase/delivery-images';dest.mkdir(exist_ok=True)
def prepare(job):
 source=root/'public'/job['src'].lstrip('/');target=dest/(job['key']+'.webp');data=source.read_bytes();metadata=target.with_suffix('.json');sha=hashlib.sha256(data).hexdigest()
 if metadata.exists() and target.exists():
  old=json.loads(metadata.read_text())
  if old.get('sourceSha256')==sha:
   if 'width' not in old:
    with Image.open(target) as delivered:old.update(width=delivered.width,height=delivered.height)
    metadata.write_text(json.dumps(old))
   return old
 with Image.open(io.BytesIO(data)) as opened:
  originalsize=opened.size;image=ImageOps.exif_transpose(opened).convert('RGBA' if 'A' in opened.getbands() else 'RGB');image.thumbnail((720,1000),Image.Resampling.LANCZOS);out=io.BytesIO();image.save(out,'WEBP',quality=78,method=6);optimized=out.getvalue()
 # Never enlarge a small, already efficiently encoded source.
 chosen=optimized if len(optimized)<len(data) else data;target.write_bytes(chosen)
 result={'key':job['key'],'sourceSha256':sha,'sourceBytes':len(data),'deliveryBytes':len(chosen),'width':image.width if chosen is optimized else originalsize[0],'height':image.height if chosen is optimized else originalsize[1],'path':str(target),'profile':'720x1000 WebP q78, original retained if smaller'};metadata.write_text(json.dumps(result));return result
with ThreadPoolExecutor(3) as pool:rows=list(pool.map(prepare,jobs))
(root/'.firebase/delivery-image-evidence.json').write_text(json.dumps(rows,indent=2));print(json.dumps({'files':len(rows),'sourceBytes':sum(x['sourceBytes'] for x in rows),'deliveryBytes':sum(x['deliveryBytes'] for x in rows)}))

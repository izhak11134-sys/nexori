import { writeFile } from 'node:fs/promises';
import { contentGroups, contentFields } from '../src/content.js';
import { schemaChunks, validationChunks, receiptChunks, rootChunks } from '../src/spark-content.js';

const quote=JSON.stringify;
for(const {records} of Object.values(contentGroups))for(const {id} of records)if(/[|~]/.test(id)||id==='__nexori_no_card__')throw new Error('Reserved character in content ID');
const compactIds=ids=>ids.map(id=>id.replace(/^expand-ebay-/, '~e').replace(/^expand-ht-/, '~h').replace(/^a28-/, '~n').replace(/^more-ebay-/, '~m').replace(/^more-cdjapan-neogds-/, '~c')).join('|');
const expandedIds=expression=>`(${expression}).replace('~e','expand-ebay-').replace('~h','expand-ht-').replace('~n','a28-').replace('~m','more-ebay-').replace('~c','more-cdjapan-neogds-').split('[|]')`;
if(rootChunks.length>8 || rootChunks.some(root=>root.receipts.length>8) || receiptChunks.some(receipt=>receipt.chunks.length>8))throw new Error('The expanded schema exceeds Firestore rule access limits. Redesign and test validation before publishing rules.');
const functions=Object.entries(contentGroups).map(([group,{records}])=>{
  const fields=contentFields[group],publicFields=fields.filter(field=>!['editorNotes','retailerUrl'].includes(field));
  const images=fields.filter(field=>/image$/i.test(field));
  return `    function patch_${group}(p, allowed, pattern) {
      return p is map && p.keys().hasOnly(allowed)${images.map(field=>`\n        && p.get(${quote(field)}, '').matches(pattern)`).join('')};
    }`;
}).join('\n');
// Split one constant string instead of evaluating hundreds of list literals.
// This preserves the exact ID whitelist within Firestore's expression budget.
const knownFunctions=Object.entries(contentGroups).filter(([group])=>group!=='products').map(([group,{records}])=>`    function known_${group}(r) {return r is map && r.keys().hasOnly(${expandedIds(quote(compactIds(records.map(record=>record.id))))});}`).join('\n');
const productChunks=validationChunks.filter(chunk=>chunk.group==='products');
const otherChunks=validationChunks.filter(chunk=>chunk.group!=='products');
const productWidth=Math.max(...productChunks.map(chunk=>chunk.ids.length));
// Pass the exact schema IDs as data to a single fixed-width validator. Expanding
// one validator per catalogue chunk exceeds the production compiled-rules limit.
const productIdList = compactIds(contentGroups.products.records.map(record=>record.id));
const productIdsFunction = `    function product_ids() {return ${expandedIds(quote(productIdList))};}
    function known_products(r) {return r is map && r.keys().hasOnly(product_ids());}`;
const productFunction=`    function chunk_products(r, published, pattern, ids, offset) {
      let allowed = published ? ${quote(contentFields.products.filter(field=>!['editorNotes','retailerUrl'].includes(field)))} : ${quote(contentFields.products)};
      return r is map && r.keys().hasOnly(ids)${Array.from({length:productWidth},(_,i)=>`\n        && (offset + ${i} >= ids.size() || !(ids[offset + ${i}] in r) || patch_products(r[ids[offset + ${i}]], allowed, pattern))`).join('')};
    }`;
const chunkFunctions=otherChunks.map(chunk=>`    function chunk_${chunk.id.replace('-','_')}(r, ${chunk.group==='products'?'published, ':''}pattern) {
      let allowed = ${chunk.group==='products'?`published ? ${quote(contentFields[chunk.group].filter(field=>!['editorNotes','retailerUrl'].includes(field)))} : ${quote(contentFields[chunk.group])}`:quote(contentFields[chunk.group])};
      return known_${chunk.group}(r)${chunk.ids.map(id=>`\n        && (!(${quote(id)} in r) || patch_${chunk.group}(r[${quote(id)}], allowed, pattern))`).join('')};
    }`).join('\n');
const groupDispatch=chunks=>{
  if(chunks.length===1){const chunk=chunks[0];return `(group == ${quote(chunk.id)} && chunk_${chunk.id.replace('-','_')}(records, ${chunk.group==='products'?'published, ':''}pattern))`;}
  const middle=Math.ceil(chunks.length/2),left=chunks.slice(0,middle),right=chunks.slice(middle);
  return `(group in ${quote(left.map(chunk=>chunk.id))} ? ${groupDispatch(left)} : ${groupDispatch(right)})`;
};
const groups=Object.keys(contentGroups);
const proofFunctions=[...receiptChunks.map(receipt=>`    function proof_${receipt.id.replaceAll('-','_')}(r, version, published) {
      return r is map && r.keys().hasOnly(${quote(receipt.groups)})${receipt.chunks.map(chunk=>`\n        && proofRecords('groups', ${quote(chunk.id)}, version, published) == r.get(${quote(chunk.group)}, {})`).join('')};
    }`),...rootChunks.map(root=>`    function proof_${root.id.replaceAll('-','_')}(r, version, published) {
      return r is map && r.keys().hasOnly(${quote(root.groups)})${root.receipts.map(receipt=>`\n        && proofRecords('proofs', ${quote(receipt.id)}, version, published) == {${receipt.groups.map(group=>`${quote(group)}: r.get(${quote(group)}, {})`).join(', ')}}`).join('')};
    }`)].join('\n');
const receiptPayload=receipt=>`{${receipt.groups.map(group=>`${quote(group)}: d.payload.changes.get(${quote(group)}, {})`).join(', ')}}`;

const rules=`// Generated by scripts/build-firestore-rules.mjs from the approved card schema.
// Auth + Firestore only. No Functions, Storage or billing activation.
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function owner() {
      return request.auth != null && request.auth.token.email_verified == true
        && get(/databases/$(database)/documents/admins/$(request.auth.uid)).data.active == true;
    }
    function uuid(id) { return id is string && id.matches('[a-f0-9-]{36}'); }
${functions}
${knownFunctions}
${productIdsFunction}
${productFunction}
${chunkFunctions}
    function proofRecords(kind, id, version, published) {
      return get(published ? /databases/$(database)/documents/publishedContent/$(version)/$(kind)/$(id) : /databases/$(database)/documents/draftContent/$(request.auth.uid)/versions/$(version)/$(kind)/$(id)).data.records;
    }
${proofFunctions}
    function payloadHeader(p) {
      return p is map && p.keys().hasOnly(['version', 'changes']) && p.version == 1
        && p.changes is map && p.changes.keys().hasOnly(${quote(groups)})${Object.entries(contentGroups).map(([group,{records}])=>`\n        && known_${group}(p.changes.get(${quote(group)}, {}))`).join('')};
    }
    function groupData(group, records, published) {
      let pattern = published ? '(|spark:published/[a-f0-9-]{36}/[a-f0-9-]{36})'
        : '(|spark:published/[a-f0-9-]{36}/[a-f0-9-]{36}|spark:drafts/' + request.auth.uid + '/[a-f0-9-]{36})';
      return group in ${quote(productChunks.map(chunk=>chunk.id).join('|'))}.split('[|]')
        ? chunk_products(records, published, pattern, product_ids(), int(group.replace('products-', '')) * ${productWidth})
        : ${groupDispatch(otherChunks)};
    }
    function draftEnvelope() {
      let d = request.resource.data;
      return d.keys().hasOnly(['payload', 'revision', 'draftId', 'updatedAt', 'updatedBy'])
        && d.revision is int && d.updatedBy == request.auth.uid && d.updatedAt == request.time
        && uuid(d.draftId) && payloadHeader(d.payload)${rootChunks.map(receipt=>`\n        && get(/databases/$(database)/documents/draftContent/$(request.auth.uid)/versions/$(d.draftId)/proofs/${receipt.id}).data.records == ${receiptPayload(receipt)}`).join('')};
    }
    function publicEnvelope() {
      let d = request.resource.data;
      let release = getAfter(/databases/$(database)/documents/mediaReleases/$(d.revisionId)).data;
      return d.keys().hasOnly(['payload', 'revision', 'revisionId', 'updatedAt'])
        && d.revision is int && uuid(d.revisionId) && d.updatedAt == request.time
        && payloadHeader(d.payload) && release.revision == d.revision${rootChunks.map(receipt=>`\n        && get(/databases/$(database)/documents/publishedContent/$(d.revisionId)/proofs/${receipt.id}).data.records == ${receiptPayload(receipt)}`).join('')};
    }
    function proofData(proof, records, version, published) {
      return ${[...receiptChunks,...rootChunks].map(receipt=>`(proof == ${quote(receipt.id)} && proof_${receipt.id.replaceAll('-','_')}(records, version, published))`).join('\n        || ')};
    }
    function imageData() {
      let d = request.resource.data;
      return d.bytes is bytes && d.bytes.size() > 0 && d.bytes.size() <= 196608
        && d.mime == 'image/webp' && d.createdAt == request.time;
    }
    match /admins/{uid} {
      allow get: if request.auth != null && request.auth.uid == uid;
      allow list, write: if false;
    }
    match /cms/draft {
      allow read: if owner();
      allow create: if owner() && draftEnvelope() && request.resource.data.revision == 1;
      allow update: if owner() && draftEnvelope() && request.resource.data.revision == resource.data.revision + 1;
      allow delete: if false;
    }
    match /draftContent/{uid}/versions/{version}/groups/{group} {
      allow read: if owner() && request.auth.uid == uid;
      allow create: if owner() && request.auth.uid == uid && uuid(version)
        && request.resource.data.keys().hasOnly(['records', 'createdAt'])
        && request.resource.data.createdAt == request.time
        && groupData(group, request.resource.data.records, false);
      allow update, delete: if false;
    }
    match /draftContent/{uid}/versions/{version}/proofs/{proof} {
      allow read: if owner() && request.auth.uid == uid;
      allow create: if owner() && request.auth.uid == uid && uuid(version)
        && request.resource.data.keys().hasOnly(['records', 'createdAt'])
        && request.resource.data.createdAt == request.time
        && proofData(proof, request.resource.data.records, version, false);
      allow update, delete: if false;
    }
    match /publishedContent/{release}/proofs/{proof} {
      allow read: if exists(/databases/$(database)/documents/mediaReleases/$(release));
      allow create: if owner() && uuid(release)
        && request.resource.data.keys().hasOnly(['records', 'createdAt'])
        && request.resource.data.createdAt == request.time
        && proofData(proof, request.resource.data.records, release, true)
        && !exists(/databases/$(database)/documents/mediaReleases/$(release));
      allow update, delete: if false;
    }
    match /publishedContent/{release}/groups/{group} {
      allow read: if exists(/databases/$(database)/documents/mediaReleases/$(release));
      allow create: if owner() && uuid(release)
        && request.resource.data.keys().hasOnly(['records', 'createdAt'])
        && request.resource.data.createdAt == request.time
        && groupData(group, request.resource.data.records, true)
        && !exists(/databases/$(database)/documents/mediaReleases/$(release));
      allow update, delete: if false;
    }
    match /public/site {
      allow read: if true;
      allow create: if owner() && publicEnvelope() && request.resource.data.revision == 1;
      allow update: if owner() && publicEnvelope() && request.resource.data.revision == resource.data.revision + 1;
      allow delete: if false;
    }
    match /revisions/{id} {
      allow read: if owner();
      allow create: if owner()
        && request.resource.data.keys().hasOnly(['payload', 'revision', 'createdAt', 'kind'])
        && request.resource.data.createdAt == request.time
        && ((id == 'initial' && !exists(/databases/$(database)/documents/public/site)
          && getAfter(/databases/$(database)/documents/public/site).data.revision == 1
          && request.resource.data.revision == 0 && request.resource.data.kind == 'initial'
          && request.resource.data.payload == {'version': 1, 'changes': {}})
        || (uuid(id) && request.resource.data.kind in ['publish', 'restore']
          && getAfter(/databases/$(database)/documents/public/site).data.revisionId == id
          && getAfter(/databases/$(database)/documents/public/site).data.revision == request.resource.data.revision
          && getAfter(/databases/$(database)/documents/public/site).data.payload == request.resource.data.payload));
      allow update, delete: if false;
    }
    match /mediaReleases/{id} {
      allow read: if owner();
      allow create: if owner() && uuid(id)
        && request.resource.data.keys().hasOnly(['revision', 'createdAt'])
        && request.resource.data.createdAt == request.time
        && getAfter(/databases/$(database)/documents/public/site).data.revisionId == id
        && getAfter(/databases/$(database)/documents/public/site).data.revision == request.resource.data.revision
        && getAfter(/databases/$(database)/documents/revisions/$(id)).data.revision == request.resource.data.revision
        && getAfter(/databases/$(database)/documents/revisions/$(id)).data.payload == getAfter(/databases/$(database)/documents/public/site).data.payload;
      allow update, delete: if false;
    }
    match /draftImages/{uid}/images/{id} {
      allow read: if owner() && request.auth.uid == uid;
      allow create: if owner() && request.auth.uid == uid && uuid(id) && imageData()
        && request.resource.data.keys().hasOnly(['bytes', 'mime', 'createdAt']);
      allow update, delete: if false;
    }
    match /publishedImages/{release}/images/{id} {
      allow read: if exists(/databases/$(database)/documents/mediaReleases/$(release));
      allow create: if owner() && uuid(release) && uuid(id) && imageData()
        && request.resource.data.keys().hasOnly(['bytes', 'mime', 'sourceId', 'createdAt'])
        && uuid(request.resource.data.sourceId)
        && !exists(/databases/$(database)/documents/mediaReleases/$(release))
        && request.resource.data.bytes == get(/databases/$(database)/documents/draftImages/$(request.auth.uid)/images/$(request.resource.data.sourceId)).data.bytes;
      allow update, delete: if false;
    }
    match /{document=**} { allow read, write: if false; }
  }
}
`;
await writeFile(new URL('../firestore.rules',import.meta.url),rules);
console.log('Generated Spark-only Firestore rules for the approved cards.');

// Visitor-only checks. External requests (including Firebase) are blocked.
const assert=require('node:assert/strict');
const {readFileSync}=require('node:fs');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const baseline=JSON.parse(readFileSync(__dirname+'/../fixtures/catalog-retirement.json','utf8'));
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 try{
  const context=await browser.newContext({viewport:{width:1440,height:1000}}),errors=[];
  await context.route(/^https?:/,r=>['127.0.0.1','localhost'].includes(new URL(r.request().url()).hostname)?r.continue():r.abort());
  await context.route('**/src/firebase-config.js*',r=>r.fulfill({contentType:'application/javascript',body:'export function firebaseConfiguration(){return null;}'}));
  await context.addInitScript(()=>localStorage.setItem('nexori.saved.v1',JSON.stringify(['midnight-ronin','moonlight-blade'])));
  const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
  const base=process.env.SITE_URL||'http://127.0.0.1:5199',standalone=base.endsWith('.html');
  const go=async path=>{await page.goto(standalone?base+'#'+path:base+path);await page.locator('#main').waitFor();};
  await go('/');assert.equal(await page.locator('.world-card').count(),14);
  const decode=async()=>{const bad=await page.locator('main img').evaluateAll(async list=>(await Promise.all(list.map(async img=>{try{img.loading='eager';await img.decode();return img.naturalWidth>0?null:img.src;}catch{return img.src;}}))).filter(Boolean));assert.deepEqual(bad,[]);};
  await decode();
  await go('/collection');await page.locator('.product-card').first().waitFor();
  const ids=await page.locator('.product-card').evaluateAll(list=>list.map(el=>el.dataset.contentId));
  assert.deepEqual(ids,baseline.activeIds);assert.equal(ids.length,1042);
  assert.match(await page.locator('#result-count').innerText(),/^1042 finds/);
  assert((await page.locator('.product-card-info>.tiny-label').allTextContents()).every(text=>text.endsWith(' · eBay')));
  assert.equal(await page.locator('a[href*="hottopic.com"]').count(),0);
  assert.equal(await page.locator('#collection-world option').count(),15); // All + 14 anime, no empty original-concepts option.
  await page.locator('#collection-world').selectOption('one-piece');
  await page.waitForFunction(()=>document.querySelectorAll('.product-card').length===21);
  await page.locator('[data-category="figures"]').click();await page.locator('#collection-grid .empty-state').waitFor();assert.match(await page.locator('#collection-grid').innerText(),/No current eBay listings/);
  await page.locator('[data-category="props"]').click();await page.waitForFunction(()=>document.querySelectorAll('.product-card').length===21);
  await go('/saved');await page.locator('.product-card').waitFor();assert.equal(await page.locator('.product-card').count(),1);assert.equal(await page.locator('.product-card').getAttribute('data-content-id'),'moonlight-blade');
  await go('/product/midnight-ronin');await page.getByRole('heading',{name:'This page wandered off.'}).waitFor();assert.equal(await page.locator('.retail-offer').count(),0);
  await go('/worlds');assert.equal(await page.locator('.world-card').count(),14);
  for(const width of [390,1440]){await page.setViewportSize({width,height:900});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);}
  assert.deepEqual(errors,[]);
  console.log('PASS '+(standalone?'portable':'source')+': exact 1042 active products, no retired cards, intact homepage images, 14 worlds, updated counts, empty combination, favorites cleanup, removed URL and mobile layout.');
  await context.close();
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});

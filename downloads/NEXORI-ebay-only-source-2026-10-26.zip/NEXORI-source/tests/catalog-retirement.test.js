import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {products,productRecords} from '../src/data.js';
import {applyContentDraft,contentBlocks,publicCatalogContent} from '../src/content.js';
import {validationChunks,receiptChunks,rootChunks,sparkContent,imageEntries} from '../src/spark-content.js';
const baseline=JSON.parse(await readFile(new URL('./fixtures/catalog-retirement.json',import.meta.url)));

test('only the 1042 original eBay records are public; 708 reserved slots contain no old listing content',()=>{
 assert.deepEqual(products.map(p=>p.id),baseline.activeIds);
 assert(products.every(p=>p.retailer==='eBay'&&!p.retired));
 assert.equal(productRecords.length,1750);
 const retired=productRecords.filter(p=>p.retired);assert.deepEqual(retired.map(p=>p.id),baseline.retiredIds);
 for(const p of retired)for(const key of ['sourceUrl','art','image','productPhoto','description','seller','retailer'])assert(!Object.hasOwn(p,key));
});

test('schema chunks and proofs remain identical to the deployed 1750-slot schema',()=>{
 assert.deepEqual({validationChunks,receiptChunks,rootChunks},baseline.schema);
});

test('old cloud content retains the banner and active edits without exposing or downloading retired product images',()=>{
 const image='spark:published/11111111-1111-1111-1111-111111111111/22222222-2222-2222-2222-222222222222';
 const old={version:1,changes:{blocks:{hero:{lead:'Saved banner'}},products:{'midnight-ronin':{name:'Hidden former listing',image},'moonlight-blade':{name:'Saved active listing'}}}};
 const display=publicCatalogContent(sparkContent(old,undefined,true));
 assert.equal(display.changes.products['midnight-ronin'],undefined);assert.equal(imageEntries(display).length,0);
 assert.equal(old.changes.products['midnight-ronin'].image,image);
 applyContentDraft(display);assert.equal(contentBlocks.hero.lead,'Saved banner');assert.equal(products.find(p=>p.id==='moonlight-blade').name,'Saved active listing');
 assert(!products.some(p=>p.name==='Hidden former listing'));
 applyContentDraft({version:1,changes:{}});
});

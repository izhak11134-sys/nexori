import{u as Cu,_ as Su,v as Nu,i as Sa,p as Du,d as ku,w as Lu,g as Pe,L as Ou,b as Fe,F as Mu,I as gt,x as Uu,o as Fu,M as qu,y as Bu,z as $u,X as zu,A as ju,B as Qr,W as Yn,G as Gu,a as Ku,H as bi,n as Wu,C as Qu,r as Ci,S as Hu}from"./firebase-core-qkisiWiA.js";import{_ as te,R as Es}from"./index-CK3NOHgz.js";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Gt="13.0.0";function Yu(r){Gt=r}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const wt=new Ou("@firebase/firestore");function Ct(){return wt.logLevel}function w(r,...e){if(wt.logLevel<=Fe.DEBUG){const t=e.map(Ts);wt.debug(`Firestore (${Gt}): ${r}`,...t)}}function Ge(r,...e){if(wt.logLevel<=Fe.ERROR){const t=e.map(Ts);wt.error(`Firestore (${Gt}): ${r}`,...t)}}function xe(r,...e){if(wt.logLevel<=Fe.WARN){const t=e.map(Ts);wt.warn(`Firestore (${Gt}): ${r}`,...t)}}function Ts(r){if(typeof r=="string")return r;try{return(function(t){return JSON.stringify(t)})(r)}catch{return r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function A(r,e,t){let n="Unexpected state";typeof e=="string"?n=e:t=e,Na(r,n,t)}function Na(r,e,t){let n=`FIRESTORE (${Gt}) INTERNAL ASSERTION FAILED: ${e} (ID: ${r.toString(16)})`;if(t!==void 0)try{n+=" CONTEXT: "+JSON.stringify(t)}catch{n+=" CONTEXT: "+t}throw Ge(n),new Error(n)}function I(r,e,t,n){let s="Unexpected state";typeof t=="string"?s=t:n=t,r||Na(e,s,n)}function S(r,e){return r}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xu(r){const e=typeof self<"u"&&(self.crypto||self.msCrypto),t=new Uint8Array(r);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(t);else for(let n=0;n<r;n++)t[n]=Math.floor(256*Math.random());return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ws{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=62*Math.floor(4.129032258064516);let n="";for(;n.length<20;){const s=Xu(40);for(let i=0;i<s.length;++i)n.length<20&&s[i]<t&&(n+=e.charAt(s[i]%62))}return n}}function N(r,e){return r<e?-1:r>e?1:0}function gn(r,e){const t=Math.min(r.length,e.length);for(let n=0;n<t;n++){const s=r.charAt(n),i=e.charAt(n);if(s!==i)return Hr(s)===Hr(i)?N(s,i):Hr(s)?1:-1}return N(r.length,e.length)}const Ju=55296,Zu=57343;function Hr(r){const e=r.charCodeAt(0);return e>=Ju&&e<=Zu}function Ft(r,e,t){return r.length===e.length&&r.every(((n,s)=>t(n,e[s])))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class q{constructor(e,t){this.comparator=e,this.root=t||ne.EMPTY}insert(e,t){return new q(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,ne.BLACK,null,null))}remove(e){return new q(this.comparator,this.root.remove(e,this.comparator).copy(null,null,ne.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const n=this.comparator(e,t.key);if(n===0)return t.value;n<0?t=t.left:n>0&&(t=t.right)}return null}indexOf(e){let t=0,n=this.root;for(;!n.isEmpty();){const s=this.comparator(e,n.key);if(s===0)return t+n.left.size;s<0?n=n.left:(t+=n.left.size+1,n=n.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal(((t,n)=>(e(t,n),!1)))}toString(){const e=[];return this.inorderTraversal(((t,n)=>(e.push(`${t}:${n}`),!1))),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new Xn(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new Xn(this.root,e,this.comparator,!1)}getReverseIterator(){return new Xn(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new Xn(this.root,e,this.comparator,!0)}}class Xn{constructor(e,t,n,s){this.isReverse=s,this.nodeStack=[];let i=1;for(;!e.isEmpty();)if(i=t?n(e.key,t):1,t&&s&&(i*=-1),i<0)e=this.isReverse?e.left:e.right;else{if(i===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}}class ne{constructor(e,t,n,s,i){this.key=e,this.value=t,this.color=n??ne.RED,this.left=s??ne.EMPTY,this.right=i??ne.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,n,s,i){return new ne(e??this.key,t??this.value,n??this.color,s??this.left,i??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,n){let s=this;const i=n(e,s.key);return s=i<0?s.copy(null,null,null,s.left.insert(e,t,n),null):i===0?s.copy(null,t,null,null,null):s.copy(null,null,null,null,s.right.insert(e,t,n)),s.fixUp()}removeMin(){if(this.left.isEmpty())return ne.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let n,s=this;if(t(e,s.key)<0)s.left.isEmpty()||s.left.isRed()||s.left.left.isRed()||(s=s.moveRedLeft()),s=s.copy(null,null,null,s.left.remove(e,t),null);else{if(s.left.isRed()&&(s=s.rotateRight()),s.right.isEmpty()||s.right.isRed()||s.right.left.isRed()||(s=s.moveRedRight()),t(e,s.key)===0){if(s.right.isEmpty())return ne.EMPTY;n=s.right.min(),s=s.copy(n.key,n.value,null,null,s.right.removeMin())}s=s.copy(null,null,null,null,s.right.remove(e,t))}return s.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,ne.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,ne.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw A(43730,{key:this.key,value:this.value});if(this.right.isRed())throw A(14113,{key:this.key,value:this.value});const e=this.left.check();if(e!==this.right.check())throw A(27949);return e+(this.isRed()?0:1)}}ne.EMPTY=null,ne.RED=!0,ne.BLACK=!1;ne.EMPTY=new class{constructor(){this.size=0}get key(){throw A(57766)}get value(){throw A(16141)}get color(){throw A(16727)}get left(){throw A(29726)}get right(){throw A(36894)}copy(e,t,n,s,i){return this}insert(e,t,n){return new ne(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class W{constructor(e){this.comparator=e,this.data=new q(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal(((t,n)=>(e(t),!1)))}forEachInRange(e,t){const n=this.data.getIteratorFrom(e[0]);for(;n.hasNext();){const s=n.getNext();if(this.comparator(s.key,e[1])>=0)return;t(s.key)}}forEachWhile(e,t){let n;for(n=t!==void 0?this.data.getIteratorFrom(t):this.data.getIterator();n.hasNext();)if(!e(n.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new Si(this.data.getIterator())}getIteratorFrom(e){return new Si(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach((n=>{t=t.add(n)})),t}isEqual(e){if(!(e instanceof W)||this.size!==e.size)return!1;const t=this.data.getIterator(),n=e.data.getIterator();for(;t.hasNext();){const s=t.getNext().key,i=n.getNext().key;if(this.comparator(s,i)!==0)return!1}return!0}toArray(){const e=[];return this.forEach((t=>{e.push(t)})),e}toString(){const e=[];return this.forEach((t=>e.push(t))),"SortedSet("+e.toString()+")"}copy(e){const t=new W(this.comparator);return t.data=e,t}}class Si{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const p={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class y extends Mu{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Se="__name__";class Ce{constructor(e,t,n){t===void 0?t=0:t>e.length&&A(637,{offset:t,range:e.length}),n===void 0?n=e.length-t:n>e.length-t&&A(1746,{length:n,range:e.length-t}),this.segments=e,this.offset=t,this.len=n}get length(){return this.len}isEqual(e){return Ce.comparator(this,e)===0}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof Ce?e.forEach((n=>{t.push(n)})):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,n=this.limit();t<n;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const n=Math.min(e.length,t.length);for(let s=0;s<n;s++){const i=Ce.compareSegments(e.get(s),t.get(s));if(i!==0)return i}return N(e.length,t.length)}static compareSegments(e,t){const n=Ce.isNumericId(e),s=Ce.isNumericId(t);return n&&!s?-1:!n&&s?1:n&&s?Ce.extractNumericId(e).compare(Ce.extractNumericId(t)):gn(e,t)}static isNumericId(e){return e.startsWith("__id")&&e.endsWith("__")}static extractNumericId(e){return gt.fromString(e.substring(4,e.length-2))}}class L extends Ce{construct(e,t,n){return new L(e,t,n)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toStringWithLeadingSlash(){return`/${this.canonicalString()}`}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const t=[];for(const n of e){if(n.indexOf("//")>=0)throw new y(p.INVALID_ARGUMENT,`Invalid segment (${n}). Paths must not contain // in them.`);t.push(...n.split("/").filter((s=>s.length>0)))}return new L(t)}static emptyPath(){return new L([])}}const ec=/^[_a-zA-Z][_a-zA-Z0-9]*$/;let Te=class St extends Ce{construct(e,t,n){return new St(e,t,n)}static isValidIdentifier(e){return ec.test(e)}canonicalString(){return this.toArray().map((e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),St.isValidIdentifier(e)||(e="`"+e+"`"),e))).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)===Se}static keyField(){return new St([Se])}static fromServerFormat(e){const t=[];let n="",s=0;const i=()=>{if(n.length===0)throw new y(p.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(n),n=""};let a=!1;for(;s<e.length;){const o=e[s];if(o==="\\"){if(s+1===e.length)throw new y(p.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const u=e[s+1];if(u!=="\\"&&u!=="."&&u!=="`")throw new y(p.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);n+=u,s+=2}else o==="`"?(a=!a,s++):o!=="."||a?(n+=o,s++):(i(),s++)}if(i(),a)throw new y(p.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new St(t)}static emptyPath(){return new St([])}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ye{constructor(e){this.fields=e,e.sort(Te.comparator)}static empty(){return new ye([])}unionWith(e){let t=new W(Te.comparator);for(const n of this.fields)t=t.add(n);for(const n of e)t=t.add(n);return new ye(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return Ft(this.fields,e.fields,((t,n)=>t.isEqual(n)))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function It(r){let e=0;for(const t in r)Object.prototype.hasOwnProperty.call(r,t)&&e++;return e}function ft(r,e){for(const t in r)Object.prototype.hasOwnProperty.call(r,t)&&e(t,r[t])}function tc(r,e){const t=[];for(const n in r)Object.prototype.hasOwnProperty.call(r,n)&&t.push(e(r[n],n,r));return t}function Da(r){for(const e in r)if(Object.prototype.hasOwnProperty.call(r,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class V{constructor(e){this.path=e}static fromPath(e){return new V(L.fromString(e))}static fromName(e){return new V(L.fromString(e).popFirst(5))}static empty(){return new V(L.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&L.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,t){return L.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new V(new L(e.slice()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ka(r,e,t){if(!t)throw new y(p.INVALID_ARGUMENT,`Function ${r}() cannot be called with an empty ${e}.`)}function nc(r,e,t,n){if(e===!0&&n===!0)throw new y(p.INVALID_ARGUMENT,`${r} and ${t} cannot be used together.`)}function Ni(r){if(!V.isDocumentKey(r))throw new y(p.INVALID_ARGUMENT,`Invalid document reference. Document references must have an even number of segments, but ${r} has ${r.length}.`)}function Di(r){if(V.isDocumentKey(r))throw new y(p.INVALID_ARGUMENT,`Invalid collection reference. Collection references must have an odd number of segments, but ${r} has ${r.length}.`)}function Un(r){return typeof r=="object"&&r!==null&&(Object.getPrototypeOf(r)===Object.prototype||Object.getPrototypeOf(r)===null)}function Rr(r){if(r===void 0)return"undefined";if(r===null)return"null";if(typeof r=="string")return r.length>20&&(r=`${r.substring(0,20)}...`),JSON.stringify(r);if(typeof r=="number"||typeof r=="boolean")return""+r;if(typeof r=="object"){if(r instanceof Array)return"an array";{const e=(function(n){return n.constructor?n.constructor.name:null})(r);return e?`a custom ${e} object`:"an object"}}return typeof r=="function"?"a function":A(12329,{type:typeof r})}function we(r,e){if("_delegate"in r&&(r=r._delegate),!(r instanceof e)){if(e.name===r.constructor.name)throw new y(p.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const t=Rr(r);throw new y(p.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${t}`)}}return r}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function z(r,e){const t={typeString:r};return e&&(t.value=e),t}function Fn(r,e){if(!Un(r))throw new y(p.INVALID_ARGUMENT,"JSON must be an object");let t;for(const n in e)if(e[n]){const s=e[n].typeString,i="value"in e[n]?{value:e[n].value}:void 0,a=e[n].optional;if(!(n in r)){if(a)continue;t=`JSON missing required field: '${n}'`;break}const o=r[n];if(s&&typeof o!==s){t=`JSON field '${n}' must be a ${s}.`;break}if(i!==void 0&&o!==i.value){t=`Expected '${n}' field to equal '${i.value}'`;break}}if(t)throw new y(p.INVALID_ARGUMENT,t);return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ki=-62135596800,Li=1e6;class M{static now(){return M.fromMillis(Date.now())}static fromDate(e){return M.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),n=Math.floor((e-1e3*t)*Li);return new M(t,n)}static fromInstant(e){if(!e||typeof e.t!="bigint")throw new y(p.INVALID_ARGUMENT,"Invalid Temporal.Instant object provided.");return M._fromEpochNanoseconds(e.t)}static _fromEpochNanoseconds(e){let t,n;if(e>=0n)t=Number(e/1000000000n),n=Number(e%1000000000n);else{const s=e%1000000000n;s===0n?(t=Number(e/1000000000n),n=0):(t=Number(e/1000000000n-1n),n=Number(s+1000000000n))}return new M(t,n)}constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new y(p.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new y(p.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<ki)throw new y(p.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new y(p.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/Li}toInstant(){if(typeof Temporal>"u"||!Temporal.Instant)throw new y(p.FAILED_PRECONDITION,"The Temporal object is not available in the current environment.");const e=1000000000n*BigInt(this.seconds)+BigInt(this.nanoseconds);return Temporal.Instant.__PRIVATE_fromEpochNanoseconds(e)}_compareTo(e){return this.seconds===e.seconds?N(this.nanoseconds,e.nanoseconds):N(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{type:M._jsonSchemaVersion,seconds:this.seconds,nanoseconds:this.nanoseconds}}static fromJSON(e){if(Fn(e,M._jsonSchema))return new M(e.seconds,e.nanoseconds)}valueOf(){const e=this.seconds-ki;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}M._jsonSchemaVersion="firestore/timestamp/1.0",M._jsonSchema={type:z("string",M._jsonSchemaVersion),seconds:z("number"),nanoseconds:z("number")};/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class La extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class B{constructor(e){this.binaryString=e}static fromBase64String(e){const t=(function(s){try{return atob(s)}catch(i){throw typeof DOMException<"u"&&i instanceof DOMException?new La("Invalid base64 string: "+i):i}})(e);return new B(t)}static fromUint8Array(e){const t=(function(s){let i="";for(let a=0;a<s.length;++a)i+=String.fromCharCode(s[a]);return i})(e);return new B(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return(function(t){return btoa(t)})(this.binaryString)}toUint8Array(){return(function(t){const n=new Uint8Array(t.length);for(let s=0;s<t.length;s++)n[s]=t.charCodeAt(s);return n})(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return N(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}B.EMPTY_BYTE_STRING=new B("");const rc=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function tt(r){if(I(!!r,39018),typeof r=="string"){let e=0;const t=rc.exec(r);if(I(!!t,46558,{timestamp:r}),t[1]){let s=t[1];s=(s+"000000000").substr(0,9),e=Number(s)}const n=new Date(r);return{seconds:Math.floor(n.getTime()/1e3),nanos:e}}return{seconds:$(r.seconds),nanos:$(r.nanos)}}function $(r){return typeof r=="number"?r:typeof r=="string"?Number(r):0}function At(r){return typeof r=="string"?B.fromBase64String(r):B.fromUint8Array(r)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Oa="server_timestamp",Ma="__type__",Ua="__previous_value__",Fa="__local_write_time__";function Is(r){return(r?.mapValue?.fields||{})[Ma]?.stringValue===Oa}function qn(r){const e=r.mapValue.fields[Ua];return Is(e)?qn(e):e}function qt(r){const e=tt(r.mapValue.fields[Fa].timestampValue);return new M(e.seconds,e.nanos)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class sc{constructor(e,t,n,s,i,a,o,u,c,l,h,d,g){this.databaseId=e,this.appId=t,this.persistenceKey=n,this.host=s,this.ssl=i,this.forceLongPolling=a,this.autoDetectLongPolling=o,this.longPollingOptions=u,this.useFetchStreams=c,this.isUsingEmulator=l,this.apiKey=h,this._customHeaders=d,this.grpcFlowControlWindow=g}}const cr="(default)";class yn{constructor(e,t){this.projectId=e,this.database=t||cr}static empty(){return new yn("","")}get isDefaultDatabase(){return this.database===cr}isEqual(e){return e instanceof yn&&e.projectId===this.projectId&&e.database===this.database}}function ic(r,e){if(!Object.prototype.hasOwnProperty.apply(r.options,["projectId"]))throw new y(p.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new yn(r.options.projectId,e)}/**
 * Copyright 2021 M.Vokhmentsev
 *
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class R{constructor(){this.exponent=0,this.i=0n,this.o=0n,this.u=new Array(4).fill(0n),this.l=new Array(6).fill(0n),this.h=new Array(6).fill(0n),this.T=new Array(6).fill(0n),this.P=new Array(12).fill(0n)}static I(e,t){let n=new R;return n.parse(e,t),n}parse(e,t){t+=e.length-1,this.exponent=0,this.i=0n,this.o=0n;let n=this.T,s=this.R(e,n);if(s==0&&this.isEmpty(n)||(t+=s)<R.A)return;if(t>R.V)return void(this.exponent=Number(R.m));let i=this.p(t,n);this.S(t,i,n)}R(e,t){for(let i=0;i<6;i++)t[i]=0n;let n=0;for(;n<e.length&&e[n]==0;)n+=1;if(n==e.length)return 0;let s=-n;if(e.length-n>R.v){let i=e[R.v]>=5,a=new Array(R.v).fill(0);for(let o=0;o<R.v;o++)a[o]=e[o+n];i&&(s+=this.D(a)),e=a,n=0}for(let i=e.length-1;i>=n;i--)t[0]|=BigInt(e[i])<<32n,this.C(t);return s}C(e){let t=e.length;for(let n=0;n<t;n++){let s=e[n]%10n;e[n]=e[n]/10n,n+1<t&&(e[n+1]+=s<<32n)}}isEmpty(e){for(let t=0;t<e.length;t++)if(e[t]!=0n)return!1;return!0}D(e){for(let t=e.length-1;t>=0;t--){if(e[t]!=9)return e[t]=e[t]+1,0;e[t]=0}return e[0]=1,1}p(e,t){let n=t[0]<<31n|t[1]>>1n,s=Number(n)/R.F;return Math.floor(Number(e)*R.O+this.log2(s))}log2(e){return R.M*Math.log(e)}S(e,t,n){let s=this.u;this.N(-t,s);let i=this.P;this.B(n,s,i),this.L(i),BigInt(s[0])!=BigInt(-e)&&this.L(i),t+=this.U(i),(t+=R.k)<=0||(t+=this.q(i),BigInt(t)>=R.m?this.exponent=Number(R.m):(this.exponent=Number(t),this.i=(i[0]<<32n)+i[1]&0xffffffffffffffffn,this.o=(i[2]<<32n)+i[3]&0xffffffffffffffffn))}N(e,t){if(e==0)return void this.K(R.$[0],t);let n=R.$;e<0&&(e=-e,n=R.W);let s=R.G,i=32,a=!0;for(;e>0;)e>=s&&(a?(this.K(n[i],t),a=!1):this.j(t,n[i],t),e-=s),i-=1,s*=.5}K(e,t){for(let n=0;n<t.length;n++)t[n]=e[n]}j(e,t,n){this.H(e,t,this.P);let s=this.J(this.P);this.Y(this.P,n),n[0]=e[0]+t[0]+BigInt(s)}H(e,t,n){for(let s=0;s<n.length;s++)n[s]=0n;this.Z(e,this.l),this.Z(t,this.h);for(let s=5;s>=0;s--)for(let i=5;i>=0;i--){let a=this.l[s]*this.h[i];n[i+s+1]=n[i+s+1]+(a&R.X)&0xffffffffffffffffn,n[i+s]=n[i+s]+(a>>32n)&0xffffffffffffffffn}for(let s=11;s>=1;s--)n[s-1]=n[s-1]+(n[s]>>32n)&0xffffffffffffffffn,n[s]&=R.X}J(e){let t=0;for(;this.ee(e);)this.L(e),t-=1;return t}ee(e){if(e[0]<0x19999999n)return!0;if(e[0]>0x19999999n)return!1;for(let t=1;t<e.length;t++){if(e[t]<0x99999999n)return!0;if(e[t]>0x99999999n)return!1}return!1}B(e,t,n){for(let a=0;a<n.length;a++)n[a]=0n;let s=this.h;this.Z(t,s);let i=e.length;for(let a=i-1;a>=0;a--)for(let o=i-1;o>=0;o--){let u=e[a]*s[o];n[o+a+1]=n[o+a+1]+(u&R.X)&0xffffffffffffffffn,n[o+a]=n[o+a]+(u>>32n)&0xffffffffffffffffn}for(let a=11;a>=1;a--)n[a-1]=n[a-1]+(n[a]>>32n)&0xffffffffffffffffn,n[a]&=R.X}L(e){let t=e.length-1;e[0]&=R.X,e[t]*=10n;for(let n=t-1;n>=0;n--)e[n]=10n*e[n]+(e[n+1]>>32n)&0xffffffffffffffffn,e[n+1]&=R.X}U(e){let t=31-R.te(e[0]);return t!=0&&this.ne(e,t),t}q(e){return this.re(e,5,100n),this.re(e,4,0x80000000n),(e[0]&R.ie<<1n)!=0n?(this.ne(e,1),1):0}Y(e,t){t[1]=(e[0]<<32n)+e[1],t[2]=(e[2]<<32n)+e[3],t[3]=(e[4]<<32n)+e[5]}Z(e,t){t[0]=e[1]>>32n,t[1]=e[1]&R.X,t[2]=e[2]>>32n,t[3]=e[2]&R.X,t[4]=e[3]>>32n,t[5]=e[3]&R.X}ne(e,t){let n=e.length-1,s=BigInt(32-Math.abs(t));if(t>0){let i=BigInt(t);for(let a=n+1-1;a>=1;a--)e[a]=e[a]>>i|e[a-1]<<s&R.X;e[0]=e[0]>>i}else if(t<0){let i=BigInt(-t);e[0]=0xffffffffffffffffn&(e[0]<<i|e[1]>>s);for(let a=1;a<n;a++)e[a]=0xffffffffffffffffn&(e[a]<<i&R.X|e[a+1]>>s);e[n]=e[n]<<i&R.X}}re(e,t,n){let s=t;e[s]=e[s]+n&0xffffffffffffffffn;for(let i=s+1-1;i>=1&&(e[i]&R.ie)!=0n;i--)e[i]&=R.X,e[i-1]+=1n}static te(e){let t=Number(e>>32n);return t==0?32+Math.clz32(Number(BigInt.asUintN(32,e))):Math.clz32(t)}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Y,Lt,ts,nr,rr,rn;R.v=59,R.V=646456993,R.A=-646457032,R.F=0xccccccccccccd00,R.se=0x8000000000000000n,R.G=2147483648,R.X=0x00000000ffffffffn,R.ie=0xffffffff00000000n,R.O=Math.log(10)/Math.log(2),R.M=1/Math.log(2),R.k=2147483647,R.m=0xffffffffn,R.$=[[1n,0x1999999999999999n,0x9999999999999999n,0x999999999999999an],[1n,0x3333333333333333n,0x3333333333333333n,0x3333333333333334n],[1n,0x6666666666666666n,0x6666666666666666n,0x6666666666666667n],[2n,0x28f5c28f5c28f5c2n,0x8f5c28f5c28f5c28n,0xf5c28f5c28f5c290n],[3n,0x4189374bc6a7ef9dn,0xb22d0e5604189374n,0xbc6a7ef9db22d0e6n],[5n,0xa7c5ac471b478423n,0x0fcf80dc33721d53n,0xcddd6e04c0592104n],[10n,0x6df37f675ef6eadfn,0x5ab9a2072d44268dn,0x97df837e6748956en],[20n,0x2f394219248446ban,0xa23d2ec729af3d61n,0x0607aa0167dd94cbn],[39n,0x571cbec554b60dbbn,0xd5f64baf0506840dn,0x451db70d5904029bn],[78n,0x1da48ce468e7c702n,0x6520247d3556476dn,0x1469caf6db224cfan],[155n,0x2252f0e5b39769dcn,0x9ae2eea30ca3ade0n,0xeeaa3c08dfe84e30n],[309n,0x2e055c9a3f6ba793n,0x16583a816eb60a59n,0x22c4b0826cf1ebf7n],[617n,0x52bb45e9cf23f17fn,0x7688c07606e50364n,0xb34479aa9d449a57n],[1234n,0x1abc81c8ff5f846cn,0x8f5e3c9853e38c97n,0x45060097f3bf9296n],[2467n,0x1bec53b510daa7b4n,0x48369ed77dbb0eb1n,0x3b05587b2187b41en],[4933n,0x1e75063a5ba91326n,0x8abfb8e460016ae3n,0x28008702d29e8a3cn],[9865n,0x243c5d8bb5c5fa55n,0x40c6d248c5881915n,0x4c0fd99fd5befc22n],[19729n,0x334a5570c3f4ef3cn,0xa13c36c43f979c90n,0xda7ac473555fb7a8n],[39457n,0x66c304445dd98f3bn,0xa8c293a20e47a41bn,0x4c5b03dc12604964n],[78914n,0x293ffbf5fb028cc4n,0x89d3e5ff44238406n,0x369a339e1bfe8c9bn],[157827n,0x427792fbb68e5d20n,0x7b297cd9fc154b62n,0xf09142114aa9a20cn],[315653n,0xac92bc65ad5c08fcn,0x00beeb115a566c19n,0x4ba882d8a4622437n],[631306n,0x745581440f92e80en,0x4da822cf7f896f41n,0x509d598678164ecdn],[1262612n,0x34dd99b4c69523a5n,0x64bc2e8f0d8b1044n,0xb03b1c96da5dd349n],[2525223n,0x6d2bbea9d6d25a08n,0xa0a4606a88e96b70n,0x182063bbc2fe8520n],[5050446n,0x2e8e47d63bfdd6e3n,0x2b55fa8976eaa3e9n,0x1a6b9d3086412a73n],[10100891n,0x54aa68efa1d719dfn,0xd8505806612c5c8fn,0xad068837fee8b43an],[20201782n,0x1c00464ccb7bae77n,0x9e3877784c77982cn,0xd94af3b61717404fn],[40403563n,0x1ea099c8be2b6cd0n,0x8bfb6d539fa50466n,0x6d3bc37e69a84218n],[80807125n,0x24a457f466ce8d18n,0xf2c8f3b81bc6bb59n,0xa78c757692e02d49n],[161614249n,0x347256677aba6b53n,0x3fbf90d30611a67cn,0x1e039d87e0bdb32bn],[323228497n,0x6b727daf0fd3432an,0x71f71121f9e4200fn,0x8fcd9942d486c10cn],[646456994n,0x2d18e84484d91f78n,0x4079bfe7829dec6fn,0x21551643e365abc6n]],R.W=[[1n,0x1999999999999999n,0x9999999999999999n,0x999999999999999an],[0n,0x8000000000000000n,0x0000000000000000n,0x0000000000000000n],[0n,0x4000000000000000n,0x0000000000000000n,0x0000000000000001n],[-1n,0xa000000000000000n,0x0000000000000000n,0x0000000000000000n],[-2n,0x6400000000000000n,0x0000000000000000n,0x0000000000000000n],[-4n,0x2710000000000000n,0x0000000000000000n,0x0000000000000001n],[-9n,0x3b9aca0000000000n,0x0000000000000000n,0x0000000000000001n],[-19n,0x8ac7230489e80000n,0x0000000000000000n,0x0000000000000000n],[-38n,0x4b3b4ca85a86c47an,0x098a224000000000n,0x0000000000000001n],[-77n,0xdd15fe86affad912n,0x49ef0eb713f39eben,0xaa987b6e6fd2a002n],[-154n,0xbeeefb584aff8603n,0xaafb550ffacfd8fan,0x5ca47e4f88d45371n],[-308n,0x8e679c2f5e44ff8fn,0x570f09eaa7ea7648n,0x5961db50c6d2b888n],[-616n,0x4f371b3399fc2ab0n,0x8170041c9feb05aan,0xc7c343447c75bcf6n],[-1233n,0xf51e928179013fd3n,0xde4bd12cde4d985cn,0x4a573ca6f94bff14n],[-2466n,0xeab388127bccaff7n,0x1667639142b9fbaen,0x775ec9995e1039fbn],[-4932n,0xd72cb2a95c7ef6ccn,0xe81bf1e825ba7515n,0xc2feb521d6cb5dcdn],[-9864n,0xb4dc1be6604502dcn,0xd491079b8eef6535n,0x578d3965d24de84dn],[-19728n,0x7fc6447bee60ea43n,0x2548da5c8b125b27n,0x5f42d1142f41d349n],[-39456n,0x3fc65180f88af8fbn,0x6a6915f383349413n,0x063c3708b6ceb291n],[-78913n,0x9ee0197c8dcd55bfn,0x2b2b9b942c38f4a2n,0x0f8ba634e9c706aen],[-157826n,0x629963a25b8b2d79n,0xd00b9d2286f70876n,0xe97004700c3644fcn],[-315652n,0x25f9cc308ceef4f3n,0x40f19543911a4546n,0xa2cd389452cfc366n],[-631305n,0x385597b0d47e76b8n,0x1b9f67e103bf2329n,0xc3119848595985f7n],[-1262611n,0x7bf795d276c12f66n,0x66a61d62a446659an,0xa1a4d73bebf093d5n],[-2525222n,0x3c07d96ab1ed7799n,0xcb7355c22cc05ac0n,0x4ffc0ab73b1f6a49n],[-5050445n,0x8cc4cd8c3edefb9an,0x6c8ff86a90a97e0cn,0x166cfddbf98b71bfn],[-10100890n,0x4d67d81cc88e1228n,0x1d7cfb06666b79b3n,0x7b916728aaa4e70dn],[-20201781n,0xea0c55494e7a552dn,0xb88cb9484bb86c61n,0x8d44893c610bb7dfn],[-40403562n,0xd5fa8c821ec0c24an,0xa80e46e764e0f8b0n,0xa7276bfa432fac7en],[-80807124n,0xb2dae307426f6791n,0xc970b82f58b12918n,0x0472592f7f39190en],[-161614248n,0x7cf51edd8a15f1c9n,0x656dab3498f8e697n,0x12daa2a80e53c807n],[-323228496n,0x3cfe609ab5883c50n,0xbec8b5d22b198871n,0xe18477703b4622b4n],[-646456993n,0x9152447b9d7cda9an,0x3b4d3f6110d77aadn,0xfa81bad1c394adb4n]];class v{constructor(e,t,n,s){this.negative=e,this._e=t,this.i=n,this.o=s}exponent(){return this._e-R.k}oe(){return this._e===0&&this.i===0n&&this.o===0n}ae(){return this._e===te(v,Y,"f",Lt)&&this.i===0n&&this.o===0n}isNaN(){return this._e===te(v,Y,"f",Lt)&&!(this.i===0n&&this.o===0n)}compareTo(e){if(this.isNaN())return e.isNaN()?0:1;if(e.isNaN())return-1;let t,n;if(this.negative){if(!e.negative)return-1;t=1,n=-1}else{if(e.negative)return 1;t=-1,n=1}return this._e<e._e?t:this._e>e._e?n:this.i<e.i?t:this.i>e.i?n:this.o<e.o?t:this.o>e.o?n:0}debug(){return(this.negative?"+":"-")+te(v,Y,"m",ts).call(v,this.i)+te(v,Y,"m",ts).call(v,this.o)+"*2^"+this.exponent()}static fromNumber(e){if(isNaN(e))return v.NaN;if(!isFinite(e))return e<0?v.ue:v.ce;if(e===0)return Math.sign(1/e)>0?v.le:v.Ee;const t=new DataView(new ArrayBuffer(8));t.setFloat64(0,e);const n=t.getBigUint64(0);let s=BigInt.asUintN(64,n<<12n),i=2047&Number(n>>52n);if(i===0){const a=R.te(s);s=a<63?s<<BigInt(a+1):0n,i=-a}return new v(e<0,te(v,Y,"m",rn).call(v,i-1023),s,0n)}static fromString(e){if(e==="NaN")return v.NaN;if(e==="-Infinity")return v.ue;if(e==="Infinity"||e==="+Infinity")return v.ce;const t=new Array(e.length).fill(0);let n=0,s=0,i=0,a=!1;for(e[n]==="-"?(a=!0,n++):e[n]==="+"&&n++;te(v,Y,"m",nr).call(v,e,n);)t[s++]=te(v,Y,"m",rr).call(v,e,n++);if(e[n]==="."){const u=++n;for(;te(v,Y,"m",nr).call(v,e,n);)t[s++]=te(v,Y,"m",rr).call(v,e,n++);i=u-n}if(e[n]==="e"||e[n]==="E"){let u=0;n++;let c=1;e[n]==="-"?(c=-1,n++):e[n]==="+"&&n++;const l=n;for(;te(v,Y,"m",nr).call(v,e,n);)if(u=10*u+te(v,Y,"m",rr).call(v,e,n++),n-l>9)throw new Error("Exponent too large "+e);if(n===l)throw new Error("Invalid number "+e);i+=u*c}if(s===0||n!==e.length)throw new Error("Invalid number "+e);const o=R.I(t.slice(0,s),i);return new v(a,o.exponent,o.i,o.o)}}Y=v,ts=function(e){return e.toString(16).padStart(16,"0")},nr=function(e,t){const n=e.codePointAt(t);return n!==void 0&&n>=48&&n<=57},rr=function(e,t){return e.codePointAt(t)-48},rn=function(e){return e+R.k},Lt={value:Number(R.m)},v.le=new v(!1,0,0n,0n),v.Ee=new v(!0,0,0n,0n),v.NaN=new v(!1,te(v,Y,"f",Lt),1n<<63n,0n),v.ue=new v(!0,te(v,Y,"f",Lt),0n,0n),v.ce=new v(!1,te(v,Y,"f",Lt),0n,0n),new v(!0,te(v,Y,"m",rn).call(v,63),0n,0n),new v(!1,te(v,Y,"m",rn).call(v,0),0n,0n),new v(!0,te(v,Y,"m",rn).call(v,0),0n,0n);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const As=-1;function Bn(r){return r==null}function En(r){return r===0&&1/r==-1/0}function ac(r){return typeof r=="number"&&Number.isInteger(r)&&!En(r)&&r<=Number.MAX_SAFE_INTEGER&&r>=Number.MIN_SAFE_INTEGER}function oc(r){return typeof r=="string"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Vs="__type__",vs="__vector__",Tn="value",uc="server_timestamp",qa="__min__",Rs="__max__",Ye="__regex__",lr="pattern",hr="options",wn="__oid__",Rt="__int__",nt="__decimal128__",_t="__request_timestamp__",fr="seconds",dr="increment",Pr="__binary__",Bt={nullValue:"NULL_VALUE"},Jn={mapValue:{}};var U,Ve;(Ve=U||(U={})).he="regexValue",Ve.Te="bsonObjectIdValue",Ve.Pe="int32Value",Ve.Ie="decimal128Value",Ve.Re="bsonTimestampValue",Ve.Ae="bsonBinaryValue",Ve.Ve="minKeyValue",Ve.fe="maxKeyValue",Ve.de="maxValue",Ve.me="vectorValue",Ve.pe="serverTimestampValue",Ve.ge="regularMapValue";const Oi={[vs]:U.me,[Rs]:U.de,[uc]:U.pe},Ba={[Ye]:U.he,[wn]:U.Te,[Rt]:U.Pe,[nt]:U.Ie,[_t]:U.Re,[Pr]:U.Ae,[qa]:U.Ve,[Rs]:U.fe},cc=new Set(Object.values(Ba)),me={booleanValue:!0},Z={booleanValue:!1};function Q(r){if("nullValue"in r)return 0;if("booleanValue"in r)return 2;if("integerValue"in r||"doubleValue"in r)return 3;if("timestampValue"in r)return 4;if("stringValue"in r)return 7;if("bytesValue"in r)return 8;if("referenceValue"in r)return 9;if("geoPointValue"in r)return 11;if("arrayValue"in r)return 13;if(!("mapValue"in r))return A(28295,{value:r});switch(Qa(r)){case U.pe:return 6;case U.de:return 9007199254740991;case U.me:return 14;case U.he:return 12;case U.Te:return 10;case U.Pe:case U.Ie:return 3;case U.Re:return 5;case U.Ae:return 8;case U.Ve:return 1;case U.fe:return 16;default:return 15}}function ve(r,e,t){if(r===e)return!0;const n=Q(r);if(n!==Q(e))return!1;switch(n){case 0:case 9007199254740991:case 16:case 1:return!0;case 2:return r.booleanValue===e.booleanValue;case 6:return qt(r).isEqual(qt(e));case 4:return(function(i,a){if(typeof i.timestampValue=="string"&&typeof a.timestampValue=="string"&&i.timestampValue.length===a.timestampValue.length)return i.timestampValue===a.timestampValue;const o=tt(i.timestampValue),u=tt(a.timestampValue);return o.seconds===u.seconds&&o.nanos===u.nanos})(r,e);case 7:return r.stringValue===e.stringValue;case 8:return(function(i,a){return Ga(i,a)===0})(r,e);case 9:return r.referenceValue===e.referenceValue;case 11:return(function(i,a){return $(i.geoPointValue.latitude)===$(a.geoPointValue.latitude)&&$(i.geoPointValue.longitude)===$(a.geoPointValue.longitude)})(r,e);case 3:return(function(i,a,o){if(Re(i)&&Re(a))return za(i,a)===0;if("integerValue"in i&&"integerValue"in a||rt(i)&&rt(a))return An(i)===An(a);let u,c;if("doubleValue"in i&&"doubleValue"in a)u=$(i.doubleValue),c=$(a.doubleValue);else{if(!o?.ye)return!1;u=$(i.integerValue??i.doubleValue),c=$(a.integerValue??a.doubleValue)}return u===c?!!o?.we||En(u)===En(c):!!(o===void 0||o.be)&&isNaN(u)&&isNaN(c)})(r,e,t);case 13:return Ft(r.arrayValue.values||[],e.arrayValue.values||[],((s,i)=>ve(s,i,t)));case 14:case 15:return(function(i,a,o){const u=i.mapValue.fields||{},c=a.mapValue.fields||{};if(It(u)!==It(c))return!1;for(const l in u)if(u.hasOwnProperty(l)&&(c[l]===void 0||!ve(u[l],c[l],o)))return!1;return!0})(r,e,t);case 5:return ja(r,e)===0;case 12:return Ka(r,e)===0;case 10:return Wa(r,e)===0;default:return A(52216,{left:r})}}function In(r,e){return(r.values||[]).find((t=>ve(t,e)))!==void 0}function pe(r,e){if(r===e)return 0;const t=Q(r),n=Q(e);if(t!==n)return N(t,n);switch(t){case 0:case 1:case 16:case 9007199254740991:return 0;case 2:return N(r.booleanValue,e.booleanValue);case 3:return Vn(r,e);case 4:return Ui(r.timestampValue,e.timestampValue);case 6:return Ui(qt(r),qt(e));case 7:return gn(r.stringValue,e.stringValue);case 8:return Ga(r,e);case 9:return(function(i,a){const o=i.split("/"),u=a.split("/");for(let c=0;c<o.length&&c<u.length;c++){const l=N(o[c],u[c]);if(l!==0)return l}return N(o.length,u.length)})(r.referenceValue,e.referenceValue);case 11:return(function(i,a){const o=N($(i.latitude),$(a.latitude));return o!==0?o:N($(i.longitude),$(a.longitude))})(r.geoPointValue,e.geoPointValue);case 13:return Fi(r.arrayValue,e.arrayValue);case 14:return(function(i,a){const o=i.fields||{},u=a.fields||{},c=o[Tn]?.arrayValue,l=u[Tn]?.arrayValue,h=N(c?.values?.length||0,l?.values?.length||0);return h!==0?h:Fi(c,l)})(r.mapValue,e.mapValue);case 15:return(function(i,a){if(i===Jn.mapValue&&a===Jn.mapValue)return 0;if(i===Jn.mapValue)return 1;if(a===Jn.mapValue)return-1;const o=i.fields||{},u=Object.keys(o),c=a.fields||{},l=Object.keys(c);u.sort(),l.sort();for(let h=0;h<u.length&&h<l.length;++h){const d=gn(u[h],l[h]);if(d!==0)return d;const g=pe(o[u[h]],c[l[h]]);if(g!==0)return g}return N(u.length,l.length)})(r.mapValue,e.mapValue);case 5:return ja(r,e);case 12:return Ka(r,e);case 10:return Wa(r,e);default:throw A(23264,{Se:t})}}function An(r){let e;return e=rt(r)?r.mapValue.fields[Rt].integerValue:r.integerValue||r.doubleValue,$(e)}function $a(r){return r.mapValue.fields[nt].stringValue}function Vn(r,e){if(Re(r)||Re(e))return za(r,e);const t=An(r),n=An(e);return isNaN(t)?isNaN(n)?0:-1:isNaN(n)?1:N(t,n)}function za(r,e){const t=Mi(r),n=Mi(e);return t.oe()&&n.oe()?0:t.isNaN()?n.isNaN()?0:-1:n.isNaN()?1:t.compareTo(n)}function Mi(r){return Re(r)?v.fromString($a(r)):v.fromNumber(An(r))}function Ui(r,e){if(typeof r=="string"&&typeof e=="string"&&r.length===e.length)return N(r,e);const t=tt(r),n=tt(e),s=N(t.seconds,n.seconds);return s!==0?s:N(t.nanos,n.nanos)}function Fi(r,e){const t=r.values||[],n=e.values||[];for(let s=0;s<t.length&&s<n.length;++s){const i=pe(t[s],n[s]);if(i!==void 0&&i!==0)return i}return N(t.length,n.length)}function ja(r,e){const t=r.mapValue.fields?.[_t].mapValue?.fields?.[fr],n=e.mapValue.fields?.[_t].mapValue?.fields?.[fr],s=r.mapValue.fields?.[_t].mapValue?.fields?.[dr],i=e.mapValue.fields?.[_t].mapValue?.fields?.[dr],a=Vn(t,n);return a!==0?a:Vn(s,i)}function qi(r){if("bytesValue"in r)return{subtype:0,bytes:At(r.bytesValue)};const e=r.mapValue?.fields,t=e?.[Pr],n=t?.bytesValue;if(!n)throw new Error("Received incorrect value for BsonBinaryData");const s=At(n).toUint8Array();if(s.length===0)throw new Error("Received empty bytesValue for BsonBinaryData");const i=s[0],a=s.slice(1);return{subtype:i,bytes:B.fromUint8Array(a)}}function Ga(r,e){const t=qi(r),n=qi(e);return t.subtype!==n.subtype?t.subtype<n.subtype?-1:1:t.bytes.compareTo(n.bytes)}function Ka(r,e){const t=r.mapValue.fields,n=t?.[Ye]?.mapValue?.fields?.[lr]?.stringValue??"",s=t?.[Ye]?.mapValue?.fields?.[hr]?.stringValue??"",i=e.mapValue.fields,a=i?.[Ye]?.mapValue?.fields?.[lr]?.stringValue??"",o=i?.[Ye]?.mapValue?.fields?.[hr]?.stringValue??"",u=gn(n,a);return u!==0?u:N(s,o)}function Wa(r,e){return gn(r.mapValue.fields?.[wn]?.stringValue??"",e.mapValue.fields?.[wn]?.stringValue??"")}function $t(r){return ns(r)}function ns(r){return"nullValue"in r?"null":"booleanValue"in r?""+r.booleanValue:"integerValue"in r?""+r.integerValue:"doubleValue"in r?""+r.doubleValue:"timestampValue"in r?(function(t){const n=tt(t);return`time(${n.seconds},${n.nanos})`})(r.timestampValue):"stringValue"in r?r.stringValue:"bytesValue"in r?(function(t){return At(t).toBase64()})(r.bytesValue):"referenceValue"in r?(function(t){return V.fromName(t).toString()})(r.referenceValue):"geoPointValue"in r?(function(t){return`geo(${t.latitude},${t.longitude})`})(r.geoPointValue):"arrayValue"in r?(function(t){let n="[",s=!0;for(const i of t.values||[])s?s=!1:n+=",",n+=ns(i);return n+"]"})(r.arrayValue):"mapValue"in r?(function(t){const n=Object.keys(t.fields||{}).sort();let s="{",i=!0;for(const a of n)i?i=!1:s+=",",s+=`${a}:${ns(t.fields[a])}`;return s+"}"})(r.mapValue):A(61005,{value:r})}function mr(r){switch(Q(r)){case 0:case 2:return 4;case 3:return Re(r)?16:8;case 4:case 11:return 16;case 6:const e=qn(r);return e?16+mr(e):16;case 7:return 2*r.stringValue.length;case 8:return"bytesValue"in r?At(r.bytesValue).approximateByteSize():Bi(r.mapValue);case 9:return r.referenceValue.length;case 13:return(function(n){return(n.values||[]).reduce(((s,i)=>s+mr(i)),0)})(r.arrayValue);case 14:case 15:case 12:case 10:case 5:case 1:case 16:return Bi(r.mapValue);default:throw A(13486,{value:r})}}function Bi(r){let e=0;return ft(r.fields,((t,n)=>{e+=t.length+mr(n)})),e}function $i(r,e){return{referenceValue:`projects/${r.projectId}/databases/${r.database}/documents/${e.path.canonicalString()}`}}function Ne(r){return!!r&&"integerValue"in r}function De(r){return!!r&&"doubleValue"in r}function Re(r){if(!r.mapValue?.fields)return!1;const e=r.mapValue.fields;return It(e)===1&&e[nt]&&!!e[nt].stringValue}function rt(r){if(!r.mapValue?.fields)return!1;const e=r.mapValue.fields;return It(e)===1&&e[Rt]?.integerValue!==void 0}function Ke(r){return Ne(r)||De(r)||!!r&&rt(r)||!!r&&Re(r)}function zt(r){return!!r&&"arrayValue"in r}function Ee(r){return!!r&&"nullValue"in r}function ee(r){return!(!De(r)||!isNaN(Number(r.doubleValue)))||!(!Re(r)||$a(r)!=="NaN")}function yt(r){return!!r&&"mapValue"in r}function Qa(r){if(!r.mapValue?.fields)return U.ge;const e=r.mapValue.fields,t=e[Vs]?.stringValue;if(t&&Oi[t])return Oi[t];if(It(e)===1){const n=Object.keys(e);return Ba[n[0]]??U.ge}return U.ge}function rs(r){return(r?.mapValue?.fields||{})[Vs]?.stringValue===vs}function ss(r){return(r?.mapValue?.fields||{})[Tn]?.arrayValue}function un(r){if(r.geoPointValue)return{geoPointValue:{...r.geoPointValue}};if(r.timestampValue&&typeof r.timestampValue=="object")return{timestampValue:{...r.timestampValue}};if(r.mapValue){const e={mapValue:{fields:{}}};return ft(r.mapValue.fields,((t,n)=>e.mapValue.fields[t]=un(n))),e}if(r.arrayValue){const e={arrayValue:{values:[]}};for(let t=0;t<(r.arrayValue.values||[]).length;++t)e.arrayValue.values[t]=un(r.arrayValue.values[t]);return e}return{...r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ae{constructor(e){this.value=e}static empty(){return new ae({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let n=0;n<e.length-1;++n)if(t=(t.mapValue.fields||{})[e.get(n)],!yt(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=un(t)}setAll(e){let t=Te.emptyPath(),n={},s=[];e.forEach(((a,o)=>{if(!t.isImmediateParentOf(o)){const u=this.getFieldsMap(t);this.applyChanges(u,n,s),n={},s=[],t=o.popLast()}a?n[o.lastSegment()]=un(a):s.push(o.lastSegment())}));const i=this.getFieldsMap(t);this.applyChanges(i,n,s)}delete(e){const t=this.field(e.popLast());yt(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return ve(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let n=0;n<e.length;++n){let s=t.mapValue.fields[e.get(n)];yt(s)&&s.mapValue.fields||(s={mapValue:{fields:{}}},t.mapValue.fields[e.get(n)]=s),t=s}return t.mapValue.fields}applyChanges(e,t,n){ft(t,((s,i)=>e[s]=i));for(const s of n)delete e[s]}clone(){return new ae(un(this.value))}}function Ha(r){const e=[];return ft(r.fields,((t,n)=>{const s=new Te([t]);if(yt(n)&&!(function(a){return cc.has(Qa(a))})(n)){const i=Ha(n.mapValue).fields;if(i.length===0)e.push(s);else for(const a of i)e.push(s.child(a))}else e.push(s)})),new ye(e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ps(r,e){if(r.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:En(e)?"-0":e}}function Mt(r){return{integerValue:""+r}}function xs(r,e,t){return ac(e)?Mt(e):Ps(r,e)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xr{constructor(){this._=void 0}}function lc(r,e,t){return r instanceof vn?(function(s,i){const a={fields:{[Ma]:{stringValue:Oa},[Fa]:{timestampValue:{seconds:s.seconds,nanos:s.nanoseconds}}}};return i&&Is(i)&&(i=qn(i)),i&&(a.fields[Ua]=i),{mapValue:a}})(t,e):r instanceof Rn?Xa(r,e):r instanceof Pn?Ja(r,e):r instanceof xn?(function(s,i){const a=Ya(s,i),o=zi(a)+zi(s.xe);return Re(a)||Re(s.xe)?{mapValue:{fields:{[nt]:{stringValue:o.toString()}}}}:rt(a)?De(s.xe)?{doubleValue:o}:Ne(s.xe)?{integerValue:o.toString()}:{mapValue:{fields:{[Rt]:Mt(o)}}}:Ne(a)&&(Ne(s.xe)||rt(s.xe))?Mt(o):Ps(s.serializer,o)})(r,e):r instanceof pr?(function(s,i){return!Ke(i)||ee(s.xe)?s.xe:ee(i)?i:Vn(s.xe,i)<0?s.xe:i})(r,e):r instanceof _r?(function(s,i){return!Ke(i)||ee(s.xe)?s.xe:ee(i)?i:Vn(s.xe,i)>0?s.xe:i})(r,e):void 0}function hc(r,e,t){return r instanceof Rn?Xa(r,e):r instanceof Pn?Ja(r,e):t}function Ya(r,e){return r instanceof xn?Ke(e)?e:{integerValue:0}:null}class vn extends xr{}class Rn extends xr{constructor(e){super(),this.elements=e}}function Xa(r,e){const t=Za(e);for(const n of r.elements)t.some((s=>ve(s,n)))||t.push(n);return{arrayValue:{values:t}}}class Pn extends xr{constructor(e){super(),this.elements=e}}function Ja(r,e){let t=Za(e);for(const n of r.elements)t=t.filter((s=>!ve(s,n)));return{arrayValue:{values:t}}}class bs extends xr{constructor(e,t){super(),this.serializer=e,this.xe=t}}class xn extends bs{}class pr extends bs{}class _r extends bs{}function zi(r){return Ne(r)?$(r.integerValue):De(r)?$(r.doubleValue):rt(r)?$(r.mapValue.fields[Rt].integerValue):Re(r)?parseFloat(r.mapValue.fields[nt].stringValue):0}function Za(r){return zt(r)&&r.arrayValue.values?r.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fc{constructor(e,t){this.field=e,this.transform=t}}function dc(r,e){return r.field.isEqual(e.field)&&(function(n,s){return n instanceof Rn&&s instanceof Rn||n instanceof Pn&&s instanceof Pn?Ft(n.elements,s.elements,ve):n instanceof xn&&s instanceof xn||n instanceof pr&&s instanceof pr||n instanceof _r&&s instanceof _r?ve(n.xe,s.xe):n instanceof vn&&s instanceof vn})(r.transform,e.transform)}class mc{constructor(e,t){this.version=e,this.transformResults=t}}class le{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new le}static exists(e){return new le(void 0,e)}static updateTime(e){return new le(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function sr(r,e){return r.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(r.updateTime):r.exists===void 0||r.exists===e.isFoundDocument()}class br{}function eo(r,e){if(!r.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return r.isNoDocument()?new Cs(r.key,le.none()):new $n(r.key,r.data,le.none());{const t=r.data,n=ae.empty();let s=new W(Te.comparator);for(let i of e.fields)if(!s.has(i)){let a=t.field(i);a===null&&i.length>1&&(i=i.popLast(),a=t.field(i)),a===null?n.delete(i):n.set(i,a),s=s.add(i)}return new dt(r.key,n,new ye(s.toArray()),le.none())}}function pc(r,e,t){r instanceof $n?(function(s,i,a){const o=s.value.clone(),u=Gi(s.fieldTransforms,i,a.transformResults);o.setAll(u),i.convertToFoundDocument(a.version,o).setHasCommittedMutations()})(r,e,t):r instanceof dt?(function(s,i,a){if(!sr(s.precondition,i))return void i.convertToUnknownDocument(a.version);const o=Gi(s.fieldTransforms,i,a.transformResults),u=i.data;u.setAll(to(s)),u.setAll(o),i.convertToFoundDocument(a.version,u).setHasCommittedMutations()})(r,e,t):(function(s,i,a){i.convertToNoDocument(a.version).setHasCommittedMutations()})(0,e,t)}function cn(r,e,t,n){return r instanceof $n?(function(i,a,o,u){if(!sr(i.precondition,a))return o;const c=i.value.clone(),l=Ki(i.fieldTransforms,u,a);return c.setAll(l),a.convertToFoundDocument(a.version,c).setHasLocalMutations(),null})(r,e,t,n):r instanceof dt?(function(i,a,o,u){if(!sr(i.precondition,a))return o;const c=Ki(i.fieldTransforms,u,a),l=a.data;return l.setAll(to(i)),l.setAll(c),a.convertToFoundDocument(a.version,l).setHasLocalMutations(),o===null?null:o.unionWith(i.fieldMask.fields).unionWith(i.fieldTransforms.map((h=>h.field)))})(r,e,t,n):(function(i,a,o){return sr(i.precondition,a)?(a.convertToNoDocument(a.version).setHasLocalMutations(),null):o})(r,e,t)}function _c(r,e){let t=null;for(const n of r.fieldTransforms){const s=e.data.field(n.field),i=Ya(n.transform,s||null);i!=null&&(t===null&&(t=ae.empty()),t.set(n.field,i))}return t||null}function ji(r,e){return r.type===e.type&&!!r.key.isEqual(e.key)&&!!r.precondition.isEqual(e.precondition)&&!!(function(n,s){return n===void 0&&s===void 0||!(!n||!s)&&Ft(n,s,((i,a)=>dc(i,a)))})(r.fieldTransforms,e.fieldTransforms)&&(r.type===0?r.value.isEqual(e.value):r.type!==1||r.data.isEqual(e.data)&&r.fieldMask.isEqual(e.fieldMask))}class $n extends br{constructor(e,t,n,s=[]){super(),this.key=e,this.value=t,this.precondition=n,this.fieldTransforms=s,this.type=0}getFieldMask(){return null}}class dt extends br{constructor(e,t,n,s,i=[]){super(),this.key=e,this.data=t,this.fieldMask=n,this.precondition=s,this.fieldTransforms=i,this.type=1}getFieldMask(){return this.fieldMask}}function to(r){const e=new Map;return r.fieldMask.fields.forEach((t=>{if(!t.isEmpty()){const n=r.data.field(t);e.set(t,n)}})),e}function Gi(r,e,t){const n=new Map;I(r.length===t.length,32656,{ve:t.length,De:r.length});for(let s=0;s<t.length;s++){const i=r[s],a=i.transform,o=e.data.field(i.field);n.set(i.field,hc(a,o,t[s]))}return n}function Ki(r,e,t){const n=new Map;for(const s of r){const i=s.transform,a=t.data.field(s.field);n.set(s.field,lc(i,a,e))}return n}class Cs extends br{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class no extends br{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gr{constructor(e,t){this.position=e,this.inclusive=t}}function Wi(r,e,t){let n=0;for(let s=0;s<r.position.length;s++){const i=e[s],a=r.position[s];if(i.field.isKeyField()?n=V.comparator(V.fromName(a.referenceValue),t.key):n=pe(a,t.data.field(i.field)),i.dir==="desc"&&(n*=-1),n!==0)break}return n}function Qi(r,e){if(r===null)return e===null;if(e===null||r.inclusive!==e.inclusive||r.position.length!==e.position.length)return!1;for(let t=0;t<r.position.length;t++)if(!ve(r.position[t],e.position[t]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ro{}class K extends ro{constructor(e,t,n){super(),this.field=e,this.op=t,this.value=n}static create(e,t,n){return e.isKeyField()?t==="in"||t==="not-in"?this.createKeyFieldInFilter(e,t,n):new yc(e,t,n):t==="array-contains"?new wc(e,n):t==="in"?new Ic(e,n):t==="not-in"?new Ac(e,n):t==="array-contains-any"?new Vc(e,n):new K(e,t,n)}static createKeyFieldInFilter(e,t,n){return t==="in"?new Ec(e,n):new Tc(e,n)}matches(e){const t=e.data.field(this.field);return this.op==="!="?t!==null&&t.nullValue===void 0&&this.matchesComparison(pe(t,this.value)):t!==null&&Q(this.value)===Q(t)&&this.matchesComparison(pe(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return A(47266,{operator:this.op})}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class be extends ro{constructor(e,t){super(),this.filters=e,this.op=t,this.Ce=null}static create(e,t){return new be(e,t)}matches(e){return so(this)?this.filters.find((t=>!t.matches(e)))===void 0:this.filters.find((t=>t.matches(e)))!==void 0}getFlattenedFilters(){return this.Ce!==null||(this.Ce=this.filters.reduce(((e,t)=>e.concat(t.getFlattenedFilters())),[])),this.Ce}getFilters(){return Object.assign([],this.filters)}}function so(r){return r.op==="and"}function io(r){return gc(r)&&so(r)}function gc(r){for(const e of r.filters)if(e instanceof be)return!1;return!0}function is(r){if(r instanceof K)return r.field.canonicalString()+r.op.toString()+$t(r.value);if(io(r))return r.filters.map((e=>is(e))).join(",");{const e=r.filters.map((t=>is(t))).join(",");return`${r.op}(${e})`}}function ao(r,e){return r instanceof K?(function(n,s){return s instanceof K&&n.op===s.op&&n.field.isEqual(s.field)&&ve(n.value,s.value)})(r,e):r instanceof be?(function(n,s){return s instanceof be&&n.op===s.op&&n.filters.length===s.filters.length?n.filters.reduce(((i,a,o)=>i&&ao(a,s.filters[o])),!0):!1})(r,e):void A(19439)}function oo(r){return r instanceof K?(function(t){return`${t.field.canonicalString()} ${t.op} ${$t(t.value)}`})(r):r instanceof be?(function(t){return t.op.toString()+" {"+t.getFilters().map(oo).join(" ,")+"}"})(r):"Filter"}class yc extends K{constructor(e,t,n){super(e,t,n),this.key=V.fromName(n.referenceValue)}matches(e){const t=V.comparator(e.key,this.key);return this.matchesComparison(t)}}class Ec extends K{constructor(e,t){super(e,"in",t),this.keys=uo("in",t)}matches(e){return this.keys.some((t=>t.isEqual(e.key)))}}class Tc extends K{constructor(e,t){super(e,"not-in",t),this.keys=uo("not-in",t)}matches(e){return!this.keys.some((t=>t.isEqual(e.key)))}}function uo(r,e){return(e.arrayValue?.values||[]).map((t=>V.fromName(t.referenceValue)))}class wc extends K{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return zt(t)&&In(t.arrayValue,this.value)}}class Ic extends K{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return t!==null&&In(this.value.arrayValue,t)}}class Ac extends K{constructor(e,t){super(e,"not-in",t)}matches(e){if(In(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return t!==null&&t.nullValue===void 0&&!In(this.value.arrayValue,t)}}class Vc extends K{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!zt(t)||!t.arrayValue.values)&&t.arrayValue.values.some((n=>In(this.value.arrayValue,n)))}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bn{constructor(e,t="asc"){this.field=e,this.dir=t}}function vc(r,e){return r.dir===e.dir&&r.field.isEqual(e.field)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class b{static fromTimestamp(e){return new b(e)}static min(){return new b(new M(0,0))}static max(){return new b(new M(253402300799,999999999))}constructor(e){this.timestamp=e}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class J{constructor(e,t,n,s,i,a,o){this.key=e,this.documentType=t,this.version=n,this.readTime=s,this.createTime=i,this.data=a,this.documentState=o}static newInvalidDocument(e){return new J(e,0,b.min(),b.min(),b.min(),ae.empty(),0)}static newFoundDocument(e,t,n,s){return new J(e,1,t,b.min(),n,s,0)}static newNoDocument(e,t){return new J(e,2,t,b.min(),b.min(),ae.empty(),0)}static newUnknownDocument(e,t){return new J(e,3,t,b.min(),b.min(),ae.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(b.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=ae.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=ae.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=b.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof J&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new J(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Cn=-1;function Rc(r,e){const t=r.toTimestamp().seconds,n=r.toTimestamp().nanoseconds+1,s=b.fromTimestamp(n===1e9?new M(t+1,0):new M(t,n));return new st(s,V.empty(),e)}function Pc(r){return new st(r.readTime,r.key,Cn)}class st{constructor(e,t,n){this.readTime=e,this.documentKey=t,this.largestBatchId=n}static min(){return new st(b.min(),V.empty(),Cn)}static max(){return new st(b.max(),V.empty(),Cn)}}function xc(r,e){let t=r.readTime.compareTo(e.readTime);return t!==0?t:(t=V.comparator(r.documentKey,e.documentKey),t!==0?t:N(r.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bc{constructor(e,t=null,n=[],s=[],i=null,a=null,o=null){this.path=e,this.collectionGroup=t,this.orderBy=n,this.filters=s,this.limit=i,this.startAt=a,this.endAt=o,this.Fe=null}}function Hi(r,e=null,t=[],n=[],s=null,i=null,a=null){return new bc(r,e,t,n,s,i,a)}function co(r){const e=S(r);if(e.Fe===null){let t=e.path.canonicalString();e.collectionGroup!==null&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map((n=>is(n))).join(","),t+="|ob:",t+=e.orderBy.map((n=>(function(i){return i.field.canonicalString()+i.dir})(n))).join(","),Bn(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map((n=>$t(n))).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map((n=>$t(n))).join(",")),e.Fe=t}return e.Fe}function lo(r,e){if(r.limit!==e.limit||r.orderBy.length!==e.orderBy.length)return!1;for(let t=0;t<r.orderBy.length;t++)if(!vc(r.orderBy[t],e.orderBy[t]))return!1;if(r.filters.length!==e.filters.length)return!1;for(let t=0;t<r.filters.length;t++)if(!ao(r.filters[t],e.filters[t]))return!1;return r.collectionGroup===e.collectionGroup&&!!r.path.isEqual(e.path)&&!!Qi(r.startAt,e.startAt)&&Qi(r.endAt,e.endAt)}function pt(r){return!!r.isCorePipeline}function ho(r){return!!r.path&&V.isDocumentKey(r.path)&&r.collectionGroup===null&&r.filters.length===0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kt{constructor(e,t=null,n=[],s=[],i=null,a="F",o=null,u=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=n,this.filters=s,this.limit=i,this.limitType=a,this.startAt=o,this.endAt=u,this.Oe=null,this.Me=null,this.Ne=null,this.startAt,this.endAt}}function Cc(r,e,t,n,s,i,a,o){return new Kt(r,e,t,n,s,i,a,o)}function Cr(r){return new Kt(r)}function Yi(r){return r.filters.length===0&&r.limit===null&&r.startAt==null&&r.endAt==null&&(r.explicitOrderBy.length===0||r.explicitOrderBy.length===1&&r.explicitOrderBy[0].field.isKeyField())}function Sc(r){return V.isDocumentKey(r.path)&&r.collectionGroup===null&&r.filters.length===0}function fo(r){return r.collectionGroup!==null}function ln(r){const e=S(r);if(e.Oe===null){e.Oe=[];const t=new Set;for(const i of e.explicitOrderBy)e.Oe.push(i),t.add(i.field.canonicalString());const n=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(a){let o=new W(Te.comparator);return a.filters.forEach((u=>{u.getFlattenedFilters().forEach((c=>{c.isInequality()&&(o=o.add(c.field))}))})),o})(e).forEach((i=>{t.has(i.canonicalString())||i.isKeyField()||e.Oe.push(new bn(i,n))})),t.has(Te.keyField().canonicalString())||e.Oe.push(new bn(Te.keyField(),n))}return e.Oe}function ke(r){const e=S(r);return e.Me||(e.Me=Nc(e,ln(r))),e.Me}function Nc(r,e){if(r.limitType==="F")return Hi(r.path,r.collectionGroup,e,r.filters,r.limit,r.startAt,r.endAt);{e=e.map((s=>{const i=s.dir==="desc"?"asc":"desc";return new bn(s.field,i)}));const t=r.endAt?new gr(r.endAt.position,r.endAt.inclusive):null,n=r.startAt?new gr(r.startAt.position,r.startAt.inclusive):null;return Hi(r.path,r.collectionGroup,e,r.filters,r.limit,t,n)}}function as(r,e){const t=r.filters.concat([e]);return new Kt(r.path,r.collectionGroup,r.explicitOrderBy.slice(),t,r.limit,r.limitType,r.startAt,r.endAt)}function Dc(r,e){const t=r.explicitOrderBy.concat([e]);return new Kt(r.path,r.collectionGroup,t,r.filters.slice(),r.limit,r.limitType,r.startAt,r.endAt)}function yr(r,e,t){return new Kt(r.path,r.collectionGroup,r.explicitOrderBy.slice(),r.filters.slice(),e,t,r.startAt,r.endAt)}function kc(r,e){return lo(ke(r),ke(e))&&r.limitType===e.limitType}function hn(r){return`Query(target=${(function(t){let n=t.path.canonicalString();return t.collectionGroup!==null&&(n+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(n+=`, filters: [${t.filters.map((s=>oo(s))).join(", ")}]`),Bn(t.limit)||(n+=", limit: "+t.limit),t.orderBy.length>0&&(n+=`, orderBy: [${t.orderBy.map((s=>(function(a){return`${a.field.canonicalString()} (${a.dir})`})(s))).join(", ")}]`),t.startAt&&(n+=", startAt: ",n+=t.startAt.inclusive?"b:":"a:",n+=t.startAt.position.map((s=>$t(s))).join(",")),t.endAt&&(n+=", endAt: ",n+=t.endAt.inclusive?"a:":"b:",n+=t.endAt.position.map((s=>$t(s))).join(",")),`Target(${n})`})(ke(r))}; limitType=${r.limitType})`}function Sr(r,e){return e.isFoundDocument()&&(function(n,s){const i=s.key.path;return n.collectionGroup!==null?s.key.hasCollectionId(n.collectionGroup)&&n.path.isPrefixOf(i):V.isDocumentKey(n.path)?n.path.isEqual(i):n.path.isImmediateParentOf(i)})(r,e)&&(function(n,s){for(const i of ln(n))if(!i.field.isKeyField()&&s.data.field(i.field)===null)return!1;return!0})(r,e)&&(function(n,s){for(const i of n.filters)if(!i.matches(s))return!1;return!0})(r,e)&&(function(n,s){return!(n.startAt&&!(function(a,o,u){const c=Wi(a,o,u);return a.inclusive?c<=0:c<0})(n.startAt,ln(n),s)||n.endAt&&!(function(a,o,u){const c=Wi(a,o,u);return a.inclusive?c>=0:c>0})(n.endAt,ln(n),s))})(r,e)}function Ss(r){return(e,t)=>{let n=!1;for(const s of ln(r)){const i=Lc(s,e,t);if(i!==0)return i;n=n||s.field.isKeyField()}return 0}}function Lc(r,e,t){const n=r.field.isKeyField()?V.comparator(e.key,t.key):(function(i,a,o){const u=a.data.field(i),c=o.data.field(i);return u!==null&&c!==null?pe(u,c):A(42886)})(r.field,e,t);switch(r.dir){case"asc":return n;case"desc":return-1*n;default:return A(19790,{direction:r.dir})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Oc{constructor(e,t){this.count=e,this.unchangedNames=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var G,k;function mo(r){switch(r){case p.OK:return A(64938);case p.CANCELLED:case p.UNKNOWN:case p.DEADLINE_EXCEEDED:case p.RESOURCE_EXHAUSTED:case p.INTERNAL:case p.UNAVAILABLE:case p.UNAUTHENTICATED:return!1;case p.INVALID_ARGUMENT:case p.NOT_FOUND:case p.ALREADY_EXISTS:case p.PERMISSION_DENIED:case p.FAILED_PRECONDITION:case p.ABORTED:case p.OUT_OF_RANGE:case p.UNIMPLEMENTED:case p.DATA_LOSS:return!0;default:return A(15467,{code:r})}}function po(r){if(r===void 0)return Ge("GRPC error has no .code"),p.UNKNOWN;switch(r){case G.OK:return p.OK;case G.CANCELLED:return p.CANCELLED;case G.UNKNOWN:return p.UNKNOWN;case G.DEADLINE_EXCEEDED:return p.DEADLINE_EXCEEDED;case G.RESOURCE_EXHAUSTED:return p.RESOURCE_EXHAUSTED;case G.INTERNAL:return p.INTERNAL;case G.UNAVAILABLE:return p.UNAVAILABLE;case G.UNAUTHENTICATED:return p.UNAUTHENTICATED;case G.INVALID_ARGUMENT:return p.INVALID_ARGUMENT;case G.NOT_FOUND:return p.NOT_FOUND;case G.ALREADY_EXISTS:return p.ALREADY_EXISTS;case G.PERMISSION_DENIED:return p.PERMISSION_DENIED;case G.FAILED_PRECONDITION:return p.FAILED_PRECONDITION;case G.ABORTED:return p.ABORTED;case G.OUT_OF_RANGE:return p.OUT_OF_RANGE;case G.UNIMPLEMENTED:return p.UNIMPLEMENTED;case G.DATA_LOSS:return p.DATA_LOSS;default:return A(39323,{code:r})}}(k=G||(G={}))[k.OK=0]="OK",k[k.CANCELLED=1]="CANCELLED",k[k.UNKNOWN=2]="UNKNOWN",k[k.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",k[k.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",k[k.NOT_FOUND=5]="NOT_FOUND",k[k.ALREADY_EXISTS=6]="ALREADY_EXISTS",k[k.PERMISSION_DENIED=7]="PERMISSION_DENIED",k[k.UNAUTHENTICATED=16]="UNAUTHENTICATED",k[k.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",k[k.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",k[k.ABORTED=10]="ABORTED",k[k.OUT_OF_RANGE=11]="OUT_OF_RANGE",k[k.UNIMPLEMENTED=12]="UNIMPLEMENTED",k[k.INTERNAL=13]="INTERNAL",k[k.UNAVAILABLE=14]="UNAVAILABLE",k[k.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pt{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),n=this.inner[t];if(n!==void 0){for(const[s,i]of n)if(this.equalsFn(s,e))return i}}has(e){return this.get(e)!==void 0}set(e,t){const n=this.mapKeyFn(e),s=this.inner[n];if(s===void 0)return this.inner[n]=[[e,t]],void this.innerSize++;for(let i=0;i<s.length;i++)if(this.equalsFn(s[i][0],e))return void(s[i]=[e,t]);s.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),n=this.inner[t];if(n===void 0)return!1;for(let s=0;s<n.length;s++)if(this.equalsFn(n[s][0],e))return n.length===1?delete this.inner[t]:n.splice(s,1),this.innerSize--,!0;return!1}forEach(e){ft(this.inner,((t,n)=>{for(const[s,i]of n)e(s,i)}))}isEmpty(){return Da(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mc=new q(V.comparator);function fe(){return Mc}const _o=new q(V.comparator);function Nt(...r){let e=_o;for(const t of r)e=e.insert(t.key,t);return e}function go(r){let e=_o;return r.forEach(((t,n)=>e=e.insert(t,n.overlayedDocument))),e}function He(){return fn()}function yo(){return fn()}function fn(){return new Pt((r=>r.toString()),((r,e)=>r.isEqual(e)))}const Uc=new q(V.comparator),Fc=new W(V.comparator);function D(...r){let e=Fc;for(const t of r)e=e.add(t);return e}const qc=new W(N);function Bc(){return qc}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $c(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zc=new gt([4294967295,4294967295],0);function Xi(r){const e=$c().encode(r),t=new qu;return t.update(e),new Uint8Array(t.digest())}function Ji(r){const e=new DataView(r.buffer),t=e.getUint32(0,!0),n=e.getUint32(4,!0),s=e.getUint32(8,!0),i=e.getUint32(12,!0);return[new gt([t,n],0),new gt([s,i],0)]}class Ns{constructor(e,t,n){if(this.bitmap=e,this.padding=t,this.hashCount=n,t<0||t>=8)throw new sn(`Invalid padding: ${t}`);if(n<0)throw new sn(`Invalid hash count: ${n}`);if(e.length>0&&this.hashCount===0)throw new sn(`Invalid hash count: ${n}`);if(e.length===0&&t!==0)throw new sn(`Invalid padding when bitmap length is 0: ${t}`);this.Be=8*e.length-t,this.Le=gt.fromNumber(this.Be)}Ue(e,t,n){let s=e.add(t.multiply(gt.fromNumber(n)));return s.compare(zc)===1&&(s=new gt([s.getBits(0),s.getBits(1)],0)),s.modulo(this.Le).toNumber()}ke(e){return!!(this.bitmap[Math.floor(e/8)]&1<<e%8)}mightContain(e){if(this.Be===0)return!1;const t=Xi(e),[n,s]=Ji(t);for(let i=0;i<this.hashCount;i++){const a=this.Ue(n,s,i);if(!this.ke(a))return!1}return!0}static create(e,t,n){const s=e%8==0?0:8-e%8,i=new Uint8Array(Math.ceil(e/8)),a=new Ns(i,s,t);return n.forEach((o=>a.insert(o))),a}insert(e){if(this.Be===0)return;const t=Xi(e),[n,s]=Ji(t);for(let i=0;i<this.hashCount;i++){const a=this.Ue(n,s,i);this.Qe(a)}}Qe(e){const t=Math.floor(e/8),n=e%8;this.bitmap[t]|=1<<n}}class sn extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zn{constructor(e,t,n,s,i,a){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=n,this.documentUpdates=s,this.augmentedDocumentUpdates=i,this.resolvedLimboDocuments=a}static createSynthesizedRemoteEventForCurrentChange(e,t,n){const s=new Map;return s.set(e,jn.createSynthesizedTargetChangeForCurrentChange(e,t,n)),new zn(b.min(),s,new q(N),fe(),fe(),D())}}class jn{constructor(e,t,n,s,i){this.resumeToken=e,this.current=t,this.addedDocuments=n,this.modifiedDocuments=s,this.removedDocuments=i}static createSynthesizedTargetChangeForCurrentChange(e,t,n){return new jn(n,t,D(),D(),D())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ir{constructor(e,t,n,s){this.qe=e,this.removedTargetIds=t,this.key=n,this.Ke=s}}class Eo{constructor(e,t){this.targetId=e,this.$e=t}}class To{constructor(e,t,n=B.EMPTY_BYTE_STRING,s=null){this.state=e,this.targetIds=t,this.resumeToken=n,this.cause=s}}class Zi{constructor(e){this.targetId=e,this.We=0,this.Ge=ea(),this.je=B.EMPTY_BYTE_STRING,this.ze=!1,this.He=!0}get current(){return this.ze}get resumeToken(){return this.je}get Je(){return this.We!==0}get Ye(){return this.He}Ze(e){e.approximateByteSize()>0&&(this.He=!0,this.je=e)}Xe(){let e=D(),t=D(),n=D();return this.Ge.forEach(((s,i)=>{switch(i){case 0:e=e.add(s);break;case 2:t=t.add(s);break;case 1:n=n.add(s);break;default:A(38017,{changeType:i})}})),new jn(this.je,this.ze,e,t,n)}et(){this.He=!1,this.Ge=ea()}tt(e,t){this.He=!0,this.Ge=this.Ge.insert(e,t)}nt(e){this.He=!0,this.Ge=this.Ge.remove(e)}rt(){this.We+=1}it(){this.We-=1,I(this.We>=0,3241,{We:this.We,targetId:this.targetId})}st(){this.He=!0,this.ze=!0}}const tn="WatchChangeAggregator";class jc{constructor(e){this._t=e,this.ot=new Map,this.ut=fe(),this.ct=Zn(),this.lt=fe(),this.Et=Zn(),this.ht=new q(N)}Tt(e){for(const t of e.qe)e.Ke&&e.Ke.isFoundDocument()?this.Pt(t,e.Ke):this.It(t,e.key,e.Ke);for(const t of e.removedTargetIds)this.It(t,e.key,e.Ke)}Rt(e){this.forEachTarget(e,(t=>{const n=this.ot.get(t);if(n)switch(e.state){case 0:this.At(t)&&n.Ze(e.resumeToken);break;case 1:n.it(),n.Je||n.et(),n.Ze(e.resumeToken);break;case 2:n.it(),n.Je||this.removeTarget(t);break;case 3:this.At(t)&&(n.st(),n.Ze(e.resumeToken));break;case 4:this.At(t)&&(this.Vt(t),n.Ze(e.resumeToken));break;default:A(56790,{state:e.state})}else w(tn,`handleTargetChange received targetChange for untracked target ID (${t}) with state (${e.state})`)}))}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.ot.forEach(((n,s)=>{this.At(s)&&t(s)}))}ft(e){return pt(e)?e.getPipelineSourceType()==="documents"&&e.getPipelineDocuments()?.length===1:ho(e)}dt(e){const t=e.targetId,n=e.$e.count,s=this.gt(t);if(s){const i=s.target;if(this.ft(i))if(n===0){const a=new V(pt(i)?L.fromString(i.getPipelineDocuments()[0]):i.path);this.It(t,a,J.newNoDocument(a,b.min()))}else I(n===1,20013,"Single document existence filter with count: "+n);else{const a=this.yt(t);if(a!==n){const o=this.wt(e),u=o?this.bt(o,e,a):1;if(u!==0){this.Vt(t);const c=u===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.ht=this.ht.insert(t,c)}}}}}wt(e){const t=e.$e.unchangedNames;if(!t||!t.bits)return null;const{bits:{bitmap:n="",padding:s=0},hashCount:i=0}=t;let a,o;try{a=At(n).toUint8Array()}catch(u){if(u instanceof La)return xe("Decoding the base64 bloom filter in existence filter failed ("+u.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw u}try{o=new Ns(a,s,i)}catch(u){return xe(u instanceof sn?"BloomFilter error: ":"Applying bloom filter failed: ",u),null}return o.Be===0?null:o}bt(e,t,n){return t.$e.count===n-this.vt(e,t.targetId)?0:2}vt(e,t){const n=this._t.getRemoteKeysForTarget(t);let s=0;return n.forEach((i=>{const a=this._t.xt(),o=`projects/${a.projectId}/databases/${a.database}/documents/${i.path.canonicalString()}`;e.mightContain(o)||(this.It(t,i,null),s++)})),s}Dt(e){const t=new Map;this.ot.forEach(((i,a)=>{const o=this.gt(a);if(o){if(i.current&&this.ft(o.target)){const u=pt(o.target)?L.fromString(o.target.getPipelineDocuments()[0]):o.target.path,c=new V(u);this.Ct(c).has(a)||this.Ft(a,c)||this.It(a,c,J.newNoDocument(c,e))}i.Ye&&(t.set(a,i.Xe()),i.et())}}));let n=D();this.Et.forEach(((i,a)=>{let o=!0;a.forEachWhile((u=>{const c=this.gt(u);return!c||c.purpose==="TargetPurposeLimboResolution"||(o=!1,!1)})),o&&(n=n.add(i))})),this.ut.forEach(((i,a)=>a.setReadTime(e))),this.lt.forEach(((i,a)=>a.setReadTime(e)));const s=new zn(e,t,this.ht,this.ut,this.lt,n);return this.ut=fe(),this.ct=Zn(),this.lt=fe(),this.Et=Zn(),this.ht=new q(N),s}Pt(e,t){const n=this.ot.get(e);if(!n||!this.At(e))return void w(tn,`addDocumentToTarget received document for unknown inactive target (${e})`);const s=this.Ft(e,t.key)?2:0;n.tt(t.key,s),pt(this.gt(e).target)&&this.gt(e).target.getPipelineFlavor()!=="exact"?this.lt=this.lt.insert(t.key,t):this.ut=this.ut.insert(t.key,t),this.ct=this.ct.insert(t.key,this.Ct(t.key).add(e)),this.Et=this.Et.insert(t.key,this.Ot(t.key).add(e))}It(e,t,n){const s=this.ot.get(e);s&&this.At(e)?(this.Ft(e,t)?s.tt(t,1):s.nt(t),this.Et=this.Et.insert(t,this.Ot(t).delete(e)),this.Et=this.Et.insert(t,this.Ot(t).add(e)),n&&(pt(this.gt(e).target)&&this.gt(e).target.getPipelineFlavor()!=="exact"?this.lt=this.lt.insert(t,n):this.ut=this.ut.insert(t,n))):w(tn,`removeDocumentFromTarget received document for unknown or inactive target (${e})`)}removeTarget(e){this.ot.delete(e)}yt(e){const t=this.ot.get(e);if(!t)return 0;const n=t.Xe();return this._t.getRemoteKeysForTarget(e).size+n.addedDocuments.size-n.removedDocuments.size}rt(e){let t=this.ot.get(e);t||(w(tn,`recordPendingTargetRequest set up tracking for target ID ${e}`),t=new Zi(e),this.ot.set(e,t)),t.rt()}Ot(e){let t=this.Et.get(e);return t||(t=new W(N),this.Et=this.Et.insert(e,t)),t}Ct(e){let t=this.ct.get(e);return t||(t=new W(N),this.ct=this.ct.insert(e,t)),t}At(e){const t=this.gt(e)!==null;return t||w(tn,"Detected inactive target",e),t}gt(e){const t=this.ot.get(e);return t===void 0||t.Je?null:this._t.Mt(e)}Vt(e){this.ot.set(e,new Zi(e)),this._t.getRemoteKeysForTarget(e).forEach((t=>{this.It(e,t,null)}))}Ft(e,t){return this._t.getRemoteKeysForTarget(e).has(t)}}function Zn(){return new q(V.comparator)}function ea(){return new q(V.comparator)}const Gc={asc:"ASCENDING",desc:"DESCENDING"},Kc={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},Wc={and:"AND",or:"OR"};class Qc{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function os(r,e){return r.useProto3Json||Bn(e)?e:{value:e}}function dn(r,e){return r.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function Ds(r){const e=tt(r);return new M(e.seconds,e.nanos)}function us(r,e){return r.useProto3Json?e.toBase64():e.toUint8Array()}function ar(r,e){return dn(r,e.toTimestamp())}function Ie(r){return I(!!r,49232),b.fromTimestamp(Ds(r))}function ks(r,e){return cs(r,e).canonicalString()}function cs(r,e){const t=(function(s){return new L(["projects",s.projectId,"databases",s.database])})(r).child("documents");return e===void 0?t:t.child(e)}function wo(r){const e=L.fromString(r);return I(Po(e),10190,{key:e.toString()}),e}function Sn(r,e){return ks(r.databaseId,e.path)}function mn(r,e){const t=wo(e);if(t.get(1)!==r.databaseId.projectId)throw new y(p.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+t.get(1)+" vs "+r.databaseId.projectId);if(t.get(3)!==r.databaseId.database)throw new y(p.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+t.get(3)+" vs "+r.databaseId.database);return new V(Ao(t))}function Io(r,e){return ks(r.databaseId,e)}function Hc(r){const e=wo(r);return e.length===4?L.emptyPath():Ao(e)}function ls(r){return new L(["projects",r.databaseId.projectId,"databases",r.databaseId.database]).canonicalString()}function Ao(r){return I(r.length>4&&r.get(4)==="documents",29091,{key:r.toString()}),r.popFirst(5)}function ta(r,e,t){return{name:Sn(r,e),fields:t.value.mapValue.fields}}function Yc(r,e){return"found"in e?(function(n,s){I(!!s.found,43571),s.found.name,s.found.updateTime;const i=mn(n,s.found.name),a=Ie(s.found.updateTime),o=s.found.createTime?Ie(s.found.createTime):b.min(),u=new ae({mapValue:{fields:s.found.fields}});return J.newFoundDocument(i,a,o,u)})(r,e):"missing"in e?(function(n,s){I(!!s.missing,3894),I(!!s.readTime,22933);const i=mn(n,s.missing),a=Ie(s.readTime);return J.newNoDocument(i,a)})(r,e):A(7234,{result:e})}function Xc(r,e){let t;if("targetChange"in e){e.targetChange;const n=(function(c){return c==="NO_CHANGE"?0:c==="ADD"?1:c==="REMOVE"?2:c==="CURRENT"?3:c==="RESET"?4:A(39313,{state:c})})(e.targetChange.targetChangeType||"NO_CHANGE"),s=e.targetChange.targetIds||[],i=(function(c,l){return c.useProto3Json?(I(l===void 0||typeof l=="string",58123),B.fromBase64String(l||"")):(I(l===void 0||l instanceof Buffer||l instanceof Uint8Array,16193),B.fromUint8Array(l||new Uint8Array))})(r,e.targetChange.resumeToken),a=e.targetChange.cause,o=a&&(function(c){const l=c.code===void 0?p.UNKNOWN:po(c.code);return new y(l,c.message||"")})(a);t=new To(n,s,i,o||null)}else if("documentChange"in e){e.documentChange;const n=e.documentChange;n.document,n.document.name,n.document.updateTime;const s=mn(r,n.document.name),i=Ie(n.document.updateTime),a=n.document.createTime?Ie(n.document.createTime):b.min(),o=new ae({mapValue:{fields:n.document.fields}}),u=J.newFoundDocument(s,i,a,o),c=n.targetIds||[],l=n.removedTargetIds||[];t=new ir(c,l,u.key,u)}else if("documentDelete"in e){e.documentDelete;const n=e.documentDelete;n.document;const s=mn(r,n.document),i=n.readTime?Ie(n.readTime):b.min(),a=J.newNoDocument(s,i),o=n.removedTargetIds||[];t=new ir([],o,a.key,a)}else if("documentRemove"in e){e.documentRemove;const n=e.documentRemove;n.document;const s=mn(r,n.document),i=n.removedTargetIds||[];t=new ir([],i,s,null)}else{if(!("filter"in e))return A(11601,{Nt:e});{e.filter;const n=e.filter;n.targetId;const{count:s=0,unchangedNames:i}=n,a=new Oc(s,i),o=n.targetId;t=new Eo(o,a)}}return t}function Vo(r,e){let t;if(e instanceof $n)t={update:ta(r,e.key,e.value)};else if(e instanceof Cs)t={delete:Sn(r,e.key)};else if(e instanceof dt)t={update:ta(r,e.key,e.data),updateMask:ol(e.fieldMask)};else{if(!(e instanceof no))return A(16599,{Bt:e.type});t={verify:Sn(r,e.key)}}return e.fieldTransforms.length>0&&(t.updateTransforms=e.fieldTransforms.map((n=>(function(i,a){const o=a.transform;if(o instanceof vn)return{fieldPath:a.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(o instanceof Rn)return{fieldPath:a.field.canonicalString(),appendMissingElements:{values:o.elements}};if(o instanceof Pn)return{fieldPath:a.field.canonicalString(),removeAllFromArray:{values:o.elements}};if(o instanceof xn)return{fieldPath:a.field.canonicalString(),increment:o.xe};if(o instanceof pr)return{fieldPath:a.field.canonicalString(),minimum:o.xe};if(o instanceof _r)return{fieldPath:a.field.canonicalString(),maximum:o.xe};throw A(20930,{transform:a.transform})})(0,n)))),e.precondition.isNone||(t.currentDocument=(function(s,i){return i.updateTime!==void 0?{updateTime:ar(s,i.updateTime)}:i.exists!==void 0?{exists:i.exists}:A(27497)})(r,e.precondition)),t}function Jc(r,e){return r&&r.length>0?(I(e!==void 0,14353),r.map((t=>(function(s,i){let a=s.updateTime?Ie(s.updateTime):Ie(i);return a.isEqual(b.min())&&(a=Ie(i)),new mc(a,s.transformResults||[])})(t,e)))):[]}function Zc(r,e){return{documents:[Io(r,e.path)]}}function el(r,e){const t={structuredQuery:{}},n=e.path;let s;e.collectionGroup!==null?(s=n,t.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(s=n.popLast(),t.structuredQuery.from=[{collectionId:n.lastSegment()}]),t.parent=Io(r,s);const i=(function(c){if(c.length!==0)return Ro(be.create(c,"and"))})(e.filters);i&&(t.structuredQuery.where=i);const a=(function(c){if(c.length!==0)return c.map((l=>(function(d){return{field:Dt(d.field),direction:sl(d.dir)}})(l)))})(e.orderBy);a&&(t.structuredQuery.orderBy=a);const o=os(r,e.limit);return o!==null&&(t.structuredQuery.limit=o),e.startAt&&(t.structuredQuery.startAt=(function(c){return{before:c.inclusive,values:c.position}})(e.startAt)),e.endAt&&(t.structuredQuery.endAt=(function(c){return{before:!c.inclusive,values:c.position}})(e.endAt)),{Lt:t,parent:s}}function tl(r){let e=Hc(r.parent);const t=r.structuredQuery,n=t.from?t.from.length:0;let s=null;if(n>0){I(n===1,65062);const l=t.from[0];l.allDescendants?s=l.collectionId:e=e.child(l.collectionId)}let i=[];t.where&&(i=(function(h){const d=vo(h);return d instanceof be&&io(d)?d.getFilters():[d]})(t.where));let a=[];t.orderBy&&(a=(function(h){return h.map((d=>(function(T){return new bn(kt(T.field),(function(P){switch(P){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}})(T.direction))})(d)))})(t.orderBy));let o=null;t.limit&&(o=(function(h){let d;return d=typeof h=="object"?h.value:h,Bn(d)?null:d})(t.limit));let u=null;t.startAt&&(u=(function(h){const d=!!h.before,g=h.values||[];return new gr(g,d)})(t.startAt));let c=null;return t.endAt&&(c=(function(h){const d=!h.before,g=h.values||[];return new gr(g,d)})(t.endAt)),Cc(e,s,a,i,o,"F",u,c)}function nl(r,e){const t=(function(s){switch(s){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return A(28987,{purpose:s})}})(e.purpose);return t==null?null:{"goog-listen-tags":t}}function rl(r,e){return{structuredPipeline:{pipeline:{stages:e.stages.map((t=>t._toProto(r)))}}}}function vo(r){return r.unaryFilter!==void 0?(function(t){switch(t.unaryFilter.op){case"IS_NAN":const n=kt(t.unaryFilter.field);return K.create(n,"==",{doubleValue:NaN});case"IS_NULL":const s=kt(t.unaryFilter.field);return K.create(s,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const i=kt(t.unaryFilter.field);return K.create(i,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const a=kt(t.unaryFilter.field);return K.create(a,"!=",{nullValue:"NULL_VALUE"});case"OPERATOR_UNSPECIFIED":return A(61313);default:return A(60726)}})(r):r.fieldFilter!==void 0?(function(t){return K.create(kt(t.fieldFilter.field),(function(s){switch(s){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";case"OPERATOR_UNSPECIFIED":return A(58110);default:return A(50506)}})(t.fieldFilter.op),t.fieldFilter.value)})(r):r.compositeFilter!==void 0?(function(t){return be.create(t.compositeFilter.filters.map((n=>vo(n))),(function(s){switch(s){case"AND":return"and";case"OR":return"or";default:return A(1026)}})(t.compositeFilter.op))})(r):A(30097,{filter:r})}function sl(r){return Gc[r]}function il(r){return Kc[r]}function al(r){return Wc[r]}function Dt(r){return{fieldPath:r.canonicalString()}}function kt(r){return Te.fromServerFormat(r.fieldPath)}function Ro(r){return r instanceof K?(function(t){if(t.op==="=="){if(ee(t.value))return{unaryFilter:{field:Dt(t.field),op:"IS_NAN"}};if(Ee(t.value))return{unaryFilter:{field:Dt(t.field),op:"IS_NULL"}}}else if(t.op==="!="){if(ee(t.value))return{unaryFilter:{field:Dt(t.field),op:"IS_NOT_NAN"}};if(Ee(t.value))return{unaryFilter:{field:Dt(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:Dt(t.field),op:il(t.op),value:t.value}}})(r):r instanceof be?(function(t){const n=t.getFilters().map((s=>Ro(s)));return n.length===1?n[0]:{compositeFilter:{op:al(t.op),filters:n}}})(r):A(54877,{filter:r})}function ol(r){const e=[];return r.fields.forEach((t=>e.push(t.canonicalString()))),{fieldPaths:e}}function Po(r){return r.length>=4&&r.get(0)==="projects"&&r.get(2)==="databases"}function xo(r){return!!r&&typeof r._toProto=="function"&&r._protoValueType==="ProtoValue"}function Nn(r,e){const t={fields:{}};return e.forEach(((n,s)=>{if(typeof s!="string")throw new Error(`Cannot encode map with non-string key: ${s}`);t.fields[s]=n._toProto(r)})),{mapValue:t}}function bo(r){return{stringValue:r}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Nr(r){return new Qc(r,!0)}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ls{constructor(e){this.value=e}isEqual(e){return this.value===e.value}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Os{constructor(e,t){if(this.seconds=e,this.increment=t,!Number.isInteger(e)||e<0||e>4294967295)throw new Error("BsonTimestamp 'seconds' must be in the range of a 32-bit unsigned integer (0-4294967295).");if(!Number.isInteger(t)||t<0||t>4294967295)throw new Error("BsonTimestamp 'increment' must be in the range of a 32-bit unsigned integer (0-4294967295).")}isEqual(e){return this.seconds===e.seconds&&this.increment===e.increment}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class he{constructor(e,t=0){if(this.subtype=t,!Number.isInteger(t)||t<0||t>255)throw new y(p.INVALID_ARGUMENT,"The subtype for Bytes must be a value in the inclusive [0, 255] range.");this._byteString=e}static fromBase64String(e,t=0){try{return new he(B.fromBase64String(e),t)}catch(n){throw new y(p.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+n)}}static fromUint8Array(e,t=0){return new he(B.fromUint8Array(e),t)}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}get data(){return this.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+", subtype: "+this.subtype+")"}isEqual(e){return this.subtype===e.subtype&&this._byteString.isEqual(e._byteString)}toJSON(){const e={type:he._jsonSchemaVersion,bytes:this.toBase64()};return this.subtype!==0&&(e.subtype=this.subtype),e}static fromJSON(e){if(Fn(e,he._jsonSchema)){const t=e.subtype??0;return he.fromBase64String(e.bytes,t)}}}he._jsonSchemaVersion="firestore/bytes/1.0",he._jsonSchema={type:z("string",he._jsonSchemaVersion),bytes:z("string"),subtype:{...z("number"),optional:!0}};/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ms{constructor(e){this.stringValue=e,this.value=v.fromString(e)}isEqual(e){return!(!this.value.oe()||!e.value.oe())||this.value.compareTo(e.value)===0}toJSON(){return{kt:{stringValue:this.stringValue}}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dr{constructor(...e){for(let t=0;t<e.length;++t)if(e[t].length===0)throw new y(p.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new Te(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}function ul(){return new Dr(Se)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kr{constructor(e){this._methodName=e}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Le{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new y(p.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new y(p.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}_compareTo(e){return N(this._lat,e._lat)||N(this._long,e._long)}toJSON(){return{latitude:this._lat,longitude:this._long,type:Le._jsonSchemaVersion}}static fromJSON(e){if(Fn(e,Le._jsonSchema))return new Le(e.latitude,e.longitude)}}Le._jsonSchemaVersion="firestore/geoPoint/1.0",Le._jsonSchema={type:z("string",Le._jsonSchemaVersion),latitude:z("number"),longitude:z("number")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Us{constructor(e){this.value=e}isEqual(e){return this.value===e.value}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qe{constructor(){this.type="MaxKey"}static instance(){return qe.MAX_KEY_VALUE_INSTANCE||(qe.MAX_KEY_VALUE_INSTANCE=new qe),qe.MAX_KEY_VALUE_INSTANCE}}qe.MAX_KEY_VALUE_INSTANCE=null;/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Be{constructor(){this.type="MinKey"}static instance(){return Be.MIN_KEY_VALUE_INSTANCE||(Be.MIN_KEY_VALUE_INSTANCE=new Be),Be.MIN_KEY_VALUE_INSTANCE}}Be.MIN_KEY_VALUE_INSTANCE=null;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ie{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}ie.UNAUTHENTICATED=new ie(null),ie.GOOGLE_CREDENTIALS=new ie("google-credentials-uid"),ie.FIRST_PARTY=new ie("first-party-uid"),ie.MOCK_USER=new ie("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Oe{constructor(){this.promise=new Promise(((e,t)=>{this.resolve=e,this.reject=t}))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Co{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class cl{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable((()=>t(ie.UNAUTHENTICATED)))}shutdown(){}}class ll{constructor(e){this.token=e,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(e,t){this.changeListener=t,e.enqueueRetryable((()=>t(this.token.user)))}shutdown(){this.changeListener=null}}class hl{constructor(e){this.Qt=e,this.currentUser=ie.UNAUTHENTICATED,this.qt=0,this.forceRefresh=!1,this.auth=null}start(e,t){I(this.Kt===void 0,42304);let n=this.qt;const s=u=>this.qt!==n?(n=this.qt,t(u)):Promise.resolve();let i=new Oe;this.Kt=()=>{this.qt++,this.currentUser=this.$t(),i.resolve(),i=new Oe,e.enqueueRetryable((()=>s(this.currentUser)))};const a=()=>{const u=i;e.enqueueRetryable((async()=>{await u.promise,await s(this.currentUser)}))},o=u=>{w("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=u,this.Kt&&(this.auth.addAuthTokenListener(this.Kt),a())};this.Qt.onInit((u=>o(u))),setTimeout((()=>{if(!this.auth){const u=this.Qt.getImmediate({optional:!0});u?o(u):(w("FirebaseAuthCredentialsProvider","Auth not yet detected"),i.resolve(),i=new Oe)}}),0),a()}getToken(){const e=this.qt,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then((n=>this.qt!==e?(w("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):n?(I(typeof n.accessToken=="string",31837,{Wt:n}),new Co(n.accessToken,this.currentUser)):null)):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.Kt&&this.auth.removeAuthTokenListener(this.Kt),this.Kt=void 0}$t(){const e=this.auth&&this.auth.getUid();return I(e===null||typeof e=="string",2055,{Gt:e}),new ie(e)}}class fl{constructor(e,t,n){this.jt=e,this.zt=t,this.Ht=n,this.type="FirstParty",this.user=ie.FIRST_PARTY,this.Jt=new Map}Yt(){return this.Ht?this.Ht():null}get headers(){this.Jt.set("X-Goog-AuthUser",this.jt);const e=this.Yt();return e&&this.Jt.set("Authorization",e),this.zt&&this.Jt.set("X-Goog-Iam-Authorization-Token",this.zt),this.Jt}}class dl{constructor(e,t,n){this.jt=e,this.zt=t,this.Ht=n}getToken(){return Promise.resolve(new fl(this.jt,this.zt,this.Ht))}start(e,t){e.enqueueRetryable((()=>t(ie.FIRST_PARTY)))}shutdown(){}invalidateToken(){}}class na{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class ml{constructor(e,t){this.Zt=t,this.forceRefresh=!1,this.appCheck=null,this.Xt=null,this.en=null,Ku(e)&&e.settings.appCheckToken&&(this.en=e.settings.appCheckToken)}start(e,t){I(this.Kt===void 0,3512);const n=i=>{i.error!=null&&w("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${i.error.message}`);const a=i.token!==this.Xt;return this.Xt=i.token,w("FirebaseAppCheckTokenProvider",`Received ${a?"new":"existing"} token.`),a?t(i.token):Promise.resolve()};this.Kt=i=>{e.enqueueRetryable((()=>n(i)))};const s=i=>{w("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=i,this.Kt&&this.appCheck.addTokenListener(this.Kt)};this.Zt.onInit((i=>s(i))),setTimeout((()=>{if(!this.appCheck){const i=this.Zt.getImmediate({optional:!0});i?s(i):w("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}}),0)}getToken(){if(this.en)return Promise.resolve(new na(this.en));const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then((t=>t?(I(typeof t.token=="string",44558,{tokenResult:t}),this.Xt=t.token,new na(t.token)):null)):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.Kt&&this.appCheck.removeTokenListener(this.Kt),this.Kt=void 0}}function So(r){const e={};return r.timeoutSeconds!==void 0&&(e.timeoutSeconds=r.timeoutSeconds),e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pl{tn(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ra="ConnectivityMonitor";class sa{constructor(){this.nn=()=>this.rn(),this.sn=()=>this._n(),this.an=[],this.un()}tn(e){this.an.push(e)}shutdown(){window.removeEventListener("online",this.nn),window.removeEventListener("offline",this.sn)}un(){window.addEventListener("online",this.nn),window.addEventListener("offline",this.sn)}rn(){w(ra,"Network connectivity changed: AVAILABLE");for(const e of this.an)e(0)}_n(){w(ra,"Network connectivity changed: UNAVAILABLE");for(const e of this.an)e(1)}static cn(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let er=null;function hs(){return er===null?er=(function(){return 268435456+Math.round(2147483648*Math.random())})():er++,"0x"+er.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Yr="RestConnection",_l={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery",ExecutePipeline:"executePipeline"};class gl{get En(){return!1}constructor(e){this.databaseInfo=e,this.databaseId=e.databaseId;const t=e.ssl?"https":"http",n=encodeURIComponent(this.databaseId.projectId),s=encodeURIComponent(this.databaseId.database);this.hn=t+"://"+e.host,this.Tn=`projects/${n}/databases/${s}`,this.Pn=this.databaseId.database===cr?`project_id=${n}`:`project_id=${n}&database_id=${s}`}In(e,t,n,s,i){const a=hs(),o=this.Rn(e,t.toUriEncodedString());w(Yr,`Sending RPC '${e}' ${a}:`,o,n);const u={"google-cloud-resource-prefix":this.Tn,"x-goog-request-params":this.Pn};this.An(u,s,i);const{host:c}=new URL(o),l=Sa(c);return this.Vn(e,o,u,n,l).then((h=>(w(Yr,`Received RPC '${e}' ${a}: `,h),h)),(h=>{throw xe(Yr,`RPC '${e}' ${a} failed with error: `,h,"url: ",o,"request:",n),h}))}fn(e,t,n,s,i,a){return this.In(e,t,n,s,i)}An(e,t,n){if(e["X-Goog-Api-Client"]=(function(){return"gl-js/ fire/"+Gt})(),e["Content-Type"]="text/plain",this.databaseInfo.appId&&(e["X-Firebase-GMPID"]=this.databaseInfo.appId),t&&t.headers.forEach(((s,i)=>e[i]=s)),n&&n.headers.forEach(((s,i)=>e[i]=s)),this.databaseInfo._customHeaders)for(const s of Object.keys(this.databaseInfo._customHeaders))e[s]=this.databaseInfo._customHeaders[s]}Rn(e,t){const n=_l[e];let s=`${this.hn}/v1/${t}:${n}`;return this.databaseInfo.apiKey&&(s=`${s}?key=${encodeURIComponent(this.databaseInfo.apiKey)}`),s}terminate(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class yl{constructor(e){this.dn=e.dn,this.mn=e.mn}pn(e){this.gn=e}yn(e){this.wn=e}bn(e){this.Sn=e}onMessage(e){this.xn=e}close(){this.mn()}send(e){this.dn(e)}vn(){this.gn()}Dn(){this.wn()}Cn(e){this.Sn(e)}Fn(e){this.xn(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const se="WebChannelConnection",nn=(r,e,t)=>{r.listen(e,(n=>{try{t(n)}catch(s){setTimeout((()=>{throw s}),0)}}))};class Ut extends gl{constructor(e){super(e),this.On=[],this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}static Mn(){if(!Ut.Nn){const e=Bu();nn(e,$u.STAT_EVENT,(t=>{t.stat===bi.PROXY?w(se,"STAT_EVENT: detected buffering proxy"):t.stat===bi.NOPROXY&&w(se,"STAT_EVENT: detected no buffering proxy")})),Ut.Nn=!0}}Vn(e,t,n,s,i){const a=hs();return new Promise(((o,u)=>{const c=new zu;c.setWithCredentials(!0),c.listenOnce(ju.COMPLETE,(()=>{try{switch(c.getLastErrorCode()){case Qr.NO_ERROR:const h=c.getResponseJson();w(se,`XHR for RPC '${e}' ${a} received:`,JSON.stringify(h)),o(h);break;case Qr.TIMEOUT:w(se,`RPC '${e}' ${a} timed out`),u(new y(p.DEADLINE_EXCEEDED,"Request time out"));break;case Qr.HTTP_ERROR:const d=c.getStatus();if(w(se,`RPC '${e}' ${a} failed with status:`,d,"response text:",c.getResponseText()),d>0){let g=c.getResponseJson();Array.isArray(g)&&(g=g[0]);const T=g?.error;if(T&&T.status&&T.message){const C=(function(O){const j=O.toLowerCase().replace(/_/g,"-");return Object.values(p).indexOf(j)>=0?j:p.UNKNOWN})(T.status);u(new y(C,T.message))}else u(new y(p.UNKNOWN,"Server responded with status "+c.getStatus()))}else u(new y(p.UNAVAILABLE,"Connection failed."));break;default:A(9055,{Bn:e,streamId:a,Ln:c.getLastErrorCode(),Un:c.getLastError()})}}finally{w(se,`RPC '${e}' ${a} completed.`)}}));const l=JSON.stringify(s);w(se,`RPC '${e}' ${a} sending request:`,s),c.send(t,"POST",l,n,15)}))}kn(e,t,n){const s=hs(),i=[this.hn,"/","google.firestore.v1.Firestore","/",e,"/channel"],a=this.createWebChannelTransport(),o={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},u=this.longPollingOptions.timeoutSeconds;u!==void 0&&(o.longPollingTimeout=Math.round(1e3*u)),this.useFetchStreams&&(o.useFetchStreams=!0),this.An(o.initMessageHeaders,t,n),o.encodeInitMessageHeaders=!0;const c=i.join("");w(se,`Creating RPC '${e}' stream ${s}: ${c}`,o);const l=a.createWebChannel(c,o);this.Qn(l);let h=!1,d=!1;const g=new yl({dn:T=>{d?w(se,`Not sending because RPC '${e}' stream ${s} is closed:`,T):(h||(w(se,`Opening RPC '${e}' stream ${s} transport.`),l.open(),h=!0),w(se,`RPC '${e}' stream ${s} sending:`,T),l.send(T))},mn:()=>l.close()});return nn(l,Yn.EventType.OPEN,(()=>{d||(w(se,`RPC '${e}' stream ${s} transport opened.`),g.vn())})),nn(l,Yn.EventType.CLOSE,(()=>{d||(d=!0,w(se,`RPC '${e}' stream ${s} transport closed`),g.Cn(),this.qn(l))})),nn(l,Yn.EventType.ERROR,(T=>{d||(d=!0,xe(se,`RPC '${e}' stream ${s} transport errored. Name:`,T.name,"Message:",T.message),g.Cn(new y(p.UNAVAILABLE,"The operation could not be completed")))})),nn(l,Yn.EventType.MESSAGE,(T=>{if(!d){const C=T.data[0];I(!!C,16349);const P=C,O=P?.error||P[0]?.error;if(O){w(se,`RPC '${e}' stream ${s} received error:`,O);const j=O.status;let _e=(function(Qn){const Hn=G[Qn];if(Hn!==void 0)return po(Hn)})(j),mt=O.message;j==="NOT_FOUND"&&mt.includes("database")&&mt.includes("does not exist")&&mt.includes(this.databaseId.database)&&xe(`Database '${this.databaseId.database}' not found. Please check your project configuration.`),_e===void 0&&(_e=p.INTERNAL,mt="Unknown error status: "+j+" with message "+O.message),d=!0,g.Cn(new y(_e,mt)),l.close()}else w(se,`RPC '${e}' stream ${s} received:`,C),g.Fn(C)}})),Ut.Mn(),setTimeout((()=>{g.Dn()}),0),g}terminate(){this.On.forEach((e=>e.close())),this.On=[]}Qn(e){this.On.push(e)}qn(e){this.On=this.On.filter((t=>t===e))}An(e,t,n){super.An(e,t,n),this.databaseInfo.apiKey&&(e["x-goog-api-key"]=this.databaseInfo.apiKey)}createWebChannelTransport(){return Gu()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function El(r){return new Ut(r)}Ut.Nn=!1;class Fs{constructor(e,t,n=1e3,s=1.5,i=6e4){this.Kn=e,this.timerId=t,this.$n=n,this.Wn=s,this.Gn=i,this.jn=0,this.zn=null,this.Hn=Date.now(),this.reset()}reset(){this.jn=0}Jn(){this.jn=this.Gn}Yn(e){this.cancel();const t=Math.floor(this.jn+this.Zn()),n=Math.max(0,Date.now()-this.Hn),s=Math.max(0,t-n);s>0&&w("ExponentialBackoff",`Backing off for ${s} ms (base delay: ${this.jn} ms, delay with jitter: ${t} ms, last attempt: ${n} ms ago)`),this.zn=this.Kn.enqueueAfterDelay(this.timerId,s,(()=>(this.Hn=Date.now(),e()))),this.jn*=this.Wn,this.jn<this.$n&&(this.jn=this.$n),this.jn>this.Gn&&(this.jn=this.Gn)}Xn(){this.zn!==null&&(this.zn.skipDelay(),this.zn=null)}cancel(){this.zn!==null&&(this.zn.cancel(),this.zn=null)}Zn(){return(Math.random()-.5)*this.jn}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ia="PersistentStream";class No{constructor(e,t,n,s,i,a,o,u){this.Kn=e,this.er=n,this.tr=s,this.connection=i,this.authCredentialsProvider=a,this.appCheckCredentialsProvider=o,this.listener=u,this.state=0,this.nr=0,this.rr=null,this.ir=null,this.stream=null,this.sr=0,this._r=new Fs(e,t)}ar(){return this.state===1||this.state===5||this.ur()}ur(){return this.state===2||this.state===3}start(){this.sr=0,this.state!==4?this.auth():this.cr()}async stop(){this.ar()&&await this.close(0)}lr(){this.state=0,this._r.reset()}Er(){this.ur()&&this.rr===null&&(this.rr=this.Kn.enqueueAfterDelay(this.er,6e4,(()=>this.hr())))}Tr(e){this.Pr(),this.stream.send(e)}async hr(){if(this.ur())return this.close(0)}Pr(){this.rr&&(this.rr.cancel(),this.rr=null)}Ir(){this.ir&&(this.ir.cancel(),this.ir=null)}async close(e,t){this.Pr(),this.Ir(),this._r.cancel(),this.nr++,e!==4?this._r.reset():t&&t.code===p.RESOURCE_EXHAUSTED?(Ge(t.toString()),Ge("Using maximum backoff delay to prevent overloading the backend."),this._r.Jn()):t&&t.code===p.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.Rr(),this.stream.close(),this.stream=null),this.state=e,await this.listener.bn(t)}Rr(){}auth(){this.state=1;const e=this.Ar(this.nr),t=this.nr;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then((([n,s])=>{this.nr===t&&this.Vr(n,s)}),(n=>{e((()=>{const s=new y(p.UNKNOWN,"Fetching auth token failed: "+n.message);return this.dr(s)}))}))}Vr(e,t){const n=this.Ar(this.nr);this.stream=this.mr(e,t),this.stream.pn((()=>{n((()=>this.listener.pn()))})),this.stream.yn((()=>{n((()=>(this.state=2,this.ir=this.Kn.enqueueAfterDelay(this.tr,1e4,(()=>(this.ur()&&(this.state=3),Promise.resolve()))),this.listener.yn())))})),this.stream.bn((s=>{n((()=>this.dr(s)))})),this.stream.onMessage((s=>{n((()=>++this.sr==1?this.pr(s):this.onNext(s)))}))}cr(){this.state=5,this._r.Yn((async()=>{this.state=0,this.start()}))}dr(e){return w(ia,`close with error: ${e}`),this.stream=null,this.close(4,e)}Ar(e){return t=>{this.Kn.enqueueAndForget((()=>this.nr===e?t():(w(ia,"stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve())))}}}class Tl extends No{constructor(e,t,n,s,i,a){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,n,s,a),this.serializer=i}mr(e,t){return this.connection.kn("Listen",e,t)}pr(e){return this.onNext(e)}onNext(e){this._r.reset();const t=Xc(this.serializer,e),n=(function(i){if(!("targetChange"in i))return b.min();const a=i.targetChange;return a.targetIds&&a.targetIds.length?b.min():a.readTime?Ie(a.readTime):b.min()})(e);return this.listener.gr(t,n)}yr(e){const t={};t.database=ls(this.serializer),t.addTarget=(function(i,a){let o;const u=a.target;if(o=pt(u)?{pipelineQuery:rl(i,u)}:ho(u)?{documents:Zc(i,u)}:{query:el(i,u).Lt},o.targetId=a.targetId,a.resumeToken.approximateByteSize()>0){o.resumeToken=us(i,a.resumeToken);const c=os(i,a.expectedCount);c!==null&&(o.expectedCount=c)}else if(a.snapshotVersion.compareTo(b.min())>0){o.readTime=dn(i,a.snapshotVersion.toTimestamp());const c=os(i,a.expectedCount);c!==null&&(o.expectedCount=c)}return o})(this.serializer,e);const n=nl(this.serializer,e);n&&(t.labels=n),this.Tr(t)}wr(e){const t={};t.database=ls(this.serializer),t.removeTarget=e,this.Tr(t)}}class wl extends No{constructor(e,t,n,s,i,a){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,n,s,a),this.serializer=i}get br(){return this.sr>0}start(){this.lastStreamToken=void 0,super.start()}Rr(){this.br&&this.Sr([])}mr(e,t){return this.connection.kn("Write",e,t)}pr(e){return I(!!e.streamToken,31322),this.lastStreamToken=e.streamToken,I(!e.writeResults||e.writeResults.length===0,55816),this.listener.vr()}onNext(e){I(!!e.streamToken,12678),this.lastStreamToken=e.streamToken,this._r.reset();const t=Jc(e.writeResults,e.commitTime),n=Ie(e.commitTime);return this.listener.Dr(n,t)}Cr(){const e={};e.database=ls(this.serializer),this.Tr(e)}Sr(e){const t={streamToken:this.lastStreamToken,writes:e.map((n=>Vo(this.serializer,n)))};this.Tr(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Il{}class Al extends Il{constructor(e,t,n,s){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=n,this.serializer=s,this.Fr=!1}Or(){if(this.Fr)throw new y(p.FAILED_PRECONDITION,"The client has already been terminated.")}In(e,t,n,s){return this.Or(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then((([i,a])=>this.connection.In(e,cs(t,n),s,i,a))).catch((i=>{throw i.name==="FirebaseError"?(i.code===p.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),i):new y(p.UNKNOWN,i.toString())}))}fn(e,t,n,s,i){return this.Or(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then((([a,o])=>this.connection.fn(e,cs(t,n),s,a,o,i))).catch((a=>{throw a.name==="FirebaseError"?(a.code===p.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),a):new y(p.UNKNOWN,a.toString())}))}terminate(){this.Fr=!0,this.connection.terminate()}}function Vl(r,e,t,n){return new Al(r,e,t,n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vl="ComponentProvider",aa=new Map;function Rl(r,e,t,n,s){return new sc(r,e,t,s.host,s.ssl,s.experimentalForceLongPolling,s.experimentalAutoDetectLongPolling,So(s.experimentalLongPollingOptions),s.useFetchStreams,s.isUsingEmulator,n,s._customHeaders,s.grpcFlowControlWindow)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const oa={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0},Do=41943040;class ce{static withCacheSize(e){return new ce(e,ce.DEFAULT_COLLECTION_PERCENTILE,ce.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}constructor(e,t,n){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=n}}ce.DEFAULT_COLLECTION_PERCENTILE=10,ce.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,ce.DEFAULT=new ce(Do,ce.DEFAULT_COLLECTION_PERCENTILE,ce.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),ce.DISABLED=new ce(-1,0,0);/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Lr{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=n=>this.Mr(n),this.Nr=n=>t.writeSequenceNumber(n))}Mr(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.Nr&&this.Nr(e),e}}Lr.Br=-1;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Pl="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class xl{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach((e=>e()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Wt(r){if(r.code!==p.FAILED_PRECONDITION||r.message!==Pl)throw r;w("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e((t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)}),(t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)}))}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&A(59440),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new _(((n,s)=>{this.nextCallback=i=>{this.wrapSuccess(e,i).next(n,s)},this.catchCallback=i=>{this.wrapFailure(t,i).next(n,s)}}))}toPromise(){return new Promise(((e,t)=>{this.next(e,t)}))}wrapUserFunction(e){try{const t=e();return t instanceof _?t:_.resolve(t)}catch(t){return _.reject(t)}}wrapSuccess(e,t){return e?this.wrapUserFunction((()=>e(t))):_.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction((()=>e(t))):_.reject(t)}static resolve(e){return new _(((t,n)=>{t(e)}))}static reject(e){return new _(((t,n)=>{n(e)}))}static waitFor(e){return new _(((t,n)=>{let s=0,i=0,a=!1;e.forEach((o=>{++s,o.next((()=>{++i,a&&i===s&&t()}),(u=>n(u)))})),a=!0,i===s&&t()}))}static or(e){let t=_.resolve(!1);for(const n of e)t=t.next((s=>s?_.resolve(s):n()));return t}static forEach(e,t){const n=[];return e.forEach(((s,i)=>{n.push(t.call(this,s,i))})),this.waitFor(n)}static mapArray(e,t){return new _(((n,s)=>{const i=e.length,a=new Array(i);let o=0;for(let u=0;u<i;u++){const c=u;t(e[c]).next((l=>{a[c]=l,++o,o===i&&n(a)}),(l=>s(l)))}}))}static doWhile(e,t){return new _(((n,s)=>{const i=()=>{e()===!0?t().next((()=>{i()}),s):n()};i()}))}}function bl(r){const e=r.match(/Android ([\d.]+)/i),t=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(t)}function Qt(r){return r.name==="IndexedDbTransactionError"}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ua="LruGarbageCollector",Cl=1048576;function ca([r,e],[t,n]){const s=N(r,t);return s===0?N(e,n):s}class Sl{constructor(e){this.ai=e,this.buffer=new W(ca),this.ui=0}ci(){return++this.ui}li(e){const t=[e,this.ci()];if(this.buffer.size<this.ai)this.buffer=this.buffer.add(t);else{const n=this.buffer.last();ca(t,n)<0&&(this.buffer=this.buffer.delete(n).add(t))}}get maxValue(){return this.buffer.last()[0]}}class Nl{constructor(e,t,n){this.garbageCollector=e,this.asyncQueue=t,this.localStore=n,this.Ei=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.hi(6e4)}stop(){this.Ei&&(this.Ei.cancel(),this.Ei=null)}get started(){return this.Ei!==null}hi(e){w(ua,`Garbage collection scheduled in ${e}ms`),this.Ei=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,(async()=>{this.Ei=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){Qt(t)?w(ua,"Ignoring IndexedDB error during garbage collection: ",t):await Wt(t)}await this.hi(3e5)}))}}class Dl{constructor(e,t){this.Ti=e,this.params=t}calculateTargetCount(e,t){return this.Ti.Pi(e).next((n=>Math.floor(t/100*n)))}nthSequenceNumber(e,t){if(t===0)return _.resolve(Lr.Br);const n=new Sl(t);return this.Ti.forEachTarget(e,(s=>n.li(s.sequenceNumber))).next((()=>this.Ti.Ii(e,(s=>n.li(s))))).next((()=>n.maxValue))}removeTargets(e,t,n){return this.Ti.removeTargets(e,t,n)}removeOrphanedDocuments(e,t){return this.Ti.removeOrphanedDocuments(e,t)}collect(e,t){return this.params.cacheSizeCollectionThreshold===-1?(w("LruGarbageCollector","Garbage collection skipped; disabled"),_.resolve(oa)):this.getCacheSize(e).next((n=>n<this.params.cacheSizeCollectionThreshold?(w("LruGarbageCollector",`Garbage collection skipped; Cache size ${n} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),oa):this.Ri(e,t)))}getCacheSize(e){return this.Ti.getCacheSize(e)}Ri(e,t){let n,s,i,a,o,u,c;const l=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next((h=>(h>this.params.maximumSequenceNumbersToCollect?(w("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${h}`),s=this.params.maximumSequenceNumbersToCollect):s=h,a=Date.now(),this.nthSequenceNumber(e,s)))).next((h=>(n=h,o=Date.now(),this.removeTargets(e,n,t)))).next((h=>(i=h,u=Date.now(),this.removeOrphanedDocuments(e,n)))).next((h=>(c=Date.now(),Ct()<=Fe.DEBUG&&w("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${a-l}ms
	Determined least recently used ${s} in `+(o-a)+`ms
	Removed ${i} targets in `+(u-o)+`ms
	Removed ${h} documents in `+(c-u)+`ms
Total Duration: ${c-l}ms`),_.resolve({didRun:!0,sequenceNumbersCollected:s,targetsRemoved:i,documentsRemoved:h}))))}}function kl(r,e){return new Dl(r,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ko="firestore.googleapis.com",la=!0;class ha{constructor(e){if(e.host===void 0){if(e.ssl!==void 0)throw new y(p.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host=ko,this.ssl=la}else this.host=e.host,this.ssl=e.ssl??la;if(this.isUsingEmulator=e.emulatorOptions!==void 0,this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e._customHeaders&&(this._customHeaders={...e._customHeaders}),e.cacheSizeBytes===void 0)this.cacheSizeBytes=Do;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<Cl)throw new y(p.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}if(nc("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=So(e.experimentalLongPollingOptions??{}),(function(n){if(n.timeoutSeconds!==void 0){if(isNaN(n.timeoutSeconds))throw new y(p.INVALID_ARGUMENT,`invalid long polling timeout: ${n.timeoutSeconds} (must not be NaN)`);if(n.timeoutSeconds<5)throw new y(p.INVALID_ARGUMENT,`invalid long polling timeout: ${n.timeoutSeconds} (minimum allowed value is 5)`);if(n.timeoutSeconds>30)throw new y(p.INVALID_ARGUMENT,`invalid long polling timeout: ${n.timeoutSeconds} (maximum allowed value is 30)`)}})(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams,e.grpcFlowControlWindow!==void 0){if(typeof e.grpcFlowControlWindow!="number"||e.grpcFlowControlWindow<=0||e.grpcFlowControlWindow>2147483647||!Number.isInteger(e.grpcFlowControlWindow))throw new y(p.INVALID_ARGUMENT,"grpcFlowControlWindow must be a positive integer and cannot exceed 2147483647");this.grpcFlowControlWindow=e.grpcFlowControlWindow}}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&(function(n,s){return n.timeoutSeconds===s.timeoutSeconds})(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams&&this.grpcFlowControlWindow===e.grpcFlowControlWindow&&(function(n,s){if(n===s)return!0;if(!n||!s)return!1;const i=Object.keys(n),a=Object.keys(s);if(i.length!==a.length)return!1;for(const o of i)if(n[o]!==s[o])return!1;return!0})(this._customHeaders,e._customHeaders)}}let Or=class{constructor(e,t,n,s){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=n,this._app=s,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new ha({}),this._settingsFrozen=!1,this._emulatorOptions={},this._terminateTask="notTerminated"}get app(){if(!this._app)throw new y(p.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!=="notTerminated"}_setSettings(e){if(this._settingsFrozen)throw new y(p.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new ha(e),this._emulatorOptions=e.emulatorOptions||{},e.credentials!==void 0&&(this._authCredentials=(function(n){if(!n)return new cl;switch(n.type){case"firstParty":return new dl(n.sessionIndex||"0",n.iamToken||null,n.authTokenFactory||null);case"provider":return n.client;default:throw new y(p.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}})(e.credentials))}_getSettings(){return this._settings}_getEmulatorOptions(){return this._emulatorOptions}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask==="notTerminated"&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){this._terminateTask==="notTerminated"?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return(function(t){const n=aa.get(t);n&&(w(vl,"Removing Datastore"),aa.delete(t),n.terminate())})(this),Promise.resolve()}};function Ll(r,e,t,n={}){r=we(r,Or);const s=Sa(e),i=r._getSettings(),a={...i,emulatorOptions:r._getEmulatorOptions()},o=`${e}:${t}`;s&&Du(`https://${o}`),i.host!==ko&&i.host!==o&&xe("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");const u={...i,host:o,ssl:s,emulatorOptions:n};if(!ku(u,a)&&(r._setSettings(u),n.mockUserToken)){let c,l;if(typeof n.mockUserToken=="string")c=n.mockUserToken,l=ie.MOCK_USER;else{c=Lu(n.mockUserToken,r._app?.options.projectId);const h=n.mockUserToken.sub||n.mockUserToken.user_id;if(!h)throw new y(p.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");l=new ie(h)}r._authCredentials=new ll(new Co(c,l))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qe{constructor(e,t,n){this.converter=t,this._query=n,this.type="query",this.firestore=e}withConverter(e){return new Qe(this.firestore,e,this._query)}}class F{constructor(e,t,n){this.converter=t,this._key=n,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new Xe(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new F(this.firestore,e,this._key)}toJSON(){return{type:F._jsonSchemaVersion,referencePath:this._key.toString()}}static fromJSON(e,t,n){if(Fn(t,F._jsonSchema))return new F(e,n||null,new V(L.fromString(t.referencePath)))}}F._jsonSchemaVersion="firestore/documentReference/1.0",F._jsonSchema={type:z("string",F._jsonSchemaVersion),referencePath:z("string")};class Xe extends Qe{constructor(e,t,n){super(e,t,Cr(n)),this._path=n,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new F(this.firestore,null,new V(e))}withConverter(e){return new Xe(this.firestore,e,this._path)}}function em(r,e,...t){if(r=Pe(r),ka("collection","path",e),r instanceof Or){const n=L.fromString(e,...t);return Di(n),new Xe(r,null,n)}{if(!(r instanceof F||r instanceof Xe))throw new y(p.INVALID_ARGUMENT,"Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const n=r._path.child(L.fromString(e,...t));return Di(n),new Xe(r.firestore,null,n)}}function tm(r,e,...t){if(r=Pe(r),arguments.length===1&&(e=ws.newId()),ka("doc","path",e),r instanceof Or){const n=L.fromString(e,...t);return Ni(n),new F(r,null,new V(n))}{if(!(r instanceof F||r instanceof Xe))throw new y(p.INVALID_ARGUMENT,"Expected first argument to doc() to be a CollectionReference, a DocumentReference or FirebaseFirestore");const n=r._path.child(L.fromString(e,...t));return Ni(n),new F(r.firestore,r instanceof Xe?r.converter:null,new V(n))}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qs{constructor(e,t){this.pattern=e,this.options=t}isEqual(e){return this.pattern===e.pattern&&this.options===e.options}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class de{constructor(e){this._values=(e||[]).map((t=>t))}toArray(){return this._values.map((e=>e))}isEqual(e){return(function(n,s){if(n.length!==s.length)return!1;for(let i=0;i<n.length;++i)if(n[i]!==s[i])return!1;return!0})(this._values,e._values)}toJSON(){return{type:de._jsonSchemaVersion,vectorValues:this._values}}static fromJSON(e){if(Fn(e,de._jsonSchema)){if(Array.isArray(e.vectorValues)&&e.vectorValues.every((t=>typeof t=="number")))return new de(e.vectorValues);throw new y(p.INVALID_ARGUMENT,"Expected 'vectorValues' field to be a number array")}}}de._jsonSchemaVersion="firestore/vectorValue/1.0",de._jsonSchema={type:z("string",de._jsonSchemaVersion),vectorValues:z("object")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ol=/^__.*__$/;class Ml{constructor(e,t,n){this.data=e,this.fieldMask=t,this.fieldTransforms=n}toMutation(e,t){return this.fieldMask!==null?new dt(e,this.data,this.fieldMask,t,this.fieldTransforms):new $n(e,this.data,t,this.fieldTransforms)}}class Lo{constructor(e,t,n){this.data=e,this.fieldMask=t,this.fieldTransforms=n}toMutation(e,t){return new dt(e,this.data,this.fieldMask,t,this.fieldTransforms)}}function Oo(r){switch(r){case 0:case 2:case 1:return!0;case 3:case 4:return!1;default:throw A(40011,{dataSource:r})}}class Bs{constructor(e,t,n,s,i,a){this.settings=e,this.databaseId=t,this.serializer=n,this.ignoreUndefinedProperties=s,i===void 0&&this.validatePath(),this.fieldTransforms=i||[],this.fieldMask=a||[]}get path(){return this.settings.path}get dataSource(){return this.settings.dataSource}contextWith(e){return new Bs({...this.settings,...e},this.databaseId,this.serializer,this.ignoreUndefinedProperties,this.fieldTransforms,this.fieldMask)}childContextForField(e){const t=this.path?.child(e),n=this.contextWith({path:t,arrayElement:!1});return n.validatePathSegment(e),n}childContextForFieldPath(e){const t=this.path?.child(e),n=this.contextWith({path:t,arrayElement:!1});return n.validatePath(),n}childContextForArray(e){return this.contextWith({path:void 0,arrayElement:!0})}createError(e){return Er(e,this.settings.methodName,this.settings.hasConverter||!1,this.path,this.settings.targetDoc)}contains(e){return this.fieldMask.find((t=>e.isPrefixOf(t)))!==void 0||this.fieldTransforms.find((t=>e.isPrefixOf(t.field)))!==void 0}validatePath(){if(this.path)for(let e=0;e<this.path.length;e++)this.validatePathSegment(this.path.get(e))}validatePathSegment(e){if(e.length===0)throw this.createError("Document fields must not be empty");if(Oo(this.dataSource)&&Ol.test(e))throw this.createError('Document fields cannot begin and end with "__"')}}class Ul{constructor(e,t,n){this.databaseId=e,this.ignoreUndefinedProperties=t,this.serializer=n||Nr(e)}createContext(e,t,n,s=!1){return new Bs({dataSource:e,methodName:t,targetDoc:n,path:Te.emptyPath(),arrayElement:!1,hasConverter:s},this.databaseId,this.serializer,this.ignoreUndefinedProperties)}}function $s(r){const e=r._freezeSettings(),t=Nr(r._databaseId);return new Ul(r._databaseId,!!e.ignoreUndefinedProperties,t)}function Mo(r,e,t,n,s,i={}){const a=r.createContext(i.merge||i.mergeFields?2:0,e,t,s);js("Data must be an object, but it was:",a,n);const o=Uo(n,a);let u,c;if(i.merge)u=new ye(a.fieldMask),c=a.fieldTransforms;else if(i.mergeFields){const l=[];for(const h of i.mergeFields){const d=Vt(e,h,t);if(!a.contains(d))throw new y(p.INVALID_ARGUMENT,`Field '${d}' is specified in your field mask but missing from your input data.`);$o(l,d)||l.push(d)}u=new ye(l),c=a.fieldTransforms.filter((h=>u.covers(h.field)))}else u=null,c=a.fieldTransforms;return new Ml(new ae(o),u,c)}class Mr extends kr{_toFieldTransform(e){if(e.dataSource!==2)throw e.dataSource===1?e.createError(`${this._methodName}() can only appear at the top level of your update data`):e.createError(`${this._methodName}() cannot be used with set() unless you pass {merge:true}`);return e.fieldMask.push(e.path),null}isEqual(e){return e instanceof Mr}}class zs extends kr{_toFieldTransform(e){return new fc(e.path,new vn)}isEqual(e){return e instanceof zs}}function Fl(r,e,t,n){const s=r.createContext(1,e,t);js("Data must be an object, but it was:",s,n);const i=[],a=ae.empty();ft(n,((u,c)=>{const l=Bo(e,u,t);c=Pe(c);const h=s.childContextForFieldPath(l);if(c instanceof Mr)i.push(l);else{const d=it(c,h);d!=null&&(i.push(l),a.set(l,d))}}));const o=new ye(i);return new Lo(a,o,s.fieldTransforms)}function ql(r,e,t,n,s,i){const a=r.createContext(1,e,t),o=[Vt(e,n,t)],u=[s];if(i.length%2!=0)throw new y(p.INVALID_ARGUMENT,`Function ${e}() needs to be called with an even number of arguments that alternate between field names and values.`);for(let d=0;d<i.length;d+=2)o.push(Vt(e,i[d])),u.push(i[d+1]);const c=[],l=ae.empty();for(let d=o.length-1;d>=0;--d)if(!$o(c,o[d])){const g=o[d];let T=u[d];T=Pe(T);const C=a.childContextForFieldPath(g);if(T instanceof Mr)c.push(g);else{const P=it(T,C);P!=null&&(c.push(g),l.set(g,P))}}const h=new ye(c);return new Lo(l,h,a.fieldTransforms)}function Bl(r,e,t,n=!1){return it(t,r.createContext(n?4:3,e))}function it(r,e,t){if(qo(r=Pe(r)))return js("Unsupported field value:",e,r),Uo(r,e);if(r instanceof kr)return(function(s,i){if(!Oo(i.dataSource))throw i.createError(`${s._methodName}() can only be used with update() and set()`);if(!i.path)throw i.createError(`${s._methodName}() is not currently supported inside arrays`);const a=s._toFieldTransform(i);a&&i.fieldTransforms.push(a)})(r,e),null;if(r===void 0&&e.ignoreUndefinedProperties)return null;if(e.path&&e.fieldMask.push(e.path),r instanceof Array){if(e.settings.arrayElement&&e.dataSource!==4)throw e.createError("Nested arrays are not supported");return(function(s,i){const a=[];let o=0;for(const u of s){let c=it(u,i.childContextForArray(o));c==null&&(c={nullValue:"NULL_VALUE"}),a.push(c),o++}return{arrayValue:{values:a}}})(r,e)}return(function(s,i,a){if((s=Pe(s))===null)return{nullValue:"NULL_VALUE"};if(typeof s=="number")return xs(i.serializer,s);if(typeof s=="boolean")return{booleanValue:s};if(typeof s=="string")return{stringValue:s};if(s instanceof Date){const o=M.fromDate(s);return{timestampValue:dn(i.serializer,o)}}if(s instanceof M){const o=new M(s.seconds,1e3*Math.floor(s.nanoseconds/1e3));return{timestampValue:dn(i.serializer,o)}}if(Fo(s)){const o=M.fromInstant(s),u=new M(o.seconds,1e3*Math.floor(o.nanoseconds/1e3));return{timestampValue:dn(i.serializer,u)}}if(s instanceof Le)return{geoPointValue:{latitude:s.latitude,longitude:s.longitude}};if(s instanceof he)return s.subtype===0?{bytesValue:us(i.serializer,s._byteString)}:(function(u,c){const l=c.toUint8Array(),h=new Uint8Array(l.length+1);return h[0]=c.subtype,h.set(l,1),{mapValue:{fields:{[Pr]:{bytesValue:us(u,B.fromUint8Array(h))}}}}})(i.serializer,s);if(s instanceof F){const o=i.databaseId,u=s.firestore._databaseId;if(!u.isEqual(o))throw i.createError(`Document reference is for database ${u.projectId}/${u.database} but should be for database ${o.projectId}/${o.database}`);return{referenceValue:ks(s.firestore._databaseId||i.databaseId,s._key.path)}}if(s instanceof de)return(function(u,c){const l=u instanceof de?u.toArray():u;return{mapValue:{fields:{[Vs]:{stringValue:vs},[Tn]:{arrayValue:{values:l.map((d=>{if(typeof d!="number")throw c.createError("VectorValues must only contain numeric values.");return Ps(c.serializer,d)}))}}}}}})(s,i);if(s instanceof qs)return(function(u){return{mapValue:{fields:{[Ye]:{mapValue:{fields:{[lr]:{stringValue:u.pattern},[hr]:{stringValue:u.options}}}}}}}})(s);if(s instanceof Ls)return(function(u){return{mapValue:{fields:{[wn]:{stringValue:u.value}}}}})(s);if(s instanceof Us)return(function(u){return{mapValue:{fields:{[Rt]:Mt(u.value)}}}})(s);if(s instanceof Ms)return(function(u){return{mapValue:{fields:{[nt]:{stringValue:u.stringValue}}}}})(s);if(s instanceof Os)return(function(u){return{mapValue:{fields:{[_t]:{mapValue:{fields:{[fr]:Mt(u.seconds),[dr]:Mt(u.increment)}}}}}}})(s);if(s instanceof Be)return(function(){return{mapValue:{fields:{[qa]:{nullValue:"NULL_VALUE"}}}}})();if(s instanceof qe)return(function(){return{mapValue:{fields:{[Rs]:{nullValue:"NULL_VALUE"}}}}})();if(xo(s))return s._toProto(i.serializer);throw i.createError(`Unsupported field value: ${Rr(s)}`)})(r,e)}function Uo(r,e){const t={};return Da(r)?e.path&&e.path.length>0&&e.fieldMask.push(e.path):ft(r,((n,s)=>{const i=it(s,e.childContextForField(n));i!=null&&(t[n]=i)})),{mapValue:{fields:t}}}function Fo(r){if(typeof r!="object"||r===null)return!1;if(typeof Temporal<"u"&&typeof Temporal.Instant=="function"&&r instanceof Temporal.Instant)return!0;const e=r;return e[Symbol.toStringTag]==="Temporal.Instant"&&typeof e.t=="bigint"}function qo(r){return!(typeof r!="object"||r===null||r instanceof Array||r instanceof Date||r instanceof M||r instanceof Le||r instanceof he||r instanceof F||r instanceof kr||r instanceof de||r instanceof Be||r instanceof qe||r instanceof Us||r instanceof Ms||r instanceof qs||r instanceof Ls||r instanceof Os||Fo(r)||xo(r))}function js(r,e,t){if(!qo(t)||!Un(t)){const n=Rr(t);throw n==="an object"?e.createError(r+" a custom object"):e.createError(r+" "+n)}}function Vt(r,e,t){if((e=Pe(e))instanceof Dr)return e._internalPath;if(typeof e=="string")return Bo(r,e);throw Er("Field path arguments must be of type string or ",r,!1,void 0,t)}const $l=new RegExp("[~\\*/\\[\\]]");function Bo(r,e,t){if(e.search($l)>=0)throw Er(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,r,!1,void 0,t);try{return new Dr(...e.split("."))._internalPath}catch{throw Er(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,r,!1,void 0,t)}}function Er(r,e,t,n,s){const i=n&&!n.isEmpty(),a=s!==void 0;let o=`Function ${e}() called with invalid data`;t&&(o+=" (via `toFirestore()`)"),o+=". ";let u="";return(i||a)&&(u+=" (found",i&&(u+=` in field ${n}`),a&&(u+=` in document ${s}`),u+=")"),new y(p.INVALID_ARGUMENT,o+r+u)}function $o(r,e){return r.some((t=>t.isEqual(e)))}function zo(r){return typeof r._readUserData=="function"}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oe{constructor(e){this.optionDefinitions=e}_getKnownOptions(e,t){const n=ae.empty();for(const s in this.optionDefinitions)if(this.optionDefinitions.hasOwnProperty(s)){const i=this.optionDefinitions[s];if(s in e){const a=e[s];let o;i.nestedOptions&&Un(a)?o={mapValue:{fields:new oe(i.nestedOptions).getOptionsProto(t,a)}}:a&&(o=it(a,t)??void 0),o&&n.set(Te.fromServerFormat(i.serverName),o)}}return n}getOptionsProto(e,t,n){const s=this._getKnownOptions(t,e);if(n){const i=new Map(tc(n,((a,o)=>[Te.fromServerFormat(o),a!==void 0?it(a,e):null])));s.setAll(i)}return s.value.mapValue.fields??{}}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function zl(r){return typeof r=="object"&&r!==null&&!!("nullValue"in r&&(r.nullValue===null||r.nullValue==="NULL_VALUE")||"booleanValue"in r&&(r.booleanValue===null||typeof r.booleanValue=="boolean")||"integerValue"in r&&(r.integerValue===null||typeof r.integerValue=="number"||typeof r.integerValue=="string")||"doubleValue"in r&&(r.doubleValue===null||typeof r.doubleValue=="number")||"timestampValue"in r&&(r.timestampValue===null||(function(t){return typeof t=="object"&&t!==null&&"seconds"in t&&(t.seconds===null||typeof t.seconds=="number"||typeof t.seconds=="string")&&"nanos"in t&&(t.nanos===null||typeof t.nanos=="number")})(r.timestampValue))||"stringValue"in r&&(r.stringValue===null||typeof r.stringValue=="string")||"bytesValue"in r&&(r.bytesValue===null||r.bytesValue instanceof Uint8Array)||"referenceValue"in r&&(r.referenceValue===null||typeof r.referenceValue=="string")||"geoPointValue"in r&&(r.geoPointValue===null||(function(t){return typeof t=="object"&&t!==null&&"latitude"in t&&(t.latitude===null||typeof t.latitude=="number")&&"longitude"in t&&(t.longitude===null||typeof t.longitude=="number")})(r.geoPointValue))||"arrayValue"in r&&(r.arrayValue===null||(function(t){return typeof t=="object"&&t!==null&&!(!("values"in t)||t.values!==null&&!Array.isArray(t.values))})(r.arrayValue))||"mapValue"in r&&(r.mapValue===null||(function(t){return typeof t=="object"&&t!==null&&!(!("fields"in t)||t.fields!==null&&!Un(t.fields))})(r.mapValue))||"fieldReferenceValue"in r&&(r.fieldReferenceValue===null||typeof r.fieldReferenceValue=="string")||"functionValue"in r&&(r.functionValue===null||(function(t){return typeof t=="object"&&t!==null&&!(!("name"in t)||t.name!==null&&typeof t.name!="string"||!("args"in t)||t.args!==null&&!Array.isArray(t.args))})(r.functionValue))||"pipelineValue"in r&&(r.pipelineValue===null||(function(t){return typeof t=="object"&&t!==null&&!(!("stages"in t)||t.stages!==null&&!Array.isArray(t.stages))})(r.pipelineValue)))}function nm(){return new zs("serverTimestamp")}function jl(r){return new de(r)}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function E(r){let e;return r instanceof xt?r:(e=Un(r)?Hl(r):r instanceof Array?Yl(r):jo(r,void 0),e)}function Xr(r){if(r instanceof xt)return r;if(r instanceof de)return Dn(r);if(Array.isArray(r))return Dn(jl(r));throw new Error("Unsupported value: "+typeof r)}function Gs(r){return oc(r)?or(r):E(r)}class xt{constructor(){this._protoValueType="ProtoValue"}add(e){return new m("add",[this,E(e)],"add")}asBoolean(){if(this instanceof at)return this;if(this instanceof Yt)return new Ko(this);if(this instanceof Ht)return new Ql(this);if(this instanceof m)return new Go(this);throw new y("invalid-argument",`Conversion of type ${typeof this} to BooleanExpression not supported.`)}subtract(e){return new m("subtract",[this,E(e)],"subtract")}multiply(e){return new m("multiply",[this,E(e)],"multiply")}divide(e){return new m("divide",[this,E(e)],"divide")}mod(e){return new m("mod",[this,E(e)],"mod")}equal(e){return new m("equal",[this,E(e)],"equal").asBoolean()}notEqual(e){return new m("not_equal",[this,E(e)],"notEqual").asBoolean()}lessThan(e){return new m("less_than",[this,E(e)],"lessThan").asBoolean()}lessThanOrEqual(e){return new m("less_than_or_equal",[this,E(e)],"lessThanOrEqual").asBoolean()}greaterThan(e){return new m("greater_than",[this,E(e)],"greaterThan").asBoolean()}greaterThanOrEqual(e){return new m("greater_than_or_equal",[this,E(e)],"greaterThanOrEqual").asBoolean()}arrayConcat(e,...t){const n=[e,...t].map((s=>E(s)));return new m("array_concat",[this,...n],"arrayConcat")}arrayContains(e){return new m("array_contains",[this,E(e)],"arrayContains").asBoolean()}arrayContainsAll(e){const t=Array.isArray(e)?new an(e.map(E),"arrayContainsAll"):e;return new m("array_contains_all",[this,t],"arrayContainsAll").asBoolean()}arrayContainsAny(e){const t=Array.isArray(e)?new an(e.map(E),"arrayContainsAny"):e;return new m("array_contains_any",[this,t],"arrayContainsAny").asBoolean()}arrayReverse(){return new m("array_reverse",[this])}arrayLength(){return new m("array_length",[this],"arrayLength")}equalAny(e){const t=Array.isArray(e)?new an(e.map(E),"equalAny"):e;return new m("equal_any",[this,t],"equalAny").asBoolean()}notEqualAny(e){const t=Array.isArray(e)?new an(e.map(E),"notEqualAny"):e;return new m("not_equal_any",[this,t],"notEqualAny").asBoolean()}exists(){return new m("exists",[this],"exists").asBoolean()}charLength(){return new m("char_length",[this],"charLength")}like(e){return new m("like",[this,E(e)],"like").asBoolean()}regexContains(e){return new m("regex_contains",[this,E(e)],"regexContains").asBoolean()}regexFind(e){return new m("regex_find",[this,E(e)],"regexFind")}regexFindAll(e){return new m("regex_find_all",[this,E(e)],"regexFindAll")}regexMatch(e){return new m("regex_match",[this,E(e)],"regexMatch").asBoolean()}stringContains(e){return new m("string_contains",[this,E(e)],"stringContains").asBoolean()}startsWith(e){return new m("starts_with",[this,E(e)],"startsWith").asBoolean()}endsWith(e){return new m("ends_with",[this,E(e)],"endsWith").asBoolean()}toLower(){return new m("to_lower",[this],"toLower")}toUpper(){return new m("to_upper",[this],"toUpper")}trim(e){const t=[this];return e&&t.push(E(e)),new m("trim",t,"trim")}ltrim(e){const t=[this];return e&&t.push(E(e)),new m("ltrim",t,"ltrim")}rtrim(e){const t=[this];return e&&t.push(E(e)),new m("rtrim",t,"rtrim")}type(){return new m("type",[this])}isType(e){return new m("is_type",[this,Dn(e)],"isType").asBoolean()}stringConcat(e,...t){const n=[e,...t].map(E);return new m("string_concat",[this,...n],"stringConcat")}stringIndexOf(e){return new m("string_index_of",[this,E(e)],"stringIndexOf")}stringRepeat(e){return new m("string_repeat",[this,E(e)],"stringRepeat")}stringReplaceAll(e,t){return new m("string_replace_all",[this,E(e),E(t)],"stringReplaceAll")}stringReplaceOne(e,t){return new m("string_replace_one",[this,E(e),E(t)],"stringReplaceOne")}concat(e,...t){const n=[e,...t].map(E);return new m("concat",[this,...n],"concat")}reverse(){return new m("reverse",[this],"reverse")}arrayFilter(e,t){return new m("array_filter",[this,E(e),t],"arrayFilter")}arrayTransform(e,t){return new m("array_transform",[this,E(e),t],"arrayTransform")}arrayTransformWithIndex(e,t,n){return new m("array_transform",[this,E(e),E(t),n],"arrayTransformWithIndex")}arraySlice(e,t){const n=[this,E(e)];return t!==void 0&&n.push(E(t)),new m("array_slice",n,"arraySlice")}arrayFirst(){return new m("array_first",[this],"arrayFirst")}arrayFirstN(e){return new m("array_first_n",[this,E(e)],"arrayFirstN")}arrayLast(){return new m("array_last",[this],"arrayLast")}arrayLastN(e){return new m("array_last_n",[this,E(e)],"arrayLastN")}arrayMaximum(){return new m("maximum",[this],"arrayMaximum")}arrayMaximumN(e){return new m("maximum_n",[this,E(e)],"arrayMaximumN")}arrayMinimum(){return new m("minimum",[this],"arrayMinimum")}arrayMinimumN(e){return new m("minimum_n",[this,E(e)],"arrayMinimumN")}arrayIndexOf(e){return new m("array_index_of",[this,E(e),E("first")],"arrayIndexOf")}arrayLastIndexOf(e){return new m("array_index_of",[this,E(e),E("last")],"arrayLastIndexOf")}arrayIndexOfAll(e){return new m("array_index_of_all",[this,E(e)],"arrayIndexOfAll")}byteLength(){return new m("byte_length",[this],"byteLength")}ceil(){return new m("ceil",[this])}floor(){return new m("floor",[this])}abs(){return new m("abs",[this])}exp(){return new m("exp",[this])}mapGet(e){return new m("map_get",[this,Dn(e)],"mapGet")}mapSet(e,t,...n){const s=[this,E(e),E(t),...n.map(E)];return new m("map_set",s,"mapSet")}mapKeys(){return new m("map_keys",[this],"mapKeys")}mapValues(){return new m("map_values",[this],"mapValues")}mapEntries(){return new m("map_entries",[this],"mapEntries")}getField(e){return new m("get_field",[this,E(e)],"get_field")}count(){return ge._create("count",[this],"count")}sum(){return ge._create("sum",[this],"sum")}average(){return ge._create("average",[this],"average")}minimum(){return ge._create("minimum",[this],"minimum")}maximum(){return ge._create("maximum",[this],"maximum")}first(){return ge._create("first",[this],"first")}last(){return ge._create("last",[this],"last")}arrayAgg(){return ge._create("array_agg",[this],"arrayAgg")}arrayAggDistinct(){return ge._create("array_agg_distinct",[this],"arrayAggDistinct")}countDistinct(){return ge._create("count_distinct",[this],"countDistinct")}logicalMaximum(e,...t){const n=[e,...t];return new m("maximum",[this,...n.map(E)],"logicalMaximum")}logicalMinimum(e,...t){const n=[e,...t];return new m("minimum",[this,...n.map(E)],"minimum")}vectorLength(){return new m("vector_length",[this],"vectorLength")}cosineDistance(e){return new m("cosine_distance",[this,Xr(e)],"cosineDistance")}dotProduct(e){return new m("dot_product",[this,Xr(e)],"dotProduct")}euclideanDistance(e){return new m("euclidean_distance",[this,Xr(e)],"euclideanDistance")}unixMicrosToTimestamp(){return new m("unix_micros_to_timestamp",[this],"unixMicrosToTimestamp")}timestampToUnixMicros(){return new m("timestamp_to_unix_micros",[this],"timestampToUnixMicros")}unixMillisToTimestamp(){return new m("unix_millis_to_timestamp",[this],"unixMillisToTimestamp")}timestampToUnixMillis(){return new m("timestamp_to_unix_millis",[this],"timestampToUnixMillis")}unixSecondsToTimestamp(){return new m("unix_seconds_to_timestamp",[this],"unixSecondsToTimestamp")}timestampToUnixSeconds(){return new m("timestamp_to_unix_seconds",[this],"timestampToUnixSeconds")}timestampAdd(e,t){return new m("timestamp_add",[this,E(e),E(t)],"timestampAdd")}timestampSubtract(e,t){return new m("timestamp_subtract",[this,E(e),E(t)],"timestampSubtract")}timestampDiff(e,t){return new m("timestamp_diff",[this,Gs(e),E(t)],"timestampDiff")}timestampExtract(e,t){const n=[this,E(e)];return t&&n.push(E(t)),new m("timestamp_extract",n,"timestampExtract")}documentId(){return new m("document_id",[this],"documentId")}parent(){return new m("parent",[this],"parent")}substring(e,t){const n=E(e);return new m("substring",t===void 0?[this,n]:[this,n,E(t)],"substring")}arrayGet(e){return new m("array_get",[this,E(e)],"arrayGet")}isError(){return new m("is_error",[this],"isError").asBoolean()}ifError(e){const t=new m("if_error",[this,E(e)],"ifError");return e instanceof at?t.asBoolean():t}isAbsent(){return new m("is_absent",[this],"isAbsent").asBoolean()}mapRemove(e){return new m("map_remove",[this,E(e)],"mapRemove")}mapMerge(e,...t){const n=E(e),s=t.map(E);return new m("map_merge",[this,n,...s],"mapMerge")}pow(e){return new m("pow",[this,E(e)])}trunc(e){return e===void 0?new m("trunc",[this]):new m("trunc",[this,E(e)],"trunc")}round(e){return e===void 0?new m("round",[this]):new m("round",[this,E(e)],"round")}collectionId(){return new m("collection_id",[this])}length(){return new m("length",[this])}ln(){return new m("ln",[this])}sqrt(){return new m("sqrt",[this])}stringReverse(){return new m("string_reverse",[this])}ifAbsent(e){return new m("if_absent",[this,E(e)],"ifAbsent")}ifNull(e){return new m("if_null",[this,E(e)],"ifNull")}coalesce(e,...t){return new m("coalesce",[this,E(e),...t.map(E)],"coalesce")}join(e){return new m("join",[this,E(e)],"join")}log10(){return new m("log10",[this])}arraySum(){return new m("sum",[this])}split(e){return new m("split",[this,E(e)])}timestampTruncate(e,t){const n=[this,E(e)];return t&&n.push(E(t)),new m("timestamp_trunc",n)}ascending(){return Xl(this)}descending(){return Jl(this)}as(e){return new Kl(this,e,"as")}}class ge{constructor(e,t){this.name=e,this.params=t,this.exprType="AggregateFunction",this._protoValueType="ProtoValue"}static _create(e,t,n){const s=new ge(e,t);return s._methodName=n,s}as(e){return new Gl(this,e,"as")}_toProto(e){return{functionValue:{name:this.name,args:this.params.map((t=>t._toProto(e)))}}}_readUserData(e){e=this._methodName?e.contextWith({methodName:this._methodName}):e,this.params.forEach((t=>t._readUserData(e)))}}class Gl{constructor(e,t,n){this.aggregate=e,this.alias=t,this._methodName=n}_readUserData(e){this.aggregate._readUserData(e)}}class Kl{constructor(e,t,n){this.expr=e,this.alias=t,this._methodName=n,this.exprType="AliasedExpression",this.selectable=!0}_readUserData(e){this.expr._readUserData(e)}}class an extends xt{constructor(e,t){super(),this.fi=e,this._methodName=t,this.expressionType="ListOfExpressions"}_toProto(e){return{arrayValue:{values:this.fi.map((t=>t._toProto(e)))}}}_readUserData(e){this.fi.forEach((t=>t._readUserData(e)))}}class Ht extends xt{constructor(e,t){super(),this.fieldPath=e,this._methodName=t,this.expressionType="Field",this.selectable=!0}get _fieldPath(){return this.fieldPath}get fieldName(){return this.fieldPath.canonicalString()}get alias(){return this.fieldName}get expr(){return this}geoDistance(e){return new m("geo_distance",[this,E(e)],"geoDistance")}_toProto(e){return{fieldReferenceValue:this.fieldPath.canonicalString()}}_readUserData(e){}}function or(r){return Wl(r,"field")}function Wl(r,e){return new Ht(typeof r=="string"?Se===r?ul()._internalPath:Vt("field",r):r._internalPath,e)}class Yt extends xt{constructor(e,t){super(),this.value=e,this._methodName=t,this.expressionType="Constant"}static _fromProto(e){const t=new Yt(e,void 0);return t._protoValue=e,t}_toProto(e){return I(this._protoValue!==void 0,237),this._protoValue}_getValue(){return this._protoValue}_readUserData(e){e=this._methodName?e.contextWith({methodName:this._methodName}):e,zl(this._protoValue)||(this._protoValue=it(this.value,e))}}function Dn(r,e){return jo(r,"constant")}function jo(r,e){const t=new Yt(r,e);return typeof r=="boolean"?new Ko(t):t}class m extends xt{constructor(e,t,n,s){super(),this.name=e,this.params=t,this.expressionType="Function",this._optionsProto=void 0,n!==void 0&&(this._methodName=n),s!==void 0&&(this._options=s)}get _optionsUtil(){return new oe({})}_toProto(e){const t={functionValue:{name:this.name,args:this.params.map((n=>n._toProto(e)))}};return this._optionsProto&&(t.functionValue.options=this._optionsProto),t}_readUserData(e){e=this._methodName?e.contextWith({methodName:this._methodName}):e,this.params.forEach((t=>t._readUserData(e))),this._options&&(this._optionsProto=this._optionsUtil.getOptionsProto(e,this._options))}}class at extends xt{get _methodName(){return this._expr._methodName}countIf(){return ge._create("count_if",[this],"countIf")}not(){return new m("not",[this],"not").asBoolean()}conditional(e,t){return new m("conditional",[this,e,t],"conditional")}ifError(e){const t=E(e),n=new m("if_error",[this,t],"ifError");return t instanceof at?n.asBoolean():n}_toProto(e){return this._expr._toProto(e)}_readUserData(e){this._expr._readUserData(e)}}class Go extends at{constructor(e){super(),this._expr=e,this.expressionType="Function"}}class Ko extends at{constructor(e){super(),this._expr=e,this.expressionType="Constant"}_getValue(){return this._expr._getValue()}}class Ql extends at{constructor(e){super(),this._expr=e,this.expressionType="Field"}}function Hl(r,e){const t=[];for(const n in r)if(Object.prototype.hasOwnProperty.call(r,n)){const s=r[n];t.push(Dn(n)),t.push(E(s))}return new m("map",t,"map")}function Yl(r){return(function(t,n){return new m("array",t.map((s=>E(s))),n)})(r,"array")}function Xl(r){return new Wo(Gs(r),"ascending","ascending")}function Jl(r){return new Wo(Gs(r),"descending","descending")}class Wo{constructor(e,t,n){this.expr=e,this.direction=t,this._methodName=n,this._protoValueType="ProtoValue"}_toProto(e){return{mapValue:{fields:{direction:bo(this.direction),expression:this.expr._toProto(e)}}}}_readUserData(e){this.expr._readUserData(e)}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ae{constructor(e){this.optionsProto=void 0,{rawOptions:this.rawOptions,...this.knownOptions}=e}_readUserData(e){this.optionsProto=this._optionsUtil.getOptionsProto(e,this.knownOptions,this.rawOptions)}_toProto(e){return{name:this._name,options:this.optionsProto}}}class Qo extends Ae{get _name(){return"add_fields"}get _optionsUtil(){return new oe({})}constructor(e,t){super(t),this.fields=e}_toProto(e){return{...super._toProto(e),args:[Nn(e,this.fields)]}}_readUserData(e){super._readUserData(e),ot(this.fields,e)}}class Ho extends Ae{get _name(){return"aggregate"}get _optionsUtil(){return new oe({})}constructor(e,t,n){super(n),this.groups=e,this.accumulators=t}_toProto(e){return{...super._toProto(e),args:[Nn(e,this.accumulators),Nn(e,this.groups)]}}_readUserData(e){super._readUserData(e),ot(this.groups,e),ot(this.accumulators,e)}}class Yo extends Ae{get _name(){return"distinct"}get _optionsUtil(){return new oe({})}constructor(e,t){super(t),this.groups=e}_toProto(e){return{...super._toProto(e),args:[Nn(e,this.groups)]}}_readUserData(e){super._readUserData(e),ot(this.groups,e)}}class Ur extends Ae{get _name(){return"collection"}get _optionsUtil(){return new oe({forceIndex:{serverName:"force_index"}})}constructor(e,t){super(t),this.pi=e.startsWith("/")?e:"/"+e}_toProto(e){return{...super._toProto(e),args:[{referenceValue:this.pi}]}}_readUserData(e){super._readUserData(e)}}class Fr extends Ae{get _name(){return"collection_group"}get _optionsUtil(){return new oe({forceIndex:{serverName:"force_index"}})}constructor(e,t){super(t),this.collectionId=e}_toProto(e){return{...super._toProto(e),args:[{referenceValue:""},{stringValue:this.collectionId}]}}_readUserData(e){super._readUserData(e)}}class Ks extends Ae{get _name(){return"database"}get _optionsUtil(){return new oe({})}_toProto(e){return{...super._toProto(e)}}_readUserData(e){super._readUserData(e)}}class Ws extends Ae{get _name(){return"documents"}get _optionsUtil(){return new oe({})}constructor(e,t){if(super(t),!e||e.length===0)throw new y(p.INVALID_ARGUMENT,"Empty document paths are not allowed in DocumentsSource");const n=e.map((i=>i.startsWith("/")?i:"/"+i)),s=new Set(n);if(s.size!==n.length)throw new y(p.INVALID_ARGUMENT,"Duplicate document paths are not allowed in DocumentsSource");this.gi=n,this.yi=s}_toProto(e){return{...super._toProto(e),args:this.gi.map((t=>({referenceValue:t})))}}_readUserData(e){super._readUserData(e)}}class qr extends Ae{get _name(){return"where"}get _optionsUtil(){return new oe({})}constructor(e,t){super(t),this.condition=e}_toProto(e){return{...super._toProto(e),args:[this.condition._toProto(e)]}}_readUserData(e){super._readUserData(e),ot(this.condition,e)}}class vt extends Ae{get _name(){return"limit"}get _optionsUtil(){return new oe({})}constructor(e,t){I(!isNaN(e)&&e!==1/0&&e!==-1/0,34860),super(t),this.limit=e}_toProto(e){return{...super._toProto(e),args:[xs(e,this.limit)]}}}class fa extends Ae{get _name(){return"offset"}get _optionsUtil(){return new oe({})}constructor(e,t){super(t),this.offset=e}_toProto(e){return{...super._toProto(e),args:[xs(e,this.offset)]}}}class Zl extends Ae{get _name(){return"select"}get _optionsUtil(){return new oe({})}constructor(e,t){super(t),this.selections=e}_toProto(e){return{...super._toProto(e),args:[Nn(e,this.selections)]}}_readUserData(e){super._readUserData(e),ot(this.selections,e)}}class $e extends Ae{get _name(){return"sort"}get _optionsUtil(){return new oe({})}constructor(e,t){super(t),this.orderings=e}_toProto(e){return{...super._toProto(e),args:this.orderings.map((t=>t._toProto(e)))}}_readUserData(e){super._readUserData(e),ot(this.orderings,e)}}class Qs extends Ae{get _name(){return"replace_with"}get _optionsUtil(){return new oe({})}constructor(e,t){super(t),this.map=e}_toProto(e){return{...super._toProto(e),args:[this.map._toProto(e),bo(Qs.wi)]}}_readUserData(e){super._readUserData(e),ot(this.map,e)}}Qs.wi="full_replace";function ot(r,e){return zo(r)?r._readUserData(e):Array.isArray(r)?r.forEach((t=>t._readUserData(e))):r instanceof Map?r.forEach((t=>t._readUserData(e))):Object.values(r).forEach((t=>t._readUserData(e))),r}/**
 * @license
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pn{constructor(e,t,n,s){this._db=e,this.userDataReader=t,this._userDataWriter=n,this.stages=s}xi(e,t){const n=this.userDataReader.createContext(3,e);return zo(t)?t._readUserData(n):Array.isArray(t)?t.forEach((s=>s._readUserData(n))):t.forEach((s=>s._readUserData(n))),t}where(e){const t=this.stages.map((n=>n));return this.xi("where",e),t.push(new qr(e,{})),new pn(this._db,this.userDataReader,this._userDataWriter,t)}limit(e){const t=this.stages.map((n=>n));return t.push(new vt(e,{})),new pn(this._db,this.userDataReader,this._userDataWriter,t)}sort(e,...t){const n=this.stages.map((s=>s));return"orderings"in e?n.push(new $e(this.xi("sort",e.orderings),{})):n.push(new $e(this.xi("sort",[e,...t]),{})),new pn(this._db,this.userDataReader,this._userDataWriter,n)}Di(e){return{pipeline:{stages:this.stages.map((t=>t._toProto(e)))}}}}// Copyright 2024 Google LLC* @license
class ue{constructor(e,t,n){this.serializer=e,this.stages=t,this.listenOptions=n,this.isCorePipeline=!0}getPipelineCollection(){return Br(this)}getPipelineCollectionGroup(){return Hs(this)}getPipelineCollectionId(){return eh(this)}getPipelineDocuments(){return fs(this)}getPipelineFlavor(){return(function(t){let n="exact";return t.stages.forEach(((s,i)=>{s._name!==Yo.name&&s._name!==Ho.name||(n="keyless"),s._name===Zl.name&&n==="exact"&&(n="augmented"),s._name===Qo.name&&i<t.stages.length-1&&n==="exact"&&(n="augmented")})),n})(this)}getPipelineSourceType(){return Je(this)}}function Je(r){const e=r.stages[0];return e instanceof Ur||e instanceof Fr||e instanceof Ks||e instanceof Ws?e._name:"unknown"}function Br(r){if(Je(r)==="collection")return r.stages[0].pi}function Hs(r){if(Je(r)==="collection_group")return r.stages[0].collectionId}function eh(r){switch(Je(r)){case"collection":return L.fromString(Br(r)).lastSegment();case"collection_group":return Hs(r);default:return}}function fs(r){if(Je(r)==="documents")return r.stages[0].gi}class f{constructor(e,t){this.type=e,this.value=t}static Ci(){return new f("ERROR",void 0)}static Fi(){return new f("UNSET",void 0)}static Oi(){return new f("NULL",Bt)}static newValue(e){return Ee(e)?new f("NULL",Bt):(function(n){return!!n&&"booleanValue"in n})(e)?new f("BOOLEAN",e):Ne(e)?new f("INT",e):De(e)?new f("DOUBLE",e):(function(n){return!!n&&"timestampValue"in n&&!!n.timestampValue})(e)?new f("TIMESTAMP",e):(function(n){return!!n&&"stringValue"in n})(e)?new f("STRING",e):(function(n){return!!n&&"bytesValue"in n})(e)?new f("BYTES",e):e.referenceValue?new f("REFERENCE",e):e.geoPointValue?new f("GEO_POINT",e):zt(e)?new f("ARRAY",e):rs(e)?new f("VECTOR",e):yt(e)?new f("MAP",e):new f("ERROR",void 0)}Mi(){return this.type==="ERROR"||this.type==="UNSET"}Ni(){return this.type==="NULL"}}function _n(r){if(!r.Mi())return r.value}function Xo(r){return r instanceof at?r._expr:r}function x(r){if((r=Xo(r))instanceof Ht)return new th(r);if(r instanceof Yt)return new nh(r);if(r instanceof an)return new rh(r);if(r instanceof m){if(r.name==="add")return new ah(r);if(r.name==="subtract")return new oh(r);if(r.name==="multiply")return new uh(r);if(r.name==="divide")return new ch(r);if(r.name==="mod")return new lh(r);if(r.name==="and")return new hh(r);if(r.name==="equal")return new Ah(r);if(r.name==="not_equal")return new Vh(r);if(r.name==="less_than")return new vh(r);if(r.name==="less_than_or_equal")return new Rh(r);if(r.name==="greater_than")return new Ph(r);if(r.name==="greater_than_or_equal")return new xh(r);if(r.name==="array_concat")return new bh(r);if(r.name==="array_reverse")return new Ch(r);if(r.name==="array_contains")return new Sh(r);if(r.name==="array_contains_all")return new Nh(r);if(r.name==="array_contains_any")return new Dh(r);if(r.name==="array_length")return new kh(r);if(r.name==="array_element")return new Lh(r);if(r.name==="equal_any")return new Jo(r);if(r.name==="not_equal_any")return new dh(r);if(r.name==="is_nan")return new mh(r);if(r.name==="is_not_nan")return new ph(r);if(r.name==="is_null")return new _h(r);if(r.name==="is_not_null")return new gh(r);if(r.name==="is_error")return new yh(r);if(r.name==="exists")return new Eh(r);if(r.name==="not")return new $r(r);if(r.name==="or")return new fh(r);if(r.name==="xor")return new Ys(r);if(r.name==="conditional")return new Th(r);if(r.name==="maximum")return new wh(r);if(r.name==="minimum")return new Ih(r);if(r.name==="reverse")return new Oh(r);if(r.name==="replace_first")return new Mh(r);if(r.name==="replace_all")return new Uh(r);if(r.name==="char_length")return new Fh(r);if(r.name==="byte_length")return new qh(r);if(r.name==="like")return new Bh(r);if(r.name==="regex_contains")return new $h(r);if(r.name==="regex_match")return new zh(r);if(r.name==="string_contains")return new jh(r);if(r.name==="starts_with")return new Gh(r);if(r.name==="ends_with")return new Kh(r);if(r.name==="to_lower")return new Wh(r);if(r.name==="to_upper")return new Qh(r);if(r.name==="trim")return new Hh(r);if(r.name==="string_concat")return new Yh(r);if(r.name==="map_get")return new Xh(r);if(r.name==="cosine_distance")return new Jh(r);if(r.name==="dot_product")return new Zh(r);if(r.name==="euclidean_distance")return new ef(r);if(r.name==="vector_length")return new tf(r);if(r.name==="unix_micros_to_timestamp")return new of(r);if(r.name==="timestamp_to_unix_micros")return new lf(r);if(r.name==="unix_millis_to_timestamp")return new uf(r);if(r.name==="timestamp_to_unix_millis")return new hf(r);if(r.name==="unix_seconds_to_timestamp")return new cf(r);if(r.name==="timestamp_to_unix_seconds")return new ff(r);if(r.name==="timestamp_add")return new df(r);if(r.name==="timestamp_subtract")return new mf(r)}throw new Error(`Unknown Expr : ${r}`)}class th{constructor(e){this.expr=e}evaluate(e,t){if(this.expr.fieldName===Se)return f.newValue({referenceValue:Sn(e.serializer,t.key)});if(this.expr.fieldName==="__update_time__")return f.newValue({timestampValue:ar(e.serializer,t.version)});if(this.expr.fieldName==="__create_time__")return f.newValue({timestampValue:ar(e.serializer,t.createTime)});const n=t.data.field(this.expr._fieldPath);return n?Is(n)?f.newValue((function(i,a){if(i.serverTimestampBehavior==="estimate")return{timestampValue:ar(i.serializer,b.fromTimestamp(qt(a)))};if(i.serverTimestampBehavior==="previous"){const o=qn(a);if(o)return o}return{nullValue:"NULL_VALUE"}})(e,n)):f.newValue(n):f.Fi()}}class nh{constructor(e){this.expr=e}evaluate(e,t){return f.newValue(this.expr._getValue())}}class rh{constructor(e){this.expr=e}evaluate(e,t){const n=this.expr.fi.map((s=>x(s).evaluate(e,t)));return n.some((s=>s.Mi()))?f.Ci():f.newValue({arrayValue:{values:n.map((s=>s.value))}})}}function re(r){return De(r)?Number(r.doubleValue):Number(r.integerValue)}function Me(r){return BigInt(r.integerValue)}const sh=BigInt("0x7fffffffffffffff"),ih=-BigInt("0x8000000000000000");class Gn{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length>=2,24778);const n=x(this.expr.params[0]).evaluate(e,t),s=x(this.expr.params[1]).evaluate(e,t);let i=this.Bi(n,s);for(const a of this.expr.params.slice(2)){const o=x(a).evaluate(e,t);i=this.Bi(i,o)}return i}Bi(e,t){if(e.Mi()||t.Mi())return f.Ci();if(e.Ni()||t.Ni())return f.Oi();const n=e.value,s=t.value;if(!De(n)&&!Ne(n)||!De(s)&&!Ne(s))return f.Ci();if(De(n)||De(s)){const i=this.Li(n,s);return i?f.newValue(i):f.Ci()}if(Ne(n)&&Ne(s)){const i=this.Ui(n,s);return i===void 0?f.Ci():typeof i=="number"?f.newValue({doubleValue:i}):i<ih||i>sh?f.Ci():f.newValue({integerValue:`${i}`})}return f.Ci()}}function We(r,e){return Q(r)!==Q(e)?"TYPE_MISMATCH":ee(r)||ee(e)?"NOT_EQ":Ee(r)&&Ee(e)?"EQ":Ee(r)||Ee(e)?"NULL":zt(r)&&zt(e)?(function(n,s){if(n.values?.length!==s.values?.length)return"NOT_EQ";let i=!1;for(let a=0;a<(n.values?.length??0);a++){const o=n.values[a],u=s.values[a];switch(We(o,u)){case"EQ":break;case"NOT_EQ":case"TYPE_MISMATCH":return"NOT_EQ";case"NULL":i=!0;break;default:A(44609,{ki:o,Qi:u})}}return i?"NULL":"EQ"})(r.arrayValue,e.arrayValue):rs(r)&&rs(e)||yt(r)&&yt(e)?(function(n,s){const i=n.fields||{},a=s.fields||{};if(It(i)!==It(a))return"NOT_EQ";let o=!1;for(const u in i)if(i.hasOwnProperty(u)){if(a[u]===void 0)return"NOT_EQ";switch(We(i[u],a[u])){case"NOT_EQ":case"TYPE_MISMATCH":return"NOT_EQ";case"NULL":o=!0}}return o?"NULL":"EQ"})(r.mapValue,e.mapValue):(function(n,s){return ve(n,s,{be:!1,ye:!0,we:!0})})(r,e)?"EQ":"NOT_EQ"}class ah extends Gn{Ui(e,t){return Me(e)+Me(t)}Li(e,t){return{doubleValue:re(e)+re(t)}}}class oh extends Gn{constructor(e){super(e),this.expr=e}Ui(e,t){return Me(e)-Me(t)}Li(e,t){return{doubleValue:re(e)-re(t)}}}class uh extends Gn{constructor(e){super(e),this.expr=e}Ui(e,t){return Me(e)*Me(t)}Li(e,t){return{doubleValue:re(e)*re(t)}}}class ch extends Gn{constructor(e){super(e),this.expr=e}Ui(e,t){const n=Me(t);if(n!==BigInt(0))return Me(e)/n}Li(e,t){const n=re(t);return n===0?{doubleValue:En(n)?Number.NEGATIVE_INFINITY:Number.POSITIVE_INFINITY}:{doubleValue:re(e)/n}}}class lh extends Gn{constructor(e){super(e),this.expr=e}Ui(e,t){const n=Me(t);if(n!==BigInt(0))return Me(e)%n}Li(e,t){const n=re(t);if(n!==0)return{doubleValue:re(e)%n}}}class hh{constructor(e){this.expr=e}evaluate(e,t){let n=!1,s=!1;for(const i of this.expr.params){const a=x(i).evaluate(e,t);switch(a.type){case"BOOLEAN":if(!a.value?.booleanValue)return f.newValue(Z);break;case"NULL":s=!0;break;default:n=!0}}return n?f.Ci():s?f.Oi():f.newValue(me)}}class $r{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===1,9634);const n=x(this.expr.params[0]).evaluate(e,t);switch(n.type){case"BOOLEAN":return f.newValue({booleanValue:!n.value?.booleanValue});case"NULL":return f.Oi();default:return f.Ci()}}}class fh{constructor(e){this.expr=e}evaluate(e,t){let n=!1,s=!1;for(const i of this.expr.params){const a=x(i).evaluate(e,t);switch(a.type){case"BOOLEAN":if(a.value?.booleanValue)return f.newValue(me);break;case"NULL":s=!0;break;default:n=!0}}return n?f.Ci():s?f.Oi():f.newValue(Z)}}class Ys{constructor(e){this.expr=e}evaluate(e,t){let n=!1,s=!1;for(const i of this.expr.params){const a=x(i).evaluate(e,t);switch(a.type){case"BOOLEAN":n=Ys.xor(n,!!a.value?.booleanValue);break;case"NULL":s=!0;break;default:return f.Ci()}}return s?f.Oi():f.newValue({booleanValue:n})}static xor(e,t){return(e||t)&&!(e&&t)}}class Jo{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===2,55094);let n=!1;const s=x(this.expr.params[0]).evaluate(e,t);switch(s.type){case"NULL":n=!0;break;case"ERROR":case"UNSET":return f.Ci()}const i=x(this.expr.params[1]).evaluate(e,t);switch(i.type){case"ARRAY":break;case"NULL":n=!0;break;default:return f.Ci()}if(n)return f.Oi();for(const a of i.value?.arrayValue?.values??[])switch(Ee(s.value)&&Ee(a)?"EQ":We(s.value,a)){case"EQ":return f.newValue(me);case"NOT_EQ":case"TYPE_MISMATCH":break;case"NULL":n=!0;break;default:A(44608,{value:s.value,candidate:a})}return n?f.Oi():f.newValue(Z)}}class dh{constructor(e){this.expr=e}evaluate(e,t){return new $r(new m("not",[new m("equal_any",this.expr.params)])).evaluate(e,t)}}class mh{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===1,23322);const n=x(this.expr.params[0]).evaluate(e,t);switch(n.type){case"INT":return f.newValue(Z);case"DOUBLE":return f.newValue({booleanValue:isNaN(re(n.value))});case"NULL":return f.Oi();default:return f.Ci()}}}class ph{constructor(e){this.expr=e}evaluate(e,t){return I(this.expr.params.length===1,50406),new $r(new m("not",[new m("is_nan",this.expr.params)])).evaluate(e,t)}}class _h{constructor(e){this.expr=e}evaluate(e,t){switch(I(this.expr.params.length===1,23123),x(this.expr.params[0]).evaluate(e,t).type){case"NULL":return f.newValue(me);case"UNSET":case"ERROR":return f.Ci();default:return f.newValue(Z)}}}class gh{constructor(e){this.expr=e}evaluate(e,t){return I(this.expr.params.length===1,23167),new $r(new m("not",[new m("is_null",this.expr.params)])).evaluate(e,t)}}class yh{constructor(e){this.expr=e}evaluate(e,t){return I(this.expr.params.length===1,5228),x(this.expr.params[0]).evaluate(e,t).type==="ERROR"?f.newValue(me):f.newValue(Z)}}class Eh{constructor(e){this.expr=e}evaluate(e,t){switch(I(this.expr.params.length===1,6877),x(this.expr.params[0]).evaluate(e,t).type){case"ERROR":return f.Ci();case"UNSET":return f.newValue(Z);default:return f.newValue(me)}}}class Th{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===3,11706);const n=x(this.expr.params[0]).evaluate(e,t);switch(n.type){case"BOOLEAN":return n.value?.booleanValue?x(this.expr.params[1]).evaluate(e,t):x(this.expr.params[2]).evaluate(e,t);case"NULL":return x(this.expr.params[2]).evaluate(e,t);default:return f.Ci()}}}class wh{constructor(e){this.expr=e}evaluate(e,t){const n=this.expr.params.map((i=>x(i).evaluate(e,t)));let s;for(const i of n)switch(i.type){case"ERROR":case"UNSET":case"NULL":continue;default:s=s===void 0||pe(i.value,s.value)>0?i:s}return s===void 0?f.Oi():s}}class Ih{constructor(e){this.expr=e}evaluate(e,t){const n=this.expr.params.map((i=>x(i).evaluate(e,t)));let s;for(const i of n)switch(i.type){case"ERROR":case"UNSET":case"NULL":continue;default:s=s===void 0||pe(i.value,s.value)<0?i:s}return s===void 0?f.Oi():s}}class Xt{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===2,31033,`${this.expr.name}() function should have exactly 2 params`);const n=x(this.expr.params[0]).evaluate(e,t);switch(n.type){case"ERROR":case"UNSET":return f.Ci()}const s=x(this.expr.params[1]).evaluate(e,t);switch(s.type){case"ERROR":case"UNSET":return f.Ci()}return this.qi(n,s)}}class Ah extends Xt{constructor(e){super(e),this.expr=e}qi(e,t){if(e.Ni()&&t.Ni())return f.newValue(me);if(e.Ni()||t.Ni()||ee(e.value)||ee(t.value)||Q(e.value)!==Q(t.value))return f.newValue(Z);switch(We(e.value,t.value)){case"EQ":return f.newValue(me);case"NOT_EQ":return f.newValue(Z);case"NULL":return f.Oi();default:A(44615,{left:e,right:t})}}}class Vh extends Xt{constructor(e){super(e),this.expr=e}qi(e,t){switch(We(e.value,t.value)){case"EQ":return f.newValue(Z);case"NOT_EQ":case"TYPE_MISMATCH":return f.newValue(me);case"NULL":return f.Oi();default:A(44614,{left:e,right:t})}}}class vh extends Xt{constructor(e){super(e),this.expr=e}qi(e,t){return Q(e.value)!==Q(t.value)||ee(e.value)||ee(t.value)?f.newValue(Z):f.newValue({booleanValue:pe(e.value,t.value)<0})}}class Rh extends Xt{constructor(e){super(e),this.expr=e}qi(e,t){return Q(e.value)!==Q(t.value)||ee(e.value)||ee(t.value)?f.newValue(Z):We(e.value,t.value)==="EQ"?f.newValue(me):f.newValue({booleanValue:pe(e.value,t.value)<0})}}class Ph extends Xt{constructor(e){super(e),this.expr=e}qi(e,t){return Q(e.value)!==Q(t.value)||ee(e.value)||ee(t.value)?f.newValue(Z):f.newValue({booleanValue:pe(e.value,t.value)>0})}}class xh extends Xt{constructor(e){super(e),this.expr=e}qi(e,t){return Q(e.value)!==Q(t.value)||ee(e.value)||ee(t.value)?f.newValue(Z):We(e.value,t.value)==="EQ"?f.newValue(me):f.newValue({booleanValue:pe(e.value,t.value)>0})}}class bh{constructor(e){this.expr=e}evaluate(e,t){throw new Error("Unimplemented")}}class Ch{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===1,216);const n=x(this.expr.params[0]).evaluate(e,t);switch(n.type){case"NULL":return f.Oi();case"ARRAY":{const s=n.value.arrayValue?.values??[];return f.newValue({arrayValue:{values:[...s].reverse()}})}default:return f.Ci()}}}class Sh{constructor(e){this.expr=e}evaluate(e,t){return I(this.expr.params.length===2,52884),new Jo(new m("eq_any",[this.expr.params[1],this.expr.params[0]])).evaluate(e,t)}}class Nh{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===2,1392);let n=!1;const s=x(this.expr.params[0]).evaluate(e,t);switch(s.type){case"ARRAY":break;case"NULL":n=!0;break;default:return f.Ci()}const i=x(this.expr.params[1]).evaluate(e,t);switch(i.type){case"ARRAY":break;case"NULL":n=!0;break;default:return f.Ci()}if(n)return f.Oi();const a=i.value?.arrayValue?.values??[],o=s.value?.arrayValue?.values??[];for(const u of a){let c=!1;n=!1;for(const l of o){switch(Ee(u)&&Ee(l)?"EQ":We(u,l)){case"EQ":c=!0;break;case"NOT_EQ":case"TYPE_MISMATCH":break;case"NULL":n=!0;break;default:A(44613,{value:l,search:u})}if(c)break}if(!c)return f.newValue(Z)}return f.newValue(me)}}class Dh{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===2,2680);let n=!1;const s=x(this.expr.params[0]).evaluate(e,t);switch(s.type){case"ARRAY":break;case"NULL":n=!0;break;default:return f.Ci()}const i=x(this.expr.params[1]).evaluate(e,t);switch(i.type){case"ARRAY":break;case"NULL":n=!0;break;default:return f.Ci()}if(n)return f.Oi();const a=i.value?.arrayValue?.values??[],o=s.value?.arrayValue?.values??[];for(const u of o)for(const c of a)switch(Ee(u)&&Ee(c)?"EQ":We(u,c)){case"EQ":return f.newValue(me);case"NOT_EQ":case"TYPE_MISMATCH":break;case"NULL":n=!0;break;default:A(60403,{value:u,search:c})}return n?f.Oi():f.newValue(Z)}}class kh{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===1,38605);const n=x(this.expr.params[0]).evaluate(e,t);switch(n.type){case"NULL":return f.Oi();case"ARRAY":return f.newValue({integerValue:`${n.value?.arrayValue?.values?.length??0}`});default:return f.Ci()}}}class Lh{constructor(e){this.expr=e}evaluate(e,t){throw new Error("Unimplemented")}}class Oh{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===1,1508);const n=x(this.expr.params[0]).evaluate(e,t);switch(n.type){case"NULL":return f.Oi();case"BYTES":{const s=n.value?.bytesValue;if(typeof s=="string"){const i=B.fromBase64String(s).toUint8Array();return i.reverse(),f.newValue({bytesValue:B.fromUint8Array(i).toBase64()})}return f.newValue({bytesValue:new Uint8Array(s).reverse()})}case"STRING":{const s=n.value?.stringValue,i=new Intl.__PRIVATE_Segmenter(void 0,{granularity:"grapheme"}).segment(s),a=Array.from(i,(o=>o.segment)).reverse();return f.newValue({stringValue:a.join("")})}default:return f.Ci()}}}class Mh{constructor(e){this.expr=e}evaluate(e,t){throw new Error("Unimplemented")}}class Uh{constructor(e){this.expr=e}evaluate(e,t){throw new Error("Unimplemented")}}class Fh{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===1,19400);const n=x(this.expr.params[0]).evaluate(e,t);switch(n.type){case"NULL":return f.Oi();case"STRING":{const s=(function(a){let o=0;for(let u=0;u<a.length;u++){const c=a.codePointAt(u);if(c===void 0)return;if(c<=65535)if(c>=55296&&c<=57343)if(c<=56319){const l=a.codePointAt(u+1);l!==void 0&&l>=56320&&l<=57343?(o+=1,u++):o+=1}else o+=1;else o+=1;else{if(!(c<=1114111))return;o+=1,u++}}return o})(n.value.stringValue);return s===void 0?f.Ci():f.newValue({integerValue:s})}default:return f.Ci()}}}class qh{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===1,8486);const n=x(this.expr.params[0]).evaluate(e,t);switch(n.type){case"BYTES":{const s=n.value?.bytesValue;return typeof s=="string"?f.newValue({integerValue:B.fromBase64String(s).toUint8Array().length}):f.newValue({integerValue:new Uint8Array(s).length})}case"STRING":{const s=(function(a){let o=0;for(let u=0;u<a.length;u++){const c=a.codePointAt(u);if(c===void 0)return;if(c>=55296&&c<=57343){if(!(c<=56319))return;{const l=a.codePointAt(u+1);if(l===void 0||!(l>=56320&&l<=57343))return;o+=4,u++}}else if(c<=127)o+=1;else if(c<=2047)o+=2;else if(c<=65535)o+=3;else{if(!(c<=1114111))return;o+=4,u++}}return o})(n.value?.stringValue);return s===void 0?f.Ci():f.newValue({integerValue:s})}case"NULL":return f.Oi();default:return f.Ci()}}}class Jt{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===2,39773,`${this.expr.name}() function should have exactly two parameters`);let n=!1;const s=x(this.expr.params[0]).evaluate(e,t);switch(s.type){case"STRING":break;case"NULL":n=!0;break;default:return f.Ci()}const i=x(this.expr.params[1]).evaluate(e,t);switch(i.type){case"STRING":break;case"NULL":n=!0;break;default:return f.Ci()}return n?f.Oi():this.Ki(s.value?.stringValue,i.value?.stringValue)}}class Bh extends Jt{Ki(e,t){try{const n=(function(a){let o="";for(let u=0;u<a.length;u++){const c=a.charAt(u);switch(c){case"_":o+=".";break;case"%":o+=".*";break;case"\\":case".":case"*":case"?":case"+":case"^":case"$":case"|":case"(":case")":case"[":case"]":case"{":case"}":o+="\\"+c;break;default:o+=c}}return"^"+o+"$"})(t),s=Es.compile(n);return f.newValue({booleanValue:s.matches(e)})}catch(n){return xe(`Invalid LIKE pattern converted to regex: ${t}, returning error. Error: ${n}`),f.Ci()}}}class $h extends Jt{Ki(e,t){try{const n=Es.compile(t);return f.newValue({booleanValue:n.test(e)})}catch{return xe(`Invalid regex pattern found in regex_contains: ${t}, returning error`),f.Ci()}}}class zh extends Jt{Ki(e,t){try{return f.newValue({booleanValue:Es.compile(t).matches(e)})}catch{return xe(`Invalid regex pattern found in regex_match: ${t}, returning error`),f.Ci()}}}class jh extends Jt{Ki(e,t){return f.newValue({booleanValue:e.includes(t)})}}class Gh extends Jt{Ki(e,t){return f.newValue({booleanValue:e.startsWith(t)})}}class Kh extends Jt{Ki(e,t){return f.newValue({booleanValue:e.endsWith(t)})}}class Wh{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===1,29079);const n=x(this.expr.params[0]).evaluate(e,t);switch(n.type){case"STRING":return f.newValue({stringValue:n.value?.stringValue?.toLowerCase()});case"NULL":return f.Oi();default:return f.Ci()}}}class Qh{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===1,60487);const n=x(this.expr.params[0]).evaluate(e,t);switch(n.type){case"STRING":return f.newValue({stringValue:n.value?.stringValue?.toUpperCase()});case"NULL":return f.Oi();default:return f.Ci()}}}class Hh{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===1,28544);const n=x(this.expr.params[0]).evaluate(e,t);switch(n.type){case"STRING":return f.newValue({stringValue:n.value?.stringValue?.trim()});case"NULL":return f.Oi();default:return f.Ci()}}}class Yh{constructor(e){this.expr=e}evaluate(e,t){const n=this.expr.params.map((a=>x(a).evaluate(e,t)));let s="",i=!1;for(const a of n)switch(a.type){case"STRING":s+=a.value.stringValue;break;case"NULL":i=!0;break;default:return f.Ci()}return i?f.Oi():f.newValue({stringValue:s})}}class Xh{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===2,4483);const n=x(this.expr.params[0]).evaluate(e,t);switch(n.type){case"UNSET":return f.Fi();case"MAP":break;default:return f.Ci()}const s=x(this.expr.params[1]).evaluate(e,t);if(s.type!=="STRING")return f.Ci();const i=n.value?.mapValue?.fields?.[s.value?.stringValue];return i===void 0?f.Fi():f.newValue(i)}}class Xs{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===2,25231,`${this.expr.name}() function should have exactly 2 params`);let n=!1;const s=x(this.expr.params[0]).evaluate(e,t);switch(s.type){case"VECTOR":break;case"NULL":n=!0;break;default:return f.Ci()}const i=x(this.expr.params[1]).evaluate(e,t);switch(i.type){case"VECTOR":break;case"NULL":n=!0;break;default:return f.Ci()}if(n)return f.Oi();const a=ss(s.value),o=ss(i.value);if(a===void 0||o===void 0||a.values?.length!==o.values?.length)return f.Ci();const u=this.$i(a,o);return u===void 0||isNaN(u)?f.Ci():f.newValue({doubleValue:u})}}class Jh extends Xs{$i(e,t){const n=e?.values??[],s=t?.values??[];if(n.length===0)return;let i=0,a=0,o=0;for(let c=0;c<n.length;c++){if(!Ke(n[c])||!Ke(s[c]))return;const l=re(n[c]),h=re(s[c]);i+=l*h,a+=l*l,o+=h*h}const u=Math.sqrt(a)*Math.sqrt(o);if(u!==0)return 1-Math.max(-1,Math.min(1,i/u))}}class Zh extends Xs{$i(e,t){const n=e?.values??[],s=t?.values??[];if(n.length===0)return 0;let i=0;for(let a=0;a<n.length;a++){if(!Ke(n[a])||!Ke(s[a]))return;i+=re(n[a])*re(s[a])}return i}}class ef extends Xs{$i(e,t){const n=e?.values??[],s=t?.values??[];if(n.length===0)return 0;let i=0;for(let a=0;a<n.length;a++){if(!Ke(n[a])||!Ke(s[a]))return;const o=re(n[a]),u=re(s[a]);i+=Math.pow(o-u,2)}return Math.sqrt(i)}}class tf{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===1,39044);const n=x(this.expr.params[0]).evaluate(e,t);switch(n.type){case"VECTOR":{const s=ss(n.value);return f.newValue({integerValue:s?.values?.length??0})}case"NULL":return f.Oi();default:return f.Ci()}}}const kn=BigInt(-62135596800),Ln=BigInt(253402300799),Tr=BigInt(1e3),Ze=BigInt(1e6),nf=kn*Tr,rf=Ln*Tr+BigInt(999),sf=kn*Ze,af=Ln*Ze+BigInt(999999);function Js(r){return r>=sf&&r<=af}function Zo(r){return r>=kn&&r<=Ln}function On(r,e){const t=BigInt(r);return!(t<kn||t>Ln)&&!(e<0||e>=1e9)&&(t!==kn||e===0)&&!(t===Ln&&e>999999999)}function eu(r,e){return e<0?{seconds:r-1,nanos:e+1e9}:{seconds:r,nanos:e}}function Zs(r){return BigInt(r.seconds)*Ze+BigInt(Math.trunc(r.nanoseconds/1e3))}class ei{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===1,49262,`${this.expr.name}() function should have exactly one parameter`);const n=x(this.expr.params[0]).evaluate(e,t);switch(n.type){case"INT":return this.toTimestamp(BigInt(n.value.integerValue));case"NULL":return f.Oi();default:return f.Ci()}}}class of extends ei{toTimestamp(e){if(!Js(e))return f.Ci();let t=Number(e/Ze),n=Number(e%Ze*BigInt(1e3));const s=eu(t,n);return t=s.seconds,n=s.nanos,On(t,n)?f.newValue({timestampValue:{seconds:t,nanos:n}}):f.Ci()}}class uf extends ei{toTimestamp(e){if(!(function(a){return a>=nf&&a<=rf})(e))return f.Ci();let t=Number(e/Tr),n=Number(e%Tr*BigInt(1e6));const s=eu(t,n);return t=s.seconds,n=s.nanos,On(t,n)?f.newValue({timestampValue:{seconds:t,nanos:n}}):f.Ci()}}class cf extends ei{toTimestamp(e){if(!Zo(e))return f.Ci();const t=Number(e);return f.newValue({timestampValue:{seconds:t,nanos:0}})}}class ti{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===1,1265,`${this.expr.name}() function should have exactly one parameter`);const n=x(this.expr.params[0]).evaluate(e,t);switch(n.type){case"TIMESTAMP":break;case"NULL":return f.Oi();default:return f.Ci()}const s=Ds(n.value.timestampValue);return On(s.seconds,s.nanoseconds)?this.Wi(s):f.Ci()}}class lf extends ti{Wi(e){const t=Zs(e);return Js(t)?f.newValue({integerValue:`${t.toString()}`}):f.Ci()}}class hf extends ti{Wi(e){const t=Zs(e),n=t/BigInt(1e3),s=t%BigInt(1e3);return n>BigInt(0)||s===BigInt(0)?f.newValue({integerValue:n.toString()}):f.newValue({integerValue:(n-BigInt(1)).toString()})}}class ff extends ti{Wi(e){const t=BigInt(e.seconds);return Zo(t)?f.newValue({integerValue:t.toString()}):f.Ci()}}class tu{constructor(e){this.expr=e}evaluate(e,t){I(this.expr.params.length===3,2775,`${this.expr.name}() function should have exactly 3 parameters`);let n=!1;const s=x(this.expr.params[0]).evaluate(e,t);switch(s.type){case"TIMESTAMP":break;case"NULL":n=!0;break;default:return f.Ci()}const i=x(this.expr.params[1]).evaluate(e,t);let a;switch(i.type){case"STRING":if(a=(function(j){switch(j){case"microsecond":return"microsecond";case"millisecond":return"millisecond";case"second":return"second";case"minute":return"minute";case"hour":return"hour";case"day":return"day";default:return}})(i.value.stringValue),a===void 0)return f.Ci();break;case"NULL":n=!0;break;default:return f.Ci()}const o=x(this.expr.params[2]).evaluate(e,t);switch(o.type){case"INT":break;case"NULL":n=!0;break;default:return f.Ci()}if(n)return f.Oi();const u=BigInt(o.value.integerValue);let c;try{switch(a){case"microsecond":c=u;break;case"millisecond":c=u*BigInt(1e3);break;case"second":c=u*BigInt(1e6);break;case"minute":c=u*BigInt(6e7);break;case"hour":c=u*BigInt(36e8);break;case"day":c=u*BigInt(864e8);break;default:return f.Ci()}if(a!=="microsecond"&&u!==BigInt(0)&&c/u!==BigInt(this.Gi(a)))return f.Ci()}catch(O){return xe(`Error during timestamp arithmetic: ${O}`),f.Ci()}const l=Ds(s.value.timestampValue);if(!On(l.seconds,l.nanoseconds))return f.Ci();const h=Zs(l),d=this.ji(h,c);if(!Js(d))return f.Ci();const g=Number(d/Ze),T=d%Ze,C=Number((T<0?T+Ze:T)*BigInt(1e3)),P=T<0?g-1:g;return On(P,C)?f.newValue({timestampValue:{seconds:P,nanos:C}}):f.Ci()}Gi(e){switch(e){case"millisecond":return 1e3;case"second":return 1e6;case"minute":return 6e7;case"hour":return 36e8;case"day":return 864e8;default:return 1}}}class df extends tu{ji(e,t){return e+t}}class mf extends tu{ji(e,t){return e-t}}function Mn(r){if((r=Xo(r))instanceof Ht)return`fld(${r.fieldName})`;if(r instanceof Yt)return`cst(${(function(t){return t===null?"null":typeof t=="number"?t.toString():typeof t=="string"?`"${t}"`:t instanceof F?`ref(${t.path})`:t instanceof de?`vec(${JSON.stringify(t)})`:JSON.stringify(t)})(r.value)})`;if(r instanceof m)return`fn(${r.name},[${r.params.map(Mn).join(",")}])`;if(r.expressionType==="ListOfExpressions")return`list([${r.fi.map(Mn).join(",")}])`;throw new Error(`Unrecognized expr ${JSON.stringify(r,null,2)}`)}function pf(r){if(r instanceof Qo)return`${r._name}(${tr(r.fields)})`;if(r instanceof Ho){let e=`${r._name}(${tr(r.accumulators)})`;return r.groups.size>0&&(e+=`grouping(${tr(r.groups)})`),e}if(r instanceof Yo)return`${r._name}(${tr(r.groups)})`;if(r instanceof Ur)return`${r._name}(${r.pi})`;if(r instanceof Fr)return`${r._name}(${r.collectionId})`;if(r instanceof Ks)return`${r._name}()`;if(r instanceof Ws)return`${r._name}(${r.gi.sort()})`;if(r instanceof qr)return`${r._name}(${Mn(r.condition)})`;if(r instanceof vt)return`${r._name}(${r.limit})`;if(r instanceof $e)return`${r._name}(${(function(t){return t.map((n=>`${Mn(n.expr)}${n.direction}`)).join(",")})(r.orderings)})`;throw new Error(`Unrecognized stage ${r._name}`)}function tr(r){return`${Array.from(r.entries()).sort().map((([e,t])=>`${e}=${Mn(t)}`)).join(",")}`}function je(r){return r.stages.map((e=>pf(e))).join("|")}function nu(r,e){return je(r)===je(e)}function H(r){return r instanceof ue}function da(r){return H(r)?je(r):hn(r)}function ru(r){return H(r)?je(r):(function(t){return`${co(ke(t))}|lt:${t.limitType}`})(r)}function zr(r,e){return r instanceof ue&&e instanceof ue?nu(r,e):!(r instanceof ue&&!(e instanceof ue)||!(r instanceof ue)&&e instanceof ue)&&kc(r,e)}function su(r){return pt(r)?je(r):co(r)}function iu(r,e){return r instanceof ue&&e instanceof ue?nu(r,e):!(r instanceof ue&&!(e instanceof ue)||!(r instanceof ue)&&e instanceof ue)&&lo(r,e)}function _f(r,e){const t=(function(s){let i=!1;const a=[];for(const o of s)if(o instanceof $e)if(i=!0,o.orderings.some((u=>u.expr instanceof Ht&&u.expr.fieldName===Se)))a.push(o);else{const u=o.orderings.map((c=>c));u.push(or(Se).ascending()),a.push(new $e(u,{}))}else o instanceof vt&&(i||(a.push(new $e([or(Se).ascending()],{})),i=!0)),a.push(o);return i||a.push(new $e([or(Se).ascending()],{})),a})(r.stages);if(r.userDataReader){const n=r.userDataReader.createContext(3,"toCorePipeline");t.forEach((s=>s._readUserData(n)))}return new ue(r.userDataReader.serializer,t,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gf{constructor(e,t,n,s){this.batchId=e,this.localWriteTime=t,this.baseMutations=n,this.mutations=s}applyToRemoteDocument(e,t){const n=t.mutationResults;for(let s=0;s<this.mutations.length;s++){const i=this.mutations[s];i.key.isEqual(e.key)&&pc(i,e,n[s])}}applyToLocalView(e,t){for(const n of this.baseMutations)n.key.isEqual(e.key)&&(t=cn(n,e,t,this.localWriteTime));for(const n of this.mutations)n.key.isEqual(e.key)&&(t=cn(n,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const n=yo();return this.mutations.forEach((s=>{const i=e.get(s.key),a=i.overlayedDocument;let o=this.applyToLocalView(a,i.mutatedFields);o=t.has(s.key)?null:o;const u=eo(a,o);u!==null&&n.set(s.key,u),a.isValidDocument()||a.convertToNoDocument(b.min())})),n}keys(){return this.mutations.reduce(((e,t)=>e.add(t.key)),D())}isEqual(e){return this.batchId===e.batchId&&Ft(this.mutations,e.mutations,((t,n)=>ji(t,n)))&&Ft(this.baseMutations,e.baseMutations,((t,n)=>ji(t,n)))}}class ni{constructor(e,t,n,s){this.batch=e,this.commitVersion=t,this.mutationResults=n,this.docVersions=s}static from(e,t,n){I(e.mutations.length===n.length,58842,{zi:e.mutations.length,Hi:n.length});let s=(function(){return Uc})();const i=e.mutations;for(let a=0;a<i.length;a++)s=s.insert(i[a].key,n[a].version);return new ni(e,t,n,s)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const au="";function yf(r){let e="";for(let t=0;t<r.length;t++)e.length>0&&(e=ma(e)),e=Ef(r.get(t),e);return ma(e)}function Ef(r,e){let t=e;const n=r.length;for(let s=0;s<n;s++){const i=r.charAt(s);switch(i){case"\0":t+="";break;case au:t+="";break;default:t+=i}}return t}function ma(r){return r+au+""}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Tf{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ze{constructor(e,t,n,s,i=b.min(),a=b.min(),o=B.EMPTY_BYTE_STRING,u=null){this.target=e,this.targetId=t,this.purpose=n,this.sequenceNumber=s,this.snapshotVersion=i,this.lastLimboFreeSnapshotVersion=a,this.resumeToken=o,this.expectedCount=u}withSequenceNumber(e){return new ze(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new ze(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new ze(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new ze(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wf{constructor(e){this.Yi=e}}function If(r){const e=tl({parent:r.parent,structuredQuery:r.structuredQuery});return r.limitType==="LAST"?yr(e,e.limit,"L"):e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Af{constructor(){this.A_=new Vf}addToCollectionParentIndex(e,t){return this.A_.add(t),_.resolve()}getCollectionParents(e,t){return _.resolve(this.A_.getEntries(t))}addFieldIndex(e,t){return _.resolve()}deleteFieldIndex(e,t){return _.resolve()}deleteAllFieldIndexes(e){return _.resolve()}createTargetIndexes(e,t){return _.resolve()}getDocumentsMatchingTarget(e,t){return _.resolve(null)}getIndexType(e,t){return _.resolve(0)}getFieldIndexes(e,t){return _.resolve([])}getNextCollectionGroupToUpdate(e){return _.resolve(null)}getMinOffset(e,t){return _.resolve(st.min())}getMinOffsetFromCollectionGroup(e,t){return _.resolve(st.min())}updateCollectionGroup(e,t,n){return _.resolve()}updateIndexEntries(e,t){return _.resolve()}}class Vf{constructor(){this.index={}}add(e){const t=e.lastSegment(),n=e.popLast(),s=this.index[t]||new W(L.comparator),i=!s.has(n);return this.index[t]=s.add(n),i}has(e){const t=e.lastSegment(),n=e.popLast(),s=this.index[t];return s&&s.has(n)}getEntries(e){return(this.index[e]||new W(L.comparator)).toArray()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ut{constructor(e){this.Q_=e}next(){return this.Q_+=2,this.Q_}static q_(){return new ut(0)}static K_(){return new ut(-1)}}// Copyright 2024 Google LLC* @license
function ou(r,e){let t=e;for(const n of r.stages)t=Rf({serializer:r.serializer,serverTimestampBehavior:r.listenOptions?.serverTimestampBehavior},n,t);return t}function jr(r,e){return ou(r,[e]).length>0}function vf(r,e){return H(r)?jr(r,e):Sr(r,e)}function Rf(r,e,t){if(e instanceof Ur)return(function(s,i,a){return a.filter((o=>o.isFoundDocument()&&`/${o.key.getCollectionPath().canonicalString()}`===i.pi))})(0,e,t);if(e instanceof qr)return(function(s,i,a){return a.filter((o=>{const u=_n(x(i.condition).evaluate(s,o));return u!==void 0&&ve(u,me)}))})(r,e,t);if(e instanceof Fr)return(function(s,i,a){return a.filter((o=>o.isFoundDocument()&&o.key.getCollectionPath().lastSegment()===i.collectionId))})(0,e,t);if(e instanceof Ks)return(function(s,i,a){return a.filter((o=>o.isFoundDocument()))})(0,0,t);if(e instanceof Ws)return(function(s,i,a){return a.filter((o=>o.isFoundDocument()&&i.yi.has(o.key.path.toStringWithLeadingSlash())))})(0,e,t);if(e instanceof vt)return(function(s,i,a){return a.slice(0,i.limit)})(0,e,t);if(e instanceof $e)return(function(s,i,a){const o=i.orderings.map((u=>({Z_:x(u.expr),direction:u.direction})));return[...a].sort(((u,c)=>{for(const{Z_:l,direction:h}of o){const d=_n(l.evaluate(s,u)),g=_n(l.evaluate(s,c)),T=pe(d??Bt,g??Bt);if(T!==0)return h==="ascending"?T:-T}return 0}))})(r,e,t);throw new Error(`Unknown stage: ${e._name}`)}function ds(r){const e=(function(n){for(let s=n.stages.length-1;s>=0;s--){const i=n.stages[s];if(i instanceof $e)return i.orderings}throw new Error("Pipeline must contain at least one Sort stage")})(r);return(t,n)=>{for(const s of e){const i=_n(x(s.expr).evaluate({serializer:r.serializer},t)),a=_n(x(s.expr).evaluate({serializer:r.serializer},n)),o=pe(i||Bt,a||Bt);if(o!==0)return s.direction==="ascending"?o:-o}return 0}}function Jr(r){for(let e=r.stages.length-1;e>=0;e--){const t=r.stages[e];if(t instanceof vt)return{limit:t.limit}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Pf{constructor(){this.changes=new Pt((e=>e.toString()),((e,t)=>e.isEqual(t))),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,J.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const n=this.changes.get(t);return n!==void 0?_.resolve(n):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xf{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class bf{constructor(e,t,n,s){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=n,this.indexManager=s}getDocument(e,t){let n=null;return this.documentOverlayCache.getOverlay(e,t).next((s=>(n=s,this.remoteDocumentCache.getEntry(e,t)))).next((s=>(n!==null&&cn(n.mutation,s,ye.empty(),M.now()),s)))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next((n=>this.getLocalViewOfDocuments(e,n,D()).next((()=>n))))}getLocalViewOfDocuments(e,t,n=D()){const s=He();return this.populateOverlays(e,s,t).next((()=>this.computeViews(e,t,s,n).next((i=>{let a=Nt();return i.forEach(((o,u)=>{a=a.insert(o,u.overlayedDocument)})),a}))))}getOverlayedDocuments(e,t){const n=He();return this.populateOverlays(e,n,t).next((()=>this.computeViews(e,t,n,D())))}populateOverlays(e,t,n){const s=[];return n.forEach((i=>{t.has(i)||s.push(i)})),this.documentOverlayCache.getOverlays(e,s).next((i=>{i.forEach(((a,o)=>{t.set(a,o)}))}))}computeViews(e,t,n,s){let i=fe();const a=fn(),o=(function(){return fn()})();return t.forEach(((u,c)=>{const l=n.get(c.key);s.has(c.key)&&(l===void 0||l.mutation instanceof dt)?i=i.insert(c.key,c):l!==void 0?(a.set(c.key,l.mutation.getFieldMask()),cn(l.mutation,c,l.mutation.getFieldMask(),M.now())):a.set(c.key,ye.empty())})),this.recalculateAndSaveOverlays(e,i).next((u=>(u.forEach(((c,l)=>a.set(c,l))),t.forEach(((c,l)=>o.set(c,new xf(l,a.get(c)??null)))),o)))}recalculateAndSaveOverlays(e,t){const n=fn();let s=new q(((a,o)=>a-o)),i=D();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next((a=>{for(const o of a)o.keys().forEach((u=>{const c=t.get(u);if(c===null)return;let l=n.get(u)||ye.empty();l=o.applyToLocalView(c,l),n.set(u,l);const h=(s.get(o.batchId)||D()).add(u);s=s.insert(o.batchId,h)}))})).next((()=>{const a=[],o=s.getReverseIterator();for(;o.hasNext();){const u=o.getNext(),c=u.key,l=u.value,h=yo();l.forEach((d=>{if(!i.has(d)){const g=eo(t.get(d),n.get(d));g!==null&&h.set(d,g),i=i.add(d)}})),a.push(this.documentOverlayCache.saveOverlays(e,c,h))}return _.waitFor(a)})).next((()=>n))}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next((n=>this.recalculateAndSaveOverlays(e,n)))}getDocumentsMatchingQuery(e,t,n,s){return H(t)?this.getDocumentsMatchingPipeline(e,t,n,s):Sc(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):fo(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,n,s):this.getDocumentsMatchingCollectionQuery(e,t,n,s)}getNextDocuments(e,t,n,s){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,n,s).next((i=>{const a=s-i.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,n.largestBatchId,s-i.size):_.resolve(He());let o=Cn,u=i;return a.next((c=>_.forEach(c,((l,h)=>(o<h.largestBatchId&&(o=h.largestBatchId),i.get(l)?_.resolve():this.remoteDocumentCache.getEntry(e,l).next((d=>{u=u.insert(l,d)}))))).next((()=>this.populateOverlays(e,c,i))).next((()=>this.computeViews(e,u,c,D()))).next((l=>({batchId:o,changes:go(l)})))))}))}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new V(t)).next((n=>{let s=Nt();return n.isFoundDocument()&&(s=s.insert(n.key,n)),s}))}getDocumentsMatchingCollectionGroupQuery(e,t,n,s){const i=t.collectionGroup;let a=Nt();return this.indexManager.getCollectionParents(e,i).next((o=>_.forEach(o,(u=>{const c=(function(h,d){return new Kt(d,null,h.explicitOrderBy.slice(),h.filters.slice(),h.limit,h.limitType,h.startAt,h.endAt)})(t,u.child(i));return this.getDocumentsMatchingCollectionQuery(e,c,n,s).next((l=>{l.forEach(((h,d)=>{a=a.insert(h,d)}))}))})).next((()=>a))))}getDocumentsMatchingCollectionQuery(e,t,n,s){let i;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,n.largestBatchId).next((a=>(i=a,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,n,i,s)))).next((a=>this.retrieveMatchingLocalDocuments(i,a,(o=>Sr(t,o)))))}getDocumentsMatchingPipeline(e,t,n,s){if(Je(t)==="collection_group"){const i=Hs(t);let a=Nt();return this.indexManager.getCollectionParents(e,i).next((o=>_.forEach(o,(u=>{const c=(function(h,d){const g=h.stages.map((T=>T instanceof Fr?new Ur(d.canonicalString(),{}):T));return new ue(h.serializer,g)})(t,u.child(i));return this.getDocumentsMatchingPipeline(e,c,n,s).next((l=>{l.forEach(((h,d)=>{a=a.insert(h,d)}))}))})).next((()=>a))))}{let i;return this.getOverlaysForPipeline(e,t,n.largestBatchId).next((a=>{switch(i=a,Je(t)){case"collection":return this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,n,i,s);case"documents":let o=D();for(const u of fs(t))o=o.add(V.fromPath(u));return this.remoteDocumentCache.getEntries(e,o);case"database":return this.remoteDocumentCache.getAllEntries(e);default:throw new y("invalid-argument",`Invalid pipeline source to execute offline: ${je(t)}`)}})).next((a=>this.retrieveMatchingLocalDocuments(i,a,(o=>jr(t,o)))))}}retrieveMatchingLocalDocuments(e,t,n){e.forEach(((i,a)=>{const o=a.getKey();t.get(o)===null&&(t=t.insert(o,J.newInvalidDocument(o)))}));let s=Nt();return t.forEach(((i,a)=>{const o=e.get(i);o!==void 0&&cn(o.mutation,a,ye.empty(),M.now()),n(a)&&(s=s.insert(i,a))})),s}getOverlaysForPipeline(e,t,n){switch(Je(t)){case"collection":return this.documentOverlayCache.getOverlaysForCollection(e,L.fromString(Br(t)),n);case"collection_group":throw new y("invalid-argument",`Unexpected collection group pipeline: ${je(t)}`);case"documents":return this.documentOverlayCache.getOverlays(e,fs(t).map((s=>V.fromPath(s))));case"database":return this.documentOverlayCache.getAllOverlays(e,n);default:throw new y("invalid-argument",`Failed to get overlays for pipeline: ${je(t)}`)}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cf{constructor(e){this.serializer=e,this.ao=new Map,this.uo=new Map}getBundleMetadata(e,t){return _.resolve(this.ao.get(t))}saveBundleMetadata(e,t){return this.ao.set(t.id,(function(s){return{id:s.id,version:s.version,createTime:Ie(s.createTime)}})(t)),_.resolve()}getNamedQuery(e,t){return _.resolve(this.uo.get(t))}saveNamedQuery(e,t){return this.uo.set(t.name,(function(s){return{name:s.name,query:If(s.bundledQuery),readTime:Ie(s.readTime)}})(t)),_.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Sf{constructor(){this.overlays=new q(V.comparator),this.co=new Map}getOverlay(e,t){return _.resolve(this.overlays.get(t))}getOverlays(e,t){const n=He();return _.forEach(t,(s=>this.getOverlay(e,s).next((i=>{i!==null&&n.set(s,i)})))).next((()=>n))}getAllOverlays(e,t){const n=He();return this.overlays.forEach(((s,i)=>{i.largestBatchId>t&&n.set(s,i)})),_.resolve(n)}saveOverlays(e,t,n){return n.forEach(((s,i)=>{this.cs(e,t,i)})),_.resolve()}removeOverlaysForBatchId(e,t,n){const s=this.co.get(n);return s!==void 0&&(s.forEach((i=>this.overlays=this.overlays.remove(i))),this.co.delete(n)),_.resolve()}getOverlaysForCollection(e,t,n){const s=He(),i=t.length+1,a=new V(t.child("")),o=this.overlays.getIteratorFrom(a);for(;o.hasNext();){const u=o.getNext().value,c=u.getKey();if(!t.isPrefixOf(c.path))break;c.path.length===i&&u.largestBatchId>n&&s.set(u.getKey(),u)}return _.resolve(s)}getOverlaysForCollectionGroup(e,t,n,s){let i=new q(((c,l)=>c-l));const a=this.overlays.getIterator();for(;a.hasNext();){const c=a.getNext().value;if(c.getKey().getCollectionGroup()===t&&c.largestBatchId>n){let l=i.get(c.largestBatchId);l===null&&(l=He(),i=i.insert(c.largestBatchId,l)),l.set(c.getKey(),c)}}const o=He(),u=i.getIterator();for(;u.hasNext()&&(u.getNext().value.forEach(((c,l)=>o.set(c,l))),!(o.size()>=s)););return _.resolve(o)}cs(e,t,n){const s=this.overlays.get(n.key);if(s!==null){const a=this.co.get(s.largestBatchId).delete(n.key);this.co.set(s.largestBatchId,a)}this.overlays=this.overlays.insert(n.key,new Tf(t,n));let i=this.co.get(t);i===void 0&&(i=D(),this.co.set(t,i)),this.co.set(t,i.add(n.key))}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nf{constructor(){this.sessionToken=B.EMPTY_BYTE_STRING}getSessionToken(e){return _.resolve(this.sessionToken)}setSessionToken(e,t){return this.sessionToken=t,_.resolve()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ri{constructor(){this.lo=new W(X.Eo),this.ho=new W(X.To)}isEmpty(){return this.lo.isEmpty()}addReference(e,t){const n=new X(e,t);this.lo=this.lo.add(n),this.ho=this.ho.add(n)}Po(e,t){e.forEach((n=>this.addReference(n,t)))}removeReference(e,t){this.Io(new X(e,t))}Ro(e,t){e.forEach((n=>this.removeReference(n,t)))}Ao(e){const t=new V(new L([])),n=new X(t,e),s=new X(t,e+1),i=[];return this.ho.forEachInRange([n,s],(a=>{this.Io(a),i.push(a.key)})),i}Vo(){this.lo.forEach((e=>this.Io(e)))}Io(e){this.lo=this.lo.delete(e),this.ho=this.ho.delete(e)}fo(e){const t=new V(new L([])),n=new X(t,e),s=new X(t,e+1);let i=D();return this.ho.forEachInRange([n,s],(a=>{i=i.add(a.key)})),i}containsKey(e){const t=new X(e,0),n=this.lo.firstAfterOrEqual(t);return n!==null&&e.isEqual(n.key)}}class X{constructor(e,t){this.key=e,this.mo=t}static Eo(e,t){return V.comparator(e.key,t.key)||N(e.mo,t.mo)}static To(e,t){return N(e.mo,t.mo)||V.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Df{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.ts=1,this.po=new W(X.Eo)}checkEmpty(e){return _.resolve(this.mutationQueue.length===0)}addMutationBatch(e,t,n,s){const i=this.ts;this.ts++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const a=new gf(i,t,n,s);this.mutationQueue.push(a);for(const o of s)this.po=this.po.add(new X(o.key,i)),this.indexManager.addToCollectionParentIndex(e,o.key.path.popLast());return _.resolve(a)}lookupMutationBatch(e,t){return _.resolve(this.yo(t))}getNextMutationBatchAfterBatchId(e,t){const n=t+1,s=this.wo(n),i=s<0?0:s;return _.resolve(this.mutationQueue.length>i?this.mutationQueue[i]:null)}getHighestUnacknowledgedBatchId(){return _.resolve(this.mutationQueue.length===0?As:this.ts-1)}getAllMutationBatches(e){return _.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const n=new X(t,0),s=new X(t,Number.POSITIVE_INFINITY),i=[];return this.po.forEachInRange([n,s],(a=>{const o=this.yo(a.mo);i.push(o)})),_.resolve(i)}getAllMutationBatchesAffectingDocumentKeys(e,t){let n=new W(N);return t.forEach((s=>{const i=new X(s,0),a=new X(s,Number.POSITIVE_INFINITY);this.po.forEachInRange([i,a],(o=>{n=n.add(o.mo)}))})),_.resolve(this.bo(n))}getAllMutationBatchesAffectingQuery(e,t){const n=t.path,s=n.length+1;let i=n;V.isDocumentKey(i)||(i=i.child(""));const a=new X(new V(i),0);let o=new W(N);return this.po.forEachWhile((u=>{const c=u.key.path;return!!n.isPrefixOf(c)&&(c.length===s&&(o=o.add(u.mo)),!0)}),a),_.resolve(this.bo(o))}bo(e){const t=[];return e.forEach((n=>{const s=this.yo(n);s!==null&&t.push(s)})),t}removeMutationBatch(e,t){I(this.So(t.batchId,"removed")===0,55003),this.mutationQueue.shift();let n=this.po;return _.forEach(t.mutations,(s=>{const i=new X(s.key,t.batchId);return n=n.delete(i),this.referenceDelegate.markPotentiallyOrphaned(e,s.key)})).next((()=>{this.po=n}))}ss(e){}containsKey(e,t){const n=new X(t,0),s=this.po.firstAfterOrEqual(n);return _.resolve(t.isEqual(s&&s.key))}performConsistencyCheck(e){return this.mutationQueue.length,_.resolve()}So(e,t){return this.wo(e)}wo(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}yo(e){const t=this.wo(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class kf{constructor(e){this.xo=e,this.docs=(function(){return new q(V.comparator)})(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const n=t.key,s=this.docs.get(n),i=s?s.size:0,a=this.xo(t);return this.docs=this.docs.insert(n,{document:t.mutableCopy(),size:a}),this.size+=a-i,this.indexManager.addToCollectionParentIndex(e,n.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const n=this.docs.get(t);return _.resolve(n?n.document.mutableCopy():J.newInvalidDocument(t))}getEntries(e,t){let n=fe();return t.forEach((s=>{const i=this.docs.get(s);n=n.insert(s,i?i.document.mutableCopy():J.newInvalidDocument(s))})),_.resolve(n)}getAllEntries(e){let t=fe();return this.docs.forEach(((n,s)=>{t=t.insert(n,s.document)})),_.resolve(t)}getDocumentsMatchingQuery(e,t,n,s){let i,a;H(t)?(i=L.fromString(Br(t)),a=l=>jr(t,l)):(i=t.path,a=l=>Sr(t,l));let o=fe();const u=new V(i.child("__id-9223372036854775808__")),c=this.docs.getIteratorFrom(u);for(;c.hasNext();){const{key:l,value:{document:h}}=c.getNext();if(!i.isPrefixOf(l.path))break;l.path.length>i.length+1||xc(Pc(h),n)<=0||(s.has(h.key)||a(h))&&(o=o.insert(h.key,h.mutableCopy()))}return _.resolve(o)}getAllFromCollectionGroup(e,t,n,s){A(9500)}vo(e,t){return _.forEach(this.docs,(n=>t(n)))}newChangeBuffer(e){return new Lf(this)}getSize(e){return _.resolve(this.size)}}class Lf extends Pf{constructor(e){super(),this._o=e}applyChanges(e){const t=[];return this.changes.forEach(((n,s)=>{s.isValidDocument()?t.push(this._o.addEntry(e,s)):this._o.removeEntry(n)})),_.waitFor(t)}getFromCache(e,t){return this._o.getEntry(e,t)}getAllFromCache(e,t){return this._o.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Of{constructor(e){this.persistence=e,this.Do=new Pt((t=>su(t)),iu),this.lastRemoteSnapshotVersion=b.min(),this.highestTargetId=0,this.Co=0,this.Fo=new ri,this.targetCount=0,this.Oo=ut.q_()}forEachTarget(e,t){return this.Do.forEach(((n,s)=>t(s))),_.resolve()}getLastRemoteSnapshotVersion(e){return _.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return _.resolve(this.Co)}allocateTargetId(e){return this.highestTargetId=this.Oo.next(),_.resolve(this.highestTargetId)}setTargetsMetadata(e,t,n){return n&&(this.lastRemoteSnapshotVersion=n),t>this.Co&&(this.Co=t),_.resolve()}j_(e){this.Do.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.Oo=new ut(t),this.highestTargetId=t),e.sequenceNumber>this.Co&&(this.Co=e.sequenceNumber)}addTargetData(e,t){return this.j_(t),this.targetCount+=1,_.resolve()}updateTargetData(e,t){return this.j_(t),_.resolve()}removeTargetData(e,t){return this.Do.delete(t.target),this.Fo.Ao(t.targetId),this.targetCount-=1,_.resolve()}removeTargets(e,t,n){let s=0;const i=[];return this.Do.forEach(((a,o)=>{o.sequenceNumber<=t&&n.get(o.targetId)===null&&(this.Do.delete(a),i.push(this.removeMatchingKeysForTargetId(e,o.targetId)),s++)})),_.waitFor(i).next((()=>s))}getTargetCount(e){return _.resolve(this.targetCount)}getTargetData(e,t){const n=this.Do.get(t)||null;return _.resolve(n)}addMatchingKeys(e,t,n){return this.Fo.Po(t,n),_.resolve()}removeMatchingKeys(e,t,n){this.Fo.Ro(t,n);const s=this.persistence.referenceDelegate,i=[];return s&&t.forEach((a=>{i.push(s.markPotentiallyOrphaned(e,a))})),_.waitFor(i)}removeMatchingKeysForTargetId(e,t){return this.Fo.Ao(t),_.resolve()}getMatchingKeysForTargetId(e,t){const n=this.Fo.fo(t);return _.resolve(n)}containsKey(e,t){return _.resolve(this.Fo.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uu{constructor(e,t){this.Mo={},this.overlays={},this.No=new Lr(0),this.Bo=!1,this.Bo=!0,this.Lo=new Nf,this.referenceDelegate=e(this),this.Uo=new Of(this),this.indexManager=new Af,this.remoteDocumentCache=(function(s){return new kf(s)})((n=>this.referenceDelegate.ko(n))),this.serializer=new wf(t),this.Qo=new Cf(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.Bo=!1,Promise.resolve()}get started(){return this.Bo}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new Sf,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let n=this.Mo[e.toKey()];return n||(n=new Df(t,this.referenceDelegate),this.Mo[e.toKey()]=n),n}getGlobalsCache(){return this.Lo}getTargetCache(){return this.Uo}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.Qo}runTransaction(e,t,n){w("MemoryPersistence","Starting transaction:",e);const s=new Mf(this.No.next());return this.referenceDelegate.qo(),n(s).next((i=>this.referenceDelegate.Ko(s).next((()=>i)))).toPromise().then((i=>(s.raiseOnCommittedEvent(),i)))}$o(e,t){return _.or(Object.values(this.Mo).map((n=>()=>n.containsKey(e,t))))}}class Mf extends xl{constructor(e){super(),this.currentSequenceNumber=e}}class si{constructor(e){this.persistence=e,this.Wo=new ri,this.Go=null}static jo(e){return new si(e)}get zo(){if(this.Go)return this.Go;throw A(60996)}addReference(e,t,n){return this.Wo.addReference(n,t),this.zo.delete(n.toString()),_.resolve()}removeReference(e,t,n){return this.Wo.removeReference(n,t),this.zo.add(n.toString()),_.resolve()}markPotentiallyOrphaned(e,t){return this.zo.add(t.toString()),_.resolve()}removeTarget(e,t){this.Wo.Ao(t.targetId).forEach((s=>this.zo.add(s.toString())));const n=this.persistence.getTargetCache();return n.getMatchingKeysForTargetId(e,t.targetId).next((s=>{s.forEach((i=>this.zo.add(i.toString())))})).next((()=>n.removeTargetData(e,t)))}qo(){this.Go=new Set}Ko(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return _.forEach(this.zo,(n=>{const s=V.fromPath(n);return this.Ho(e,s).next((i=>{i||t.removeEntry(s,b.min())}))})).next((()=>(this.Go=null,t.apply(e))))}updateLimboDocument(e,t){return this.Ho(e,t).next((n=>{n?this.zo.delete(t.toString()):this.zo.add(t.toString())}))}ko(e){return 0}Ho(e,t){return _.or([()=>_.resolve(this.Wo.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.$o(e,t)])}}class wr{constructor(e,t){this.persistence=e,this.Jo=new Pt((n=>yf(n.path)),((n,s)=>n.isEqual(s))),this.garbageCollector=kl(this,t)}static jo(e,t){return new wr(e,t)}qo(){}Ko(e){return _.resolve()}forEachTarget(e,t){return this.persistence.getTargetCache().forEachTarget(e,t)}Pi(e){const t=this.H_(e);return this.persistence.getTargetCache().getTargetCount(e).next((n=>t.next((s=>n+s))))}H_(e){let t=0;return this.Ii(e,(n=>{t++})).next((()=>t))}Ii(e,t){return _.forEach(this.Jo,((n,s)=>this.Y_(e,n,s).next((i=>i?_.resolve():t(s)))))}removeTargets(e,t,n){return this.persistence.getTargetCache().removeTargets(e,t,n)}removeOrphanedDocuments(e,t){let n=0;const s=this.persistence.getRemoteDocumentCache(),i=s.newChangeBuffer();return s.vo(e,(a=>this.Y_(e,a,t).next((o=>{o||(n++,i.removeEntry(a,b.min()))})))).next((()=>i.apply(e))).next((()=>n))}markPotentiallyOrphaned(e,t){return this.Jo.set(t,e.currentSequenceNumber),_.resolve()}removeTarget(e,t){const n=t.withSequenceNumber(e.currentSequenceNumber);return this.persistence.getTargetCache().updateTargetData(e,n)}addReference(e,t,n){return this.Jo.set(n,e.currentSequenceNumber),_.resolve()}removeReference(e,t,n){return this.Jo.set(n,e.currentSequenceNumber),_.resolve()}updateLimboDocument(e,t){return this.Jo.set(t,e.currentSequenceNumber),_.resolve()}ko(e){let t=e.key.toString().length;return e.isFoundDocument()&&(t+=mr(e.data.value)),t}Y_(e,t,n){return _.or([()=>this.persistence.$o(e,t),()=>this.persistence.getTargetCache().containsKey(e,t),()=>{const s=this.Jo.get(t);return _.resolve(s!==void 0&&s>n)}])}getCacheSize(e){return this.persistence.getRemoteDocumentCache().getSize(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ii{constructor(e,t,n,s){this.targetId=e,this.fromCache=t,this.Ba=n,this.La=s}static Ua(e,t){let n=D(),s=D();for(const i of t.docChanges)switch(i.type){case 0:n=n.add(i.doc.key);break;case 1:s=s.add(i.doc.key)}return new ii(e,t.fromCache,n,s)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Uf(r,e){return V.comparator(r.key,e.key)}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ff{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qf{constructor(){this.ka=!1,this.Qa=!1,this.qa=100,this.Ka=(function(){return Uu()?8:bl(Fu())>0?6:4})()}initialize(e,t){this.$a=e,this.indexManager=t,this.ka=!0}getDocumentsMatchingQuery(e,t,n,s){const i={result:null};return this.Wa(e,t).next((a=>{i.result=a})).next((()=>{if(!i.result)return this.Ga(e,t,s,n).next((a=>{i.result=a}))})).next((()=>{if(i.result)return;const a=new Ff;return this.ja(e,t,a).next((o=>{if(i.result=o,this.Qa)return this.za(e,t,a,o.size)}))})).next((()=>i.result))}za(e,t,n,s){return H(t)?_.resolve():n.documentReadCount<this.qa?(Ct()<=Fe.DEBUG&&w("QueryEngine","SDK will not create cache indexes for query:",hn(t),"since it only creates cache indexes for collection contains","more than or equal to",this.qa,"documents"),_.resolve()):(Ct()<=Fe.DEBUG&&w("QueryEngine","Query:",hn(t),"scans",n.documentReadCount,"local documents and returns",s,"documents as results."),n.documentReadCount>this.Ka*s?(Ct()<=Fe.DEBUG&&w("QueryEngine","The SDK decides to create cache indexes for query:",hn(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,ke(t))):_.resolve())}Wa(e,t){if(H(t))return _.resolve(null);let n=t;if(Yi(n))return _.resolve(null);let s=ke(n);return this.indexManager.getIndexType(e,s).next((i=>i===0?null:(n.limit!==null&&i===1&&(n=yr(n,null,"F"),s=ke(n)),this.indexManager.getDocumentsMatchingTarget(e,s).next((a=>{const o=D(...a);return this.$a.getDocuments(e,o).next((u=>this.indexManager.getMinOffset(e,s).next((c=>{const l=this.Ha(n,u);return this.Ja(n,l,o,c.readTime)?this.Wa(e,yr(n,null,"F")):this.Ya(e,l,n,c)}))))})))))}Ga(e,t,n,s){return(H(t)?(function(a){for(const o of a.stages){if(o instanceof vt||o instanceof fa)return!1;if(o instanceof qr){if(o.condition instanceof Go&&o.condition._expr.name==="exists"&&o.condition._expr.params[0]instanceof Ht&&o.condition._expr.params[0].fieldName===Se)continue;return!1}}return!0})(t):Yi(t))||s.isEqual(b.min())?_.resolve(null):this.$a.getDocuments(e,n).next((i=>{const a=this.Ha(t,i);return this.Ja(t,a,n,s)?_.resolve(null):(Ct()<=Fe.DEBUG&&w("QueryEngine","Re-using previous result from %s to execute query: %s",s.toString(),da(t)),this.Ya(e,a,t,Rc(s,Cn)).next((o=>o)))}))}Ha(e,t){let n,s;return H(e)?(n=new W(Uf),s=i=>jr(e,i)):(n=new W(Ss(e)),s=i=>Sr(e,i)),t.forEach(((i,a)=>{s(a)&&(n=n.add(a))})),n}Ja(e,t,n,s){if(H(e))return(function(o){return o.stages.some((u=>u instanceof vt||u instanceof fa))})(e);if(e.limit===null)return!1;if(n.size!==t.size)return!0;const i=e.limitType==="F"?t.last():t.first();return!!i&&(i.hasPendingWrites||i.version.compareTo(s)>0)}ja(e,t,n){return Ct()<=Fe.DEBUG&&w("QueryEngine","Using full collection scan to execute query:",da(t)),this.$a.getDocumentsMatchingQuery(e,t,st.min(),n)}Ya(e,t,n,s){return this.$a.getDocumentsMatchingQuery(e,n,s).next((i=>(t.forEach((a=>{i=i.insert(a.key,a)})),i)))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ai="LocalStore",Bf=3e8;class $f{constructor(e,t,n,s){this.persistence=e,this.Za=t,this.serializer=s,this.Xa=new q(N),this.eu=new Pt((i=>su(i)),iu),this.tu=new Map,this.nu=e.getRemoteDocumentCache(),this.Uo=e.getTargetCache(),this.Qo=e.getBundleCache(),this.ru(n)}ru(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new bf(this.nu,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.nu.setIndexManager(this.indexManager),this.Za.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",(t=>e.collect(t,this.Xa)))}}function zf(r,e,t,n){return new $f(r,e,t,n)}async function cu(r,e){const t=S(r);return await t.persistence.runTransaction("Handle user change","readonly",(n=>{let s;return t.mutationQueue.getAllMutationBatches(n).next((i=>(s=i,t.ru(e),t.mutationQueue.getAllMutationBatches(n)))).next((i=>{const a=[],o=[];let u=D();for(const c of s){a.push(c.batchId);for(const l of c.mutations)u=u.add(l.key)}for(const c of i){o.push(c.batchId);for(const l of c.mutations)u=u.add(l.key)}return t.localDocuments.getDocuments(n,u).next((c=>({iu:c,removedBatchIds:a,addedBatchIds:o})))}))}))}function jf(r,e){const t=S(r);return t.persistence.runTransaction("Acknowledge batch","readwrite-primary",(n=>{const s=e.batch.keys(),i=t.nu.newChangeBuffer({trackRemovals:!0});return(function(o,u,c,l){const h=c.batch,d=h.keys();let g=_.resolve();return d.forEach((T=>{g=g.next((()=>l.getEntry(u,T))).next((C=>{const P=c.docVersions.get(T);I(P!==null,48541),C.version.compareTo(P)<0&&(h.applyToRemoteDocument(C,c),C.isValidDocument()&&(C.setReadTime(c.commitVersion),l.addEntry(C)))}))})),g.next((()=>o.mutationQueue.removeMutationBatch(u,h)))})(t,n,e,i).next((()=>i.apply(n))).next((()=>t.mutationQueue.performConsistencyCheck(n))).next((()=>t.documentOverlayCache.removeOverlaysForBatchId(n,s,e.batch.batchId))).next((()=>t.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(n,(function(o){let u=D();for(let c=0;c<o.mutationResults.length;++c)o.mutationResults[c].transformResults.length>0&&(u=u.add(o.batch.mutations[c].key));return u})(e)))).next((()=>t.localDocuments.getDocuments(n,s)))}))}function lu(r){const e=S(r);return e.persistence.runTransaction("Get last remote snapshot version","readonly",(t=>e.Uo.getLastRemoteSnapshotVersion(t)))}function Gf(r,e){const t=S(r),n=e.snapshotVersion;let s=t.Xa;return t.persistence.runTransaction("Apply remote event","readwrite-primary",(i=>{const a=t.nu.newChangeBuffer({trackRemovals:!0});s=t.Xa;const o=[];e.targetChanges.forEach(((l,h)=>{const d=s.get(h);if(!d)return;o.push(t.Uo.removeMatchingKeys(i,l.removedDocuments,h).next((()=>t.Uo.addMatchingKeys(i,l.addedDocuments,h))));let g=d.withSequenceNumber(i.currentSequenceNumber);e.targetMismatches.get(h)!==null?g=g.withResumeToken(B.EMPTY_BYTE_STRING,b.min()).withLastLimboFreeSnapshotVersion(b.min()):l.resumeToken.approximateByteSize()>0&&(g=g.withResumeToken(l.resumeToken,n)),s=s.insert(h,g),(function(C,P,O){return C.resumeToken.approximateByteSize()===0||P.snapshotVersion.toMicroseconds()-C.snapshotVersion.toMicroseconds()>=Bf?!0:O.addedDocuments.size+O.modifiedDocuments.size+O.removedDocuments.size>0})(d,g,l)&&o.push(t.Uo.updateTargetData(i,g))}));let u=fe(),c=D();if(e.documentUpdates.forEach((l=>{e.resolvedLimboDocuments.has(l)&&o.push(t.persistence.referenceDelegate.updateLimboDocument(i,l))})),o.push(Kf(i,a,e.documentUpdates).next((l=>{u=l.su,c=l._u}))),!n.isEqual(b.min())){const l=t.Uo.getLastRemoteSnapshotVersion(i).next((h=>t.Uo.setTargetsMetadata(i,i.currentSequenceNumber,n)));o.push(l)}return _.waitFor(o).next((()=>a.apply(i))).next((()=>t.localDocuments.getLocalViewOfDocuments(i,u,c))).next((()=>u))})).then((i=>(t.Xa=s,i)))}function Kf(r,e,t){let n=D(),s=D();return t.forEach((i=>n=n.add(i))),e.getEntries(r,n).next((i=>{let a=fe();return t.forEach(((o,u)=>{const c=i.get(o);u.isFoundDocument()!==c.isFoundDocument()&&(s=s.add(o)),u.isNoDocument()&&u.version.isEqual(b.min())?(e.removeEntry(o,u.readTime),a=a.insert(o,u)):!c.isValidDocument()||u.version.compareTo(c.version)>0||u.version.compareTo(c.version)===0&&c.hasPendingWrites?(e.addEntry(u),a=a.insert(o,u)):w(ai,"Ignoring outdated watch update for ",o,". Current version:",c.version," Watch version:",u.version)})),{su:a,_u:s}}))}function Wf(r,e){const t=S(r);return t.persistence.runTransaction("Get next mutation batch","readonly",(n=>(e===void 0&&(e=As),t.mutationQueue.getNextMutationBatchAfterBatchId(n,e))))}function Qf(r,e){const t=S(r);return t.persistence.runTransaction("Allocate target","readwrite",(n=>{let s;return t.Uo.getTargetData(n,e).next((i=>i?(s=i,_.resolve(s)):t.Uo.allocateTargetId(n).next((a=>(s=new ze(e,a,"TargetPurposeListen",n.currentSequenceNumber),t.Uo.addTargetData(n,s).next((()=>s)))))))})).then((n=>{const s=t.Xa.get(n.targetId);return(s===null||n.snapshotVersion.compareTo(s.snapshotVersion)>0)&&(t.Xa=t.Xa.insert(n.targetId,n),t.eu.set(e,n.targetId)),n}))}async function ms(r,e,t){const n=S(r),s=n.Xa.get(e),i=t?"readwrite":"readwrite-primary";try{t||await n.persistence.runTransaction("Release target",i,(a=>n.persistence.referenceDelegate.removeTarget(a,s)))}catch(a){if(!Qt(a))throw a;w(ai,`Failed to update sequence numbers for target ${e}: ${a}`)}n.Xa=n.Xa.remove(e),n.eu.delete(s.target)}function pa(r,e,t){const n=S(r);let s=b.min(),i=D();return n.persistence.runTransaction("Execute query","readwrite",(a=>(function(u,c,l){const h=S(u),d=h.eu.get(l);return d!==void 0?_.resolve(h.Xa.get(d)):h.Uo.getTargetData(c,l)})(n,a,H(e)?e:ke(e)).next((o=>{if(o)return s=o.lastLimboFreeSnapshotVersion,n.Uo.getMatchingKeysForTargetId(a,o.targetId).next((u=>{i=u}))})).next((()=>n.Za.getDocumentsMatchingQuery(a,e,t?s:b.min(),t?i:D()))).next((o=>(Hf(n,o),{documents:o,ou:i})))))}function Hf(r,e){e.forEach(((t,n)=>{const s=n.key.getCollectionGroup(),i=r.tu.get(s)||b.min();n.readTime.compareTo(i)>0&&r.tu.set(s,n.readTime)}))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yf{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.hu=0,this.Tu=null,this.Pu=!0}Iu(){this.hu===0&&(this.Ru("Unknown"),this.Tu=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,(()=>(this.Tu=null,this.Au("Backend didn't respond within 10 seconds."),this.Ru("Offline"),Promise.resolve()))))}Vu(e){this.state==="Online"?this.Ru("Unknown"):(this.hu++,this.hu>=1&&(this.fu(),this.Au(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.Ru("Offline")))}set(e){this.fu(),this.hu=0,e==="Online"&&(this.Pu=!1),this.Ru(e)}Ru(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}Au(e){const t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.Pu?(Ge(t),this.Pu=!1):w("OnlineStateTracker",t)}fu(){this.Tu!==null&&(this.Tu.cancel(),this.Tu=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ue="RemoteStore";class Xf{constructor(e,t,n,s,i){this.localStore=e,this.datastore=t,this.asyncQueue=n,this.remoteSyncer={},this.du=[],this.mu=new Map,this.pu=new Map,this.gu=new Map,this.yu=new ut(1e3),this.wu=new ut(1001),this.bu=new Set,this.Su=[],this.xu=i,this.xu.tn((a=>{n.enqueueAndForget((async()=>{bt(this)&&(w(Ue,"Restarting streams for network reachability change."),await(async function(u){const c=S(u);c.bu.add(4),await Kn(c),c.vu.set("Unknown"),c.bu.delete(4),await Gr(c)})(this))}))})),this.vu=new Yf(n,s)}}async function Gr(r){if(bt(r))for(const e of r.Su)await e(!0)}async function Kn(r){for(const e of r.Su)await e(!1)}function ps(r,e){return r.pu.get(e)||void 0}function hu(r,e){const t=S(r),n=ps(t,e.targetId);if(n!==void 0&&t.mu.has(n))return;const s=(function(o,u){const c=ps(o,u);c!==void 0&&o.gu.delete(c);const l=(function(d,g){return g%2!=0?d.wu.next():d.yu.next()})(o,u);return o.pu.set(u,l),o.gu.set(l,u),l})(t,e.targetId);w(Ue,"remoteStoreListen mapping SDK target ID to remote",e.targetId,s);const i=new ze(e.target,s,e.purpose,e.sequenceNumber,e.snapshotVersion,e.lastLimboFreeSnapshotVersion,e.resumeToken);t.mu.set(s,i),li(t)?ci(t):Zt(t).ur()&&ui(t,i)}function oi(r,e){const t=S(r),n=Zt(t),s=ps(t,e);w(Ue,"remoteStoreUnlisten removing mapping of SDK target ID to remote",e,s),t.mu.delete(s),t.pu.delete(e),t.gu.delete(s),n.ur()&&fu(t,s),t.mu.size===0&&(n.ur()?n.Er():bt(t)&&t.vu.set("Unknown"))}function ui(r,e){if(r.Du.rt(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(b.min())>0){const t=r.gu.get(e.targetId);if(t===void 0)return void w(Ue,"SDK target ID not found for remote ID: "+e.targetId);const n=r.remoteSyncer.getRemoteKeysForTarget(t).size;e=e.withExpectedCount(n)}Zt(r).yr(e)}function fu(r,e){r.Du.rt(e),Zt(r).wr(e)}function ci(r){r.Du=new jc({getRemoteKeysForTarget:e=>{const t=r.gu.get(e);return t!==void 0?r.remoteSyncer.getRemoteKeysForTarget(t):D()},Mt:e=>r.mu.get(e)||null,xt:()=>r.datastore.serializer.databaseId}),Zt(r).start(),r.vu.Iu()}function li(r){return bt(r)&&!Zt(r).ar()&&r.mu.size>0}function bt(r){return S(r).bu.size===0}function du(r){r.Du=void 0}async function Jf(r){r.vu.set("Online")}async function Zf(r){r.mu.forEach(((e,t)=>{ui(r,e)}))}async function ed(r,e){du(r),li(r)?(r.vu.Vu(e),ci(r)):r.vu.set("Unknown")}async function td(r,e,t){if(r.vu.set("Online"),e instanceof To&&e.state===2&&e.cause)try{await(async function(s,i){const a=i.cause;for(const o of i.targetIds){if(s.mu.has(o)){const u=s.gu.get(o);u!==void 0&&(await s.remoteSyncer.rejectListen(u,a),s.pu.delete(u),s.gu.delete(o)),s.mu.delete(o)}s.Du.removeTarget(o)}})(r,e)}catch(n){w(Ue,"Failed to remove targets %s: %s ",e.targetIds.join(","),n),await Ir(r,n)}else if(e instanceof ir?r.Du.Tt(e):e instanceof Eo?r.Du.dt(e):r.Du.Rt(e),!t.isEqual(b.min()))try{const n=await lu(r.localStore);t.compareTo(n)>=0&&await(function(i,a){const o=i.Du.Dt(a);o.targetChanges.forEach(((c,l)=>{if(c.resumeToken.approximateByteSize()>0){const h=i.mu.get(l);h&&i.mu.set(l,h.withResumeToken(c.resumeToken,a))}})),o.targetMismatches.forEach(((c,l)=>{const h=i.mu.get(c);if(!h)return;i.mu.set(c,h.withResumeToken(B.EMPTY_BYTE_STRING,h.snapshotVersion)),fu(i,c);const d=new ze(h.target,c,l,h.sequenceNumber);ui(i,d)}));const u=(function(l,h){const d=new Map;h.targetChanges.forEach(((T,C)=>{const P=l.gu.get(C);P!==void 0&&d.set(P,T)}));let g=new q(N);return h.targetMismatches.forEach(((T,C)=>{const P=l.gu.get(T);P!==void 0&&(g=g.insert(P,C))})),new zn(h.snapshotVersion,d,g,h.documentUpdates,h.augmentedDocumentUpdates,h.resolvedLimboDocuments)})(i,o);return i.remoteSyncer.applyRemoteEvent(u)})(r,t)}catch(n){w(Ue,"Failed to raise snapshot:",n),await Ir(r,n)}}async function Ir(r,e,t){if(!Qt(e))throw e;r.bu.add(1),await Kn(r),r.vu.set("Offline"),t||(t=()=>lu(r.localStore)),r.asyncQueue.enqueueRetryable((async()=>{w(Ue,"Retrying IndexedDB access"),await t(),r.bu.delete(1),await Gr(r)}))}function mu(r,e){return e().catch((t=>Ir(r,t,e)))}async function Kr(r){const e=S(r),t=ct(e);let n=e.du.length>0?e.du[e.du.length-1].batchId:As;for(;nd(e);)try{const s=await Wf(e.localStore,n);if(s===null){e.du.length===0&&t.Er();break}n=s.batchId,rd(e,s)}catch(s){await Ir(e,s)}pu(e)&&_u(e)}function nd(r){return bt(r)&&r.du.length<10}function rd(r,e){r.du.push(e);const t=ct(r);t.ur()&&t.br&&t.Sr(e.mutations)}function pu(r){return bt(r)&&!ct(r).ar()&&r.du.length>0}function _u(r){ct(r).start()}async function sd(r){ct(r).Cr()}async function id(r){const e=ct(r);for(const t of r.du)e.Sr(t.mutations)}async function ad(r,e,t){const n=r.du.shift(),s=ni.from(n,e,t);await mu(r,(()=>r.remoteSyncer.applySuccessfulWrite(s))),await Kr(r)}async function od(r,e){e&&ct(r).br&&await(async function(n,s){if((function(a){return mo(a)&&a!==p.ABORTED})(s.code)){const i=n.du.shift();ct(n).lr(),await mu(n,(()=>n.remoteSyncer.rejectFailedWrite(i.batchId,s))),await Kr(n)}})(r,e),pu(r)&&_u(r)}async function _a(r,e){const t=S(r);t.asyncQueue.verifyOperationInProgress(),w(Ue,"RemoteStore received new credentials");const n=bt(t);t.bu.add(3),await Kn(t),n&&t.vu.set("Unknown"),await t.remoteSyncer.handleCredentialChange(e),t.bu.delete(3),await Gr(t)}async function ud(r,e){const t=S(r);e?(t.bu.delete(2),await Gr(t)):e||(t.bu.add(2),await Kn(t),t.vu.set("Unknown"))}function Zt(r){return r.Cu||(r.Cu=(function(t,n,s){const i=S(t);return i.Or(),new Tl(n,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,s)})(r.datastore,r.asyncQueue,{pn:Jf.bind(null,r),yn:Zf.bind(null,r),bn:ed.bind(null,r),gr:td.bind(null,r)}),r.Su.push((async e=>{e?(r.Cu.lr(),li(r)?ci(r):r.vu.set("Unknown")):(await r.Cu.stop(),du(r))}))),r.Cu}function ct(r){return r.Fu||(r.Fu=(function(t,n,s){const i=S(t);return i.Or(),new wl(n,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,s)})(r.datastore,r.asyncQueue,{pn:()=>Promise.resolve(),yn:sd.bind(null,r),bn:od.bind(null,r),vr:id.bind(null,r),Dr:ad.bind(null,r)}),r.Su.push((async e=>{e?(r.Fu.lr(),await Kr(r)):(await r.Fu.stop(),r.du.length>0&&(w(Ue,`Stopping write stream with ${r.du.length} pending writes`),r.du=[]))}))),r.Fu}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hi{constructor(e){this.observer=e,this.muted=!1}next(e){this.muted||this.observer.next&&this.Ou(this.observer.next,e)}error(e){this.muted||(this.observer.error?this.Ou(this.observer.error,e):Ge("Uncaught Error in snapshot listener:",e.toString()))}Mu(){this.muted=!0}Ou(e,t){setTimeout((()=>{this.muted||e(t)}),0)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fi{constructor(e,t,n,s,i){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=n,this.op=s,this.removalCallback=i,this.deferred=new Oe,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch((a=>{}))}get promise(){return this.deferred.promise}static createAndSchedule(e,t,n,s,i){const a=Date.now()+n,o=new fi(e,t,a,s,i);return o.start(n),o}start(e){this.timerHandle=setTimeout((()=>this.handleDelayElapsed()),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new y(p.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget((()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then((e=>this.deferred.resolve(e)))):Promise.resolve()))}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}function di(r,e){if(Ge("AsyncQueue",`${e}: ${r}`),Qt(r))return new y(p.UNAVAILABLE,`${e}: ${r}`);throw r}class ga{constructor(){this.activeTargetIds=Bc()}ec(e){this.activeTargetIds=this.activeTargetIds.add(e)}tc(e){this.activeTargetIds=this.activeTargetIds.delete(e)}Xu(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class cd{constructor(){this.Uc=new ga,this.kc={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,n){}addLocalQueryTarget(e,t=!0){return t&&this.Uc.ec(e),this.kc[e]||"not-current"}updateQueryState(e,t,n){this.kc[e]=t}removeLocalQueryTarget(e){this.Uc.tc(e)}isLocalQueryTarget(e){return this.Uc.activeTargetIds.has(e)}clearQueryState(e){delete this.kc[e]}getAllActiveQueryTargets(){return this.Uc.activeTargetIds}isActiveQueryTarget(e){return this.Uc.activeTargetIds.has(e)}start(){return this.Uc=new ga,Promise.resolve()}handleUserChange(e,t,n){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}function Zr(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Et{static emptySet(e){return new Et(e.comparator)}constructor(e){this.comparator=e?(t,n)=>e(t,n)||V.comparator(t.key,n.key):(t,n)=>V.comparator(t.key,n.key),this.keyedMap=Nt(),this.sortedSet=new q(this.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal(((t,n)=>(e(t),!1)))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof Et)||this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),n=e.sortedSet.getIterator();for(;t.hasNext();){const s=t.getNext().key,i=n.getNext().key;if(!s.isEqual(i))return!1}return!0}toString(){const e=[];return this.forEach((t=>{e.push(t.toString())})),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,t){const n=new Et;return n.comparator=this.comparator,n.keyedMap=e,n.sortedSet=t,n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ya{constructor(){this.Qc=new q(V.comparator)}track(e){const t=e.doc.key,n=this.Qc.get(t);n?e.type!==0&&n.type===3?this.Qc=this.Qc.insert(t,e):e.type===3&&n.type!==1?this.Qc=this.Qc.insert(t,{type:n.type,doc:e.doc}):e.type===2&&n.type===2?this.Qc=this.Qc.insert(t,{type:2,doc:e.doc}):e.type===2&&n.type===0?this.Qc=this.Qc.insert(t,{type:0,doc:e.doc}):e.type===1&&n.type===0?this.Qc=this.Qc.remove(t):e.type===1&&n.type===2?this.Qc=this.Qc.insert(t,{type:1,doc:n.doc}):e.type===0&&n.type===1?this.Qc=this.Qc.insert(t,{type:2,doc:e.doc}):A(63341,{Nt:e,qc:n}):this.Qc=this.Qc.insert(t,e)}Kc(){const e=[];return this.Qc.inorderTraversal(((t,n)=>{e.push(n)})),e}}class jt{constructor(e,t,n,s,i,a,o,u,c){this.query=e,this.docs=t,this.oldDocs=n,this.docChanges=s,this.mutatedKeys=i,this.fromCache=a,this.syncStateChanged=o,this.excludesMetadataChanges=u,this.hasCachedResults=c}static fromInitialDocuments(e,t,n,s,i){const a=[];return t.forEach((o=>{a.push({type:0,doc:o})})),new jt(e,t,Et.emptySet(t),a,n,s,!0,!1,i)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&zr(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,n=e.docChanges;if(t.length!==n.length)return!1;for(let s=0;s<t.length;s++)if(t[s].type!==n[s].type||!t[s].doc.isEqual(n[s].doc))return!1;return!0}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ld{constructor(){this.$c=void 0,this.Wc=[]}Gc(){return this.Wc.some((e=>e.jc()))}}class hd{constructor(){this.queries=Ea(),this.onlineState="Unknown",this.zc=new Set}terminate(){(function(t,n){const s=S(t),i=s.queries;s.queries=Ea(),i.forEach(((a,o)=>{for(const u of o.Wc)u.onError(n)}))})(this,new y(p.ABORTED,"Firestore shutting down"))}}function Ea(){return new Pt((r=>ru(r)),zr)}async function mi(r,e){const t=S(r);let n=3;const s=e.query;let i=t.queries.get(s);i?!i.Gc()&&e.jc()&&(n=2):(i=new ld,n=e.jc()?0:1);try{switch(n){case 0:i.$c=await t.onListen(s,!0);break;case 1:i.$c=await t.onListen(s,!1);break;case 2:await t.onFirstRemoteStoreListen(s)}}catch(a){const o=di(a,`Initialization of query '${H(e.query)?je(e.query):hn(e.query)}' failed`);return void e.onError(o)}t.queries.set(s,i),i.Wc.push(e),e.Hc(t.onlineState),i.$c&&e.Jc(i.$c)&&_i(t)}async function pi(r,e){const t=S(r),n=e.query;let s=3;const i=t.queries.get(n);if(i){const a=i.Wc.indexOf(e);a>=0&&(i.Wc.splice(a,1),i.Wc.length===0?s=e.jc()?0:1:!i.Gc()&&e.jc()&&(s=2))}switch(s){case 0:return t.queries.delete(n),t.onUnlisten(n,!0);case 1:return t.queries.delete(n),t.onUnlisten(n,!1);case 2:return t.onLastRemoteStoreUnlisten(n);default:return}}function fd(r,e){const t=S(r);let n=!1;for(const s of e){const i=s.query,a=t.queries.get(i);if(a){for(const o of a.Wc)o.Jc(s)&&(n=!0);a.$c=s}}n&&_i(t)}function dd(r,e,t){const n=S(r),s=n.queries.get(e);if(s)for(const i of s.Wc)i.onError(t);n.queries.delete(e)}function _i(r){r.zc.forEach((e=>{e.next()}))}var _s;(function(r){r.Default="default",r.Cache="cache"})(_s||(_s={}));class gi{constructor(e,t,n){this.query=e,this.Yc=t,this.Zc=!1,this.Xc=null,this.onlineState="Unknown",this.options=n||{}}Jc(e){if(!this.options.includeMetadataChanges){const n=[];for(const s of e.docChanges)s.type!==3&&n.push(s);e=new jt(e.query,e.docs,e.oldDocs,n,e.mutatedKeys,e.fromCache,e.syncStateChanged,!0,e.hasCachedResults)}let t=!1;return this.Zc?this.el(e)&&(this.Yc.next(e),t=!0):this.tl(e,this.onlineState)&&(this.nl(e),t=!0),this.Xc=e,t}onError(e){this.Yc.error(e)}Hc(e){this.onlineState=e;let t=!1;return this.Xc&&!this.Zc&&this.tl(this.Xc,e)&&(this.nl(this.Xc),t=!0),t}tl(e,t){if(!e.fromCache||!this.jc())return!0;const n=t!=="Offline";return(!this.options.waitForSyncWhenOnline||!n)&&(!e.docs.isEmpty()||e.hasCachedResults||t==="Offline")}el(e){if(e.docChanges.length>0)return!0;const t=this.Xc&&this.Xc.hasPendingWrites!==e.hasPendingWrites;return!(!e.syncStateChanged&&!t)&&this.options.includeMetadataChanges===!0}nl(e){e=jt.fromInitialDocuments(e.query,e.docs,e.mutatedKeys,e.fromCache,e.hasCachedResults),this.Zc=!0,this.Yc.next(e)}jc(){return this.options.source!==_s.Cache}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class gu{constructor(e){this.key=e}}class yu{constructor(e){this.key=e}}class md{constructor(e,t){this.query=e,this.ll=t,this.El=null,this.hasCachedResults=!1,this.current=!1,this.hl=D(),this.mutatedKeys=D(),this.Tl=H(e)?ds(e):Ss(e),this.Pl=new Et(this.Tl)}get Il(){return this.ll}Rl(e,t){const n=t?t.Al:new ya,s=t?t.Pl:this.Pl;let i=t?t.mutatedKeys:this.mutatedKeys,a=s,o=!1;const[u,c]=this.Vl(this.query,s);e.inorderTraversal(((h,d)=>{const g=s.get(h),T=vf(this.query,d)?d:null,C=!!g&&this.mutatedKeys.has(g.key),P=!!T&&(T.hasLocalMutations||this.mutatedKeys.has(T.key)&&T.hasCommittedMutations);let O=!1;g&&T?g.data.isEqual(T.data)?C!==P&&(n.track({type:3,doc:T}),O=!0):this.fl(g,T)||(n.track({type:2,doc:T}),O=!0,(u&&this.Tl(T,u)>0||c&&this.Tl(T,c)<0)&&(o=!0)):!g&&T?(n.track({type:0,doc:T}),O=!0):g&&!T&&(n.track({type:1,doc:g}),O=!0,(u||c)&&(o=!0)),O&&(T?(a=a.add(T),i=P?i.add(h):i.delete(h)):(a=a.delete(h),i=i.delete(h)))}));const l=this.dl(this.query);if(l)if(H(this.query)){const h=[];a.forEach((T=>h.push(T)));const d=ou(this.query,h);let g=new Et(ds(this.query));for(const T of d)g=g.add(T);a.forEach((T=>{g.has(T.key)||(i=i.delete(T.key),n.track({type:1,doc:T}))})),a=g}else{const h=this.ml(this.query);for(;a.size>l;){const d=h==="F"?a.last():a.first();a=a.delete(d.key),i=i.delete(d.key),n.track({type:1,doc:d})}}return{Pl:a,Al:n,Ja:o,mutatedKeys:i}}dl(e){return H(e)?Jr(e)?.limit:e.limit||void 0}ml(e){if(H(e)){const t=Jr(e);return t&&t.limit<0?"L":"F"}return e.limitType}Vl(e,t){if(H(e)){const n=Jr(e)?.limit;return[t.size===n?t.last():null,null]}return[e.limitType==="F"&&t.size===this.dl(this.query)?t.last():null,e.limitType==="L"&&t.size===this.dl(this.query)?t.first():null]}fl(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,n,s){const i=this.Pl;this.Pl=e.Pl,this.mutatedKeys=e.mutatedKeys;const a=e.Al.Kc();a.sort(((l,h)=>(function(g,T){const C=P=>{switch(P){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return A(20277,{Nt:P})}};return C(g)-C(T)})(l.type,h.type)||this.Tl(l.doc,h.doc))),this.pl(n),s=s??!1;const o=t&&!s?this.gl():[],u=this.hl.size===0&&this.current&&!s?1:0,c=u!==this.El;return this.El=u,a.length!==0||c?{snapshot:new jt(this.query,e.Pl,i,a,e.mutatedKeys,u===0,c,!1,!!n&&n.resumeToken.approximateByteSize()>0),yl:o}:{yl:o}}Hc(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({Pl:this.Pl,Al:new ya,mutatedKeys:this.mutatedKeys,Ja:!1},!1)):{yl:[]}}wl(e){return!this.ll.has(e)&&!!this.Pl.has(e)&&!this.Pl.get(e).hasLocalMutations}pl(e){e&&(e.addedDocuments.forEach((t=>this.ll=this.ll.add(t))),e.modifiedDocuments.forEach((t=>{})),e.removedDocuments.forEach((t=>this.ll=this.ll.delete(t))),this.current=e.current)}gl(){if(!this.current)return[];const e=this.hl;this.hl=D(),this.Pl.forEach((n=>{this.wl(n.key)&&(this.hl=this.hl.add(n.key))}));const t=[];return e.forEach((n=>{this.hl.has(n)||t.push(new yu(n))})),this.hl.forEach((n=>{e.has(n)||t.push(new gu(n))})),t}bl(e){this.ll=e.ou,this.hl=D();const t=this.Rl(e.documents);return this.applyChanges(t,!0)}Sl(){return jt.fromInitialDocuments(this.query,this.Pl,this.mutatedKeys,this.El===0,this.hasCachedResults)}}const yi="SyncEngine";class pd{constructor(e,t,n){this.query=e,this.targetId=t,this.view=n}}class _d{constructor(e){this.key=e,this.xl=!1}}class gd{constructor(e,t,n,s,i,a){this.localStore=e,this.remoteStore=t,this.eventManager=n,this.sharedClientState=s,this.currentUser=i,this.maxConcurrentLimboResolutions=a,this.vl={},this.Dl=new Pt((o=>ru(o)),zr),this.Cl=new Map,this.Fl=new Set,this.Ol=new q(V.comparator),this.Ml=new Map,this.Nl=new ri,this.Bl={},this.Ll=new Map,this.Ul=ut.K_(),this.onlineState="Unknown",this.kl=void 0}get isPrimaryClient(){return this.kl===!0}}async function yd(r,e,t=!0){const n=Vu(r);let s;const i=n.Dl.get(e);return i?(n.sharedClientState.addLocalQueryTarget(i.targetId),s=i.view.Sl()):s=await Eu(n,e,t,!0),s}async function Ed(r,e){const t=Vu(r);await Eu(t,e,!0,!1)}async function Eu(r,e,t,n){const s=await Qf(r.localStore,H(e)?e:ke(e)),i=s.targetId,a=r.sharedClientState.addLocalQueryTarget(i,t);let o;return n&&(o=await Td(r,e,i,a==="current",s.resumeToken)),r.isPrimaryClient&&t&&hu(r.remoteStore,s),o}async function Td(r,e,t,n,s){r.Ql=(h,d,g)=>(async function(C,P,O,j){let _e=P.view.Rl(O);_e.Ja&&(_e=await pa(C.localStore,P.query,!1).then((({documents:Hn})=>P.view.Rl(Hn,_e))));const mt=j&&j.targetChanges.get(P.targetId),xi=j&&j.targetMismatches.get(P.targetId)!=null,Qn=P.view.applyChanges(_e,C.isPrimaryClient,mt,xi);return wa(C,P.targetId,Qn.yl),Qn.snapshot})(r,h,d,g);const i=await pa(r.localStore,e,!0),a=new md(e,i.ou),o=a.Rl(i.documents),u=jn.createSynthesizedTargetChangeForCurrentChange(t,n&&r.onlineState!=="Offline",s),c=a.applyChanges(o,r.isPrimaryClient,u);wa(r,t,c.yl);const l=new pd(e,t,a);return r.Dl.set(e,l),r.Cl.has(t)?r.Cl.get(t).push(e):r.Cl.set(t,[e]),c.snapshot}async function wd(r,e,t){const n=S(r),s=n.Dl.get(e),i=n.Cl.get(s.targetId);if(i.length>1)return n.Cl.set(s.targetId,i.filter((a=>!zr(a,e)))),void n.Dl.delete(e);n.isPrimaryClient?(n.sharedClientState.removeLocalQueryTarget(s.targetId),n.sharedClientState.isActiveQueryTarget(s.targetId)||await ms(n.localStore,s.targetId,!1).then((()=>{n.sharedClientState.clearQueryState(s.targetId),t&&oi(n.remoteStore,s.targetId),gs(n,s.targetId)})).catch(Wt)):(gs(n,s.targetId),await ms(n.localStore,s.targetId,!0))}async function Id(r,e){const t=S(r),n=t.Dl.get(e),s=t.Cl.get(n.targetId);t.isPrimaryClient&&s.length===1&&(t.sharedClientState.removeLocalQueryTarget(n.targetId),oi(t.remoteStore,n.targetId))}async function Ad(r,e,t){const n=Cd(r);try{const s=await(function(a,o){const u=S(a),c=M.now(),l=o.reduce(((g,T)=>g.add(T.key)),D());let h,d;return u.persistence.runTransaction("Locally write mutations","readwrite",(g=>{let T=fe(),C=D();return u.nu.getEntries(g,l).next((P=>{T=P,T.forEach(((O,j)=>{j.isValidDocument()||(C=C.add(O))}))})).next((()=>u.localDocuments.getOverlayedDocuments(g,T))).next((P=>{h=P;const O=[];for(const j of o){const _e=_c(j,h.get(j.key).overlayedDocument);_e!=null&&O.push(new dt(j.key,_e,Ha(_e.value.mapValue),le.exists(!0)))}return u.mutationQueue.addMutationBatch(g,c,O,o)})).next((P=>{d=P;const O=P.applyToLocalDocumentSet(h,C);return u.documentOverlayCache.saveOverlays(g,P.batchId,O)}))})).then((()=>({batchId:d.batchId,changes:go(h)})))})(n.localStore,e);n.sharedClientState.addPendingMutation(s.batchId),(function(a,o,u){let c=a.Bl[a.currentUser.toKey()];c||(c=new q(N)),c=c.insert(o,u),a.Bl[a.currentUser.toKey()]=c})(n,s.batchId,t),await Wn(n,s.changes),await Kr(n.remoteStore)}catch(s){const i=di(s,"Failed to persist write");t.reject(i)}}async function Tu(r,e){const t=S(r);try{const n=await Gf(t.localStore,e);e.targetChanges.forEach(((s,i)=>{const a=t.Ml.get(i);a&&(I(s.addedDocuments.size+s.modifiedDocuments.size+s.removedDocuments.size<=1,22616),s.addedDocuments.size>0?a.xl=!0:s.modifiedDocuments.size>0?I(a.xl,14607):s.removedDocuments.size>0&&(I(a.xl,42227),a.xl=!1))})),await Wn(t,n,e)}catch(n){await Wt(n)}}function Ta(r,e,t){const n=S(r);if(n.isPrimaryClient&&t===0||!n.isPrimaryClient&&t===1){const s=[];n.Dl.forEach(((i,a)=>{const o=a.view.Hc(e);o.snapshot&&s.push(o.snapshot)})),(function(a,o){const u=S(a);u.onlineState=o;let c=!1;u.queries.forEach(((l,h)=>{for(const d of h.Wc)d.Hc(o)&&(c=!0)})),c&&_i(u)})(n.eventManager,e),s.length&&n.vl.gr(s),n.onlineState=e,n.isPrimaryClient&&n.sharedClientState.setOnlineState(e)}}async function Vd(r,e,t){const n=S(r);n.sharedClientState.updateQueryState(e,"rejected",t);const s=n.Ml.get(e),i=s&&s.key;if(i){let a=new q(V.comparator);a=a.insert(i,J.newNoDocument(i,b.min()));const o=D().add(i),u=new zn(b.min(),new Map,new q(N),a,fe(),o);await Tu(n,u),n.Ol=n.Ol.remove(i),n.Ml.delete(e),Ei(n)}else await ms(n.localStore,e,!1).then((()=>gs(n,e,t))).catch(Wt)}async function vd(r,e){const t=S(r),n=e.batch.batchId;try{const s=await jf(t.localStore,e);Iu(t,n,null),wu(t,n),t.sharedClientState.updateMutationState(n,"acknowledged"),await Wn(t,s)}catch(s){await Wt(s)}}async function Rd(r,e,t){const n=S(r);try{const s=await(function(a,o){const u=S(a);return u.persistence.runTransaction("Reject batch","readwrite-primary",(c=>{let l;return u.mutationQueue.lookupMutationBatch(c,o).next((h=>(I(h!==null,37113),l=h.keys(),u.mutationQueue.removeMutationBatch(c,h)))).next((()=>u.mutationQueue.performConsistencyCheck(c))).next((()=>u.documentOverlayCache.removeOverlaysForBatchId(c,l,o))).next((()=>u.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(c,l))).next((()=>u.localDocuments.getDocuments(c,l)))}))})(n.localStore,e);Iu(n,e,t),wu(n,e),n.sharedClientState.updateMutationState(e,"rejected",t),await Wn(n,s)}catch(s){await Wt(s)}}function wu(r,e){(r.Ll.get(e)||[]).forEach((t=>{t.resolve()})),r.Ll.delete(e)}function Iu(r,e,t){const n=S(r);let s=n.Bl[n.currentUser.toKey()];if(s){const i=s.get(e);i&&(t?i.reject(t):i.resolve(),s=s.remove(e)),n.Bl[n.currentUser.toKey()]=s}}function gs(r,e,t=null){r.sharedClientState.removeLocalQueryTarget(e);for(const n of r.Cl.get(e))r.Dl.delete(n),t&&r.vl.ql(n,t);r.Cl.delete(e),r.isPrimaryClient&&r.Nl.Ao(e).forEach((n=>{r.Nl.containsKey(n)||Au(r,n)}))}function Au(r,e){r.Fl.delete(e.path.canonicalString());const t=r.Ol.get(e);t!==null&&(oi(r.remoteStore,t),r.Ol=r.Ol.remove(e),r.Ml.delete(t),Ei(r))}function wa(r,e,t){for(const n of t)n instanceof gu?(r.Nl.addReference(n.key,e),Pd(r,n)):n instanceof yu?(w(yi,"Document no longer in limbo: "+n.key),r.Nl.removeReference(n.key,e),r.Nl.containsKey(n.key)||Au(r,n.key)):A(19791,{Kl:n})}function Pd(r,e){const t=e.key,n=t.path.canonicalString();r.Ol.get(t)||r.Fl.has(n)||(w(yi,"New document in limbo: "+t),r.Fl.add(n),Ei(r))}function Ei(r){for(;r.Fl.size>0&&r.Ol.size<r.maxConcurrentLimboResolutions;){const e=r.Fl.values().next().value;r.Fl.delete(e);const t=new V(L.fromString(e)),n=r.Ul.next();r.Ml.set(n,new _d(t)),r.Ol=r.Ol.insert(t,n),hu(r.remoteStore,new ze(ke(Cr(t.path)),n,"TargetPurposeLimboResolution",Lr.Br))}}async function Wn(r,e,t){const n=S(r),s=[],i=[],a=[];n.Dl.isEmpty()||(n.Dl.forEach(((o,u)=>{a.push(n.Ql(u,e,t).then((c=>{if((c||t)&&n.isPrimaryClient){const l=c?!c.fromCache:t?.targetChanges.get(u.targetId)?.current;n.sharedClientState.updateQueryState(u.targetId,l?"current":"not-current")}if(c){s.push(c);const l=ii.Ua(u.targetId,c);i.push(l)}})))})),await Promise.all(a),n.vl.gr(s),await(async function(u,c){const l=S(u);try{await l.persistence.runTransaction("notifyLocalViewChanges","readwrite",(h=>_.forEach(c,(d=>_.forEach(d.Ba,(g=>l.persistence.referenceDelegate.addReference(h,d.targetId,g))).next((()=>_.forEach(d.La,(g=>l.persistence.referenceDelegate.removeReference(h,d.targetId,g)))))))))}catch(h){if(!Qt(h))throw h;w(ai,"Failed to update sequence numbers: "+h)}for(const h of c){const d=h.targetId;if(!h.fromCache){const g=l.Xa.get(d),T=g.snapshotVersion,C=g.withLastLimboFreeSnapshotVersion(T);l.Xa=l.Xa.insert(d,C)}}})(n.localStore,i))}async function xd(r,e){const t=S(r);if(!t.currentUser.isEqual(e)){w(yi,"User change. New user:",e.toKey());const n=await cu(t.localStore,e);t.currentUser=e,(function(i,a){i.Ll.forEach((o=>{o.forEach((u=>{u.reject(new y(p.CANCELLED,a))}))})),i.Ll.clear()})(t,"'waitForPendingWrites' promise is rejected due to a user change."),t.sharedClientState.handleUserChange(e,n.removedBatchIds,n.addedBatchIds),await Wn(t,n.iu)}}function bd(r,e){const t=S(r),n=t.Ml.get(e);if(n&&n.xl)return D().add(n.key);{let s=D();const i=t.Cl.get(e);if(!i)return s;for(const a of i??[]){const o=t.Dl.get(a);s=s.unionWith(o.view.Il)}return s}}function Vu(r){const e=S(r);return e.remoteStore.remoteSyncer.applyRemoteEvent=Tu.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=bd.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=Vd.bind(null,e),e.vl.gr=fd.bind(null,e.eventManager),e.vl.ql=dd.bind(null,e.eventManager),e}function Cd(r){const e=S(r);return e.remoteStore.remoteSyncer.applySuccessfulWrite=vd.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=Rd.bind(null,e),e}class Ar{constructor(){this.kind="memory",this.synchronizeTabs=!1}async initialize(e){this.serializer=Nr(e.databaseInfo.databaseId),this.sharedClientState=this.Wl(e),this.persistence=this.Gl(e),await this.persistence.start(),this.localStore=this.jl(e),this.gcScheduler=this.zl(e,this.localStore),this.indexBackfillerScheduler=this.Hl(e,this.localStore)}zl(e,t){return null}Hl(e,t){return null}jl(e){return zf(this.persistence,new qf,e.initialUser,this.serializer)}Gl(e){return new uu(si.jo,this.serializer)}Wl(e){return new cd}async terminate(){this.gcScheduler?.stop(),this.indexBackfillerScheduler?.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}Ar.provider={build:()=>new Ar};class Sd extends Ar{constructor(e){super(),this.cacheSizeBytes=e}zl(e,t){I(this.persistence.referenceDelegate instanceof wr,46915);const n=this.persistence.referenceDelegate.garbageCollector;return new Nl(n,e.asyncQueue,t)}Gl(e){const t=this.cacheSizeBytes!==void 0?ce.withCacheSize(this.cacheSizeBytes):ce.DEFAULT;return new uu((n=>wr.jo(n,t)),this.serializer)}}class ys{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=n=>Ta(this.syncEngine,n,1),this.remoteStore.remoteSyncer.handleCredentialChange=xd.bind(null,this.syncEngine),await ud(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return(function(){return new hd})()}createDatastore(e){const t=Nr(e.databaseInfo.databaseId),n=El(e.databaseInfo);return Vl(e.authCredentials,e.appCheckCredentials,n,t)}createRemoteStore(e){return(function(n,s,i,a,o){return new Xf(n,s,i,a,o)})(this.localStore,this.datastore,e.asyncQueue,(t=>Ta(this.syncEngine,t,0)),(function(){return sa.cn()?new sa:new pl})())}createSyncEngine(e,t){return(function(s,i,a,o,u,c,l){const h=new gd(s,i,a,o,u,c);return l&&(h.kl=!0),h})(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}async terminate(){await(async function(t){const n=S(t);w(Ue,"RemoteStore shutting down."),n.bu.add(5),await Kn(n),n.xu.shutdown(),n.vu.set("Unknown")})(this.remoteStore),this.datastore?.terminate(),this.eventManager?.terminate()}}ys.provider={build:()=>new ys};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Nd=class{constructor(e){this.datastore=e,this.readVersions=new Map,this.mutations=[],this.committed=!1,this.lastTransactionError=null,this.writtenDocs=new Set}async lookup(e){if(this.ensureCommitNotCalled(),this.mutations.length>0)throw this.lastTransactionError=new y(p.INVALID_ARGUMENT,"Firestore transactions require all reads to be executed before all writes."),this.lastTransactionError;const t=await(async function(s,i){const a=S(s),o={documents:i.map((h=>Sn(a.serializer,h)))},u=await a.fn("BatchGetDocuments",a.serializer.databaseId,L.emptyPath(),o,i.length),c=new Map;u.forEach((h=>{const d=Yc(a.serializer,h);c.set(d.key.toString(),d)}));const l=[];return i.forEach((h=>{const d=c.get(h.toString());I(!!d,55234,{key:h}),l.push(d)})),l})(this.datastore,e);return t.forEach((n=>this.recordVersion(n))),t}set(e,t){this.write(t.toMutation(e,this.precondition(e))),this.writtenDocs.add(e.toString())}update(e,t){try{this.write(t.toMutation(e,this.preconditionForUpdate(e)))}catch(n){this.lastTransactionError=n}this.writtenDocs.add(e.toString())}delete(e){this.write(new Cs(e,this.precondition(e))),this.writtenDocs.add(e.toString())}async commit(){if(this.ensureCommitNotCalled(),this.lastTransactionError)throw this.lastTransactionError;const e=this.readVersions;this.mutations.forEach((t=>{e.delete(t.key.toString())})),e.forEach(((t,n)=>{const s=V.fromPath(n);this.mutations.push(new no(s,this.precondition(s)))})),await(async function(n,s){const i=S(n),a={writes:s.map((o=>Vo(i.serializer,o)))};await i.In("Commit",i.serializer.databaseId,L.emptyPath(),a)})(this.datastore,this.mutations),this.committed=!0}recordVersion(e){let t;if(e.isFoundDocument())t=e.version;else{if(!e.isNoDocument())throw A(50498,{Yl:e.constructor.name});t=b.min()}const n=this.readVersions.get(e.key.toString());if(n){if(!t.isEqual(n))throw new y(p.ABORTED,"Document version changed between two reads.")}else this.readVersions.set(e.key.toString(),t)}precondition(e){const t=this.readVersions.get(e.toString());return!this.writtenDocs.has(e.toString())&&t?t.isEqual(b.min())?le.exists(!1):le.updateTime(t):le.none()}preconditionForUpdate(e){const t=this.readVersions.get(e.toString());if(!this.writtenDocs.has(e.toString())&&t){if(t.isEqual(b.min()))throw new y(p.INVALID_ARGUMENT,"Can't update a document that doesn't exist.");return le.updateTime(t)}return le.exists(!0)}write(e){this.ensureCommitNotCalled(),this.mutations.push(e)}ensureCommitNotCalled(){}};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dd{constructor(e,t,n,s,i){this.asyncQueue=e,this.datastore=t,this.options=n,this.updateFunction=s,this.deferred=i,this.Zl=n.maxAttempts,this._r=new Fs(this.asyncQueue,"transaction_retry")}Xl(){this.Zl-=1,this.eE()}eE(){this._r.Yn((async()=>{const e=new Nd(this.datastore),t=this.tE(e);t&&t.then((n=>{this.asyncQueue.enqueueAndForget((()=>e.commit().then((()=>{this.deferred.resolve(n)})).catch((s=>{this.nE(s)}))))})).catch((n=>{this.nE(n)}))}))}tE(e){try{const t=this.updateFunction(e);return!Bn(t)&&t.catch&&t.then?t:(this.deferred.reject(Error("Transaction callback must return a Promise")),null)}catch(t){return this.deferred.reject(t),null}}nE(e){this.Zl>0&&this.rE(e)?(this.Zl-=1,this.asyncQueue.enqueueAndForget((()=>(this.eE(),Promise.resolve())))):this.deferred.reject(e)}rE(e){if(e?.name==="FirebaseError"){const t=e.code;return t==="aborted"||t==="failed-precondition"||t==="already-exists"||!mo(t)}return!1}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lt="FirestoreClient";class kd{constructor(e,t,n,s,i){this.authCredentials=e,this.appCheckCredentials=t,this.asyncQueue=n,this._databaseInfo=s,this.user=ie.UNAUTHENTICATED,this.clientId=ws.newId(),this.authCredentialListener=()=>Promise.resolve(),this.appCheckCredentialListener=()=>Promise.resolve(),this._uninitializedComponentsProvider=i,this.authCredentials.start(n,(async a=>{w(lt,"Received user=",a.uid),await this.authCredentialListener(a),this.user=a})),this.appCheckCredentials.start(n,(a=>(w(lt,"Received new app check token=",a),this.appCheckCredentialListener(a,this.user))))}get configuration(){return{asyncQueue:this.asyncQueue,databaseInfo:this._databaseInfo,clientId:this.clientId,authCredentials:this.authCredentials,appCheckCredentials:this.appCheckCredentials,initialUser:this.user,maxConcurrentLimboResolutions:100}}setCredentialChangeListener(e){this.authCredentialListener=e}setAppCheckTokenChangeListener(e){this.appCheckCredentialListener=e}terminate(){this.asyncQueue.enterRestrictedMode();const e=new Oe;return this.asyncQueue.enqueueAndForgetEvenWhileRestricted((async()=>{try{this._onlineComponents&&await this._onlineComponents.terminate(),this._offlineComponents&&await this._offlineComponents.terminate(),this.authCredentials.shutdown(),this.appCheckCredentials.shutdown(),e.resolve()}catch(t){const n=di(t,"Failed to shutdown persistence");e.reject(n)}})),e.promise}}async function es(r,e){r.asyncQueue.verifyOperationInProgress(),w(lt,"Initializing OfflineComponentProvider");const t=r.configuration;await e.initialize(t);let n=t.initialUser;r.setCredentialChangeListener((async s=>{n.isEqual(s)||(await cu(e.localStore,s),n=s)})),e.persistence.setDatabaseDeletedListener((()=>r.terminate())),r._offlineComponents=e}async function Ia(r,e){r.asyncQueue.verifyOperationInProgress();const t=await Ld(r);w(lt,"Initializing OnlineComponentProvider"),await e.initialize(t,r.configuration),r.setCredentialChangeListener((n=>_a(e.remoteStore,n))),r.setAppCheckTokenChangeListener(((n,s)=>_a(e.remoteStore,s))),r._onlineComponents=e}async function Ld(r){if(!r._offlineComponents)if(r._uninitializedComponentsProvider){w(lt,"Using user provided OfflineComponentProvider");try{await es(r,r._uninitializedComponentsProvider._offline)}catch(e){const t=e;if(!(function(s){return s.name==="FirebaseError"?s.code===p.FAILED_PRECONDITION||s.code===p.UNIMPLEMENTED:!(typeof DOMException<"u"&&s instanceof DOMException)||s.code===22||s.code===20||s.code===11})(t))throw t;xe("Error using user provided cache. Falling back to memory cache: "+t),await es(r,new Ar)}}else w(lt,"Using default OfflineComponentProvider"),await es(r,new Sd(void 0));return r._offlineComponents}async function Ti(r){return r._onlineComponents||(r._uninitializedComponentsProvider?(w(lt,"Using user provided OnlineComponentProvider"),await Ia(r,r._uninitializedComponentsProvider._online)):(w(lt,"Using default OnlineComponentProvider"),await Ia(r,new ys))),r._onlineComponents}function Od(r){return Ti(r).then((e=>e.syncEngine))}function Md(r){return Ti(r).then((e=>e.datastore))}async function Vr(r){const e=await Ti(r),t=e.eventManager;return t.onListen=yd.bind(null,e.syncEngine),t.onUnlisten=wd.bind(null,e.syncEngine),t.onFirstRemoteStoreListen=Ed.bind(null,e.syncEngine),t.onLastRemoteStoreUnlisten=Id.bind(null,e.syncEngine),t}function Ud(r,e,t,n){const s=new hi(n),i=new gi(e,s,t);return r.asyncQueue.enqueueAndForget((async()=>mi(await Vr(r),i))),()=>{s.Mu(),r.asyncQueue.enqueueAndForget((async()=>pi(await Vr(r),i)))}}function vu(r,e,t={}){const n=new Oe;return r.asyncQueue.enqueueAndForget((async()=>(function(i,a,o,u,c){const l=new hi({next:d=>{l.Mu(),a.enqueueAndForget((()=>pi(i,h)));const g=d.docs.has(o);!g&&d.fromCache?c.reject(new y(p.UNAVAILABLE,"Failed to get document because the client is offline.")):g&&d.fromCache&&u&&u.source==="server"?c.reject(new y(p.UNAVAILABLE,'Failed to get document from server. (However, this document does exist in the local cache. Run again without setting source to "server" to retrieve the cached document.)')):c.resolve(d)},error:d=>c.reject(d)}),h=new gi(Cr(o.path),l,{includeMetadataChanges:!0,waitForSyncWhenOnline:!0});return mi(i,h)})(await Vr(r),r.asyncQueue,e,t,n))),n.promise}function Fd(r,e,t={}){const n=new Oe;return r.asyncQueue.enqueueAndForget((async()=>(function(i,a,o,u,c){const l=new hi({next:d=>{l.Mu(),a.enqueueAndForget((()=>pi(i,h))),d.fromCache&&u.source==="server"?c.reject(new y(p.UNAVAILABLE,'Failed to get documents from server. (However, these documents may exist in the local cache. Run again without setting source to "server" to retrieve the cached documents.)')):c.resolve(d)},error:d=>c.reject(d)}),h=new gi(o instanceof pn?_f(o):o,l,{includeMetadataChanges:!0,waitForSyncWhenOnline:!0});return mi(i,h)})(await Vr(r),r.asyncQueue,e,t,n))),n.promise}function qd(r,e){const t=new Oe;return r.asyncQueue.enqueueAndForget((async()=>Ad(await Od(r),e,t))),t.promise}function Bd(r,e,t){const n=new Oe;return r.asyncQueue.enqueueAndForget((async()=>{const s=await Md(r);new Dd(r.asyncQueue,s,t,e,n).Xl()})),n.promise}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let vr=class{constructor(e,t,n,s,i){this._firestore=e,this._userDataWriter=t,this._key=n,this._document=s,this._converter=i}get id(){return this._key.path.lastSegment()}get ref(){return new F(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new $d(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}_fieldsProto(){return this._document?.data.clone().value.mapValue.fields??void 0}get(e){if(this._document){const t=this._document.data.field(Vt("DocumentSnapshot.get",e));if(t!==null)return this._userDataWriter.convertValue(t)}}},$d=class extends vr{data(){return super.data()}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ru{convertValue(e,t="none"){switch(Q(e)){case 0:return null;case 2:return e.booleanValue;case 3:if("mapValue"in e){if(rt(e))return this.convertToInt32Value(e.mapValue);if(Re(e))return this.convertToDecimal128Value(e.mapValue)}return $(e.integerValue||e.doubleValue);case 4:return this.convertTimestamp(e.timestampValue);case 6:return this.convertServerTimestamp(e,t);case 7:return e.stringValue;case 8:return"bytesValue"in e?this.convertBytes(At(e.bytesValue)):this.convertToBytesWithSubtype(e.mapValue);case 9:return this.convertReference(e.referenceValue);case 11:return this.convertGeoPoint(e.geoPointValue);case 13:return this.convertArray(e.arrayValue,t);case 15:return this.convertObject(e.mapValue,t);case 14:return this.convertVectorValue(e.mapValue);case 12:return this.convertToRegexValue(e.mapValue);case 10:return this.convertToBsonObjectId(e.mapValue);case 5:return this.convertToBsonTimestamp(e.mapValue);case 16:return qe.instance();case 1:return Be.instance();default:throw A(62114,{value:e})}}convertObject(e,t){return this.convertObjectMap(e.fields,t)}convertObjectMap(e,t="none"){const n={};return ft(e,((s,i)=>{n[s]=this.convertValue(i,t)})),n}convertVectorValue(e){const t=e.fields?.[Tn].arrayValue?.values?.map((n=>$(n.doubleValue)));return new de(t)}convertToBsonObjectId(e){const t=e.fields?.[wn]?.stringValue??"";return new Ls(t)}convertToBytesWithSubtype(e){const t=e.fields?.[Pr],n=t?.bytesValue;if(!n)throw new Error("Received incorrect bytesValue for Bytes with subtype");const s=At(n).toUint8Array();if(s.length===0)throw new Error("Received empty bytesValue for Bytes with subtype");const i=s[0],a=s.slice(1);return new he(B.fromUint8Array(a),i)}convertToBsonTimestamp(e){const t=e.fields?.[_t],n=Number(t?.mapValue?.fields?.[fr]?.integerValue),s=Number(t?.mapValue?.fields?.[dr]?.integerValue);return new Os(n,s)}convertToRegexValue(e){const t=e.fields?.[Ye]?.mapValue?.fields?.[lr]?.stringValue??"",n=e.fields?.[Ye]?.mapValue?.fields?.[hr]?.stringValue??"";return new qs(t,n)}convertToInt32Value(e){const t=Number(e.fields?.[Rt]?.integerValue);return new Us(t)}convertToDecimal128Value(e){const t=e.fields?.[nt]?.stringValue??"";return new Ms(t)}convertGeoPoint(e){return new Le($(e.latitude),$(e.longitude))}convertArray(e,t){return(e.values||[]).map((n=>this.convertValue(n,t)))}convertServerTimestamp(e,t){switch(t){case"previous":const n=qn(e);return n==null?null:this.convertValue(n,t);case"estimate":return this.convertTimestamp(qt(e));default:return null}}convertTimestamp(e){const t=tt(e);return new M(t.seconds,t.nanos)}convertDocumentKey(e,t){const n=L.fromString(e);I(Po(n),9688,{name:e});const s=new yn(n.get(1),n.get(3)),i=new V(n.popFirst(5));return s.isEqual(t)||Ge(`A document reference to ${i} refers to a different database (${s.projectId}/${s.database}), which is not supported. It will be treated as a reference in the current database (${t.projectId}/${t.database}) instead.`),i}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Pu(r,e,t){let n;return n=r?t&&(t.merge||t.mergeFields)?r.toFirestore(e,t):r.toFirestore(e):e,n}class zd extends Ru{constructor(e){super(),this.firestore=e}convertBytes(e){return new he(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new F(this.firestore,null,t)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Aa="AsyncQueue";class Va{constructor(e=Promise.resolve()){this.iE=[],this.sE=!1,this._E=[],this.oE=null,this.aE=!1,this.uE=!1,this.cE=[],this._r=new Fs(this,"async_queue_retry"),this.lE=()=>{const n=Zr();n&&w(Aa,"Visibility state changed to "+n.visibilityState),this._r.Xn()},this.EE=e;const t=Zr();t&&typeof t.addEventListener=="function"&&t.addEventListener("visibilitychange",this.lE)}get isShuttingDown(){return this.sE}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.hE(),this.TE(e)}enterRestrictedMode(e){if(!this.sE){this.sE=!0,this.uE=e||!1;const t=Zr();t&&typeof t.removeEventListener=="function"&&t.removeEventListener("visibilitychange",this.lE)}}enqueue(e){if(this.hE(),this.sE)return new Promise((()=>{}));const t=new Oe;return this.TE((()=>this.sE&&this.uE?Promise.resolve():(e().then(t.resolve,t.reject),t.promise))).then((()=>t.promise))}enqueueRetryable(e){this.enqueueAndForget((()=>(this.iE.push(e),this.PE())))}async PE(){if(this.iE.length!==0){try{await this.iE[0](),this.iE.shift(),this._r.reset()}catch(e){if(!Qt(e))throw e;w(Aa,"Operation failed with retryable error: "+e)}this.iE.length>0&&this._r.Yn((()=>this.PE()))}}TE(e){const t=this.EE.then((()=>(this.aE=!0,e().catch((n=>{throw this.oE=n,this.aE=!1,Ge("INTERNAL UNHANDLED ERROR: ",va(n)),n})).then((n=>(this.aE=!1,n))))));return this.EE=t,t}enqueueAfterDelay(e,t,n){this.hE(),this.cE.indexOf(e)>-1&&(t=0);const s=fi.createAndSchedule(this,e,t,n,(i=>this.IE(i)));return this._E.push(s),s}hE(){this.oE&&A(47125,{RE:va(this.oE)})}verifyOperationInProgress(){}async AE(){let e;do e=this.EE,await e;while(e!==this.EE)}VE(e){for(const t of this._E)if(t.timerId===e)return!0;return!1}fE(e){return this.AE().then((()=>{this._E.sort(((t,n)=>t.targetTimeMs-n.targetTimeMs));for(const t of this._E)if(t.skipDelay(),e!=="all"&&t.timerId===e)break;return this.AE()}))}dE(e){this.cE.push(e)}IE(e){const t=this._E.indexOf(e);this._E.splice(t,1)}}function va(r){let e=r.message||"";return r.stack&&(e=r.stack.includes(r.message)?r.stack:r.message+`
`+r.stack),e}class ht extends Or{constructor(e,t,n,s){super(e,t,n,s),this.type="firestore",this._queue=new Va,this._persistenceKey=s?.name||"[DEFAULT]"}async _terminate(){if(this._firestoreClient){const e=this._firestoreClient.terminate();this._queue=new Va(e),this._firestoreClient=void 0,await e}}}function am(r,e){const t=typeof r=="object"?r:Cu(),n=typeof r=="string"?r:cr,s=Su(t,"firestore").getImmediate({identifier:n});if(!s._initialized){const i=Nu("firestore");i&&Ll(s,...i)}return s}function en(r){if(r._terminated)throw new y(p.FAILED_PRECONDITION,"The client has already been terminated.");return r._firestoreClient||jd(r),r._firestoreClient}function jd(r){const e=r._freezeSettings(),t=Rl(r._databaseId,r._app?.options.appId||"",r._persistenceKey,r._app?.options.apiKey,e);r._componentsProvider||e.localCache?._offlineComponentProvider&&e.localCache?._onlineComponentProvider&&(r._componentsProvider={_offline:e.localCache._offlineComponentProvider,_online:e.localCache._onlineComponentProvider}),r._firestoreClient=new kd(r._authCredentials,r._appCheckCredentials,r._queue,t,r._componentsProvider&&(function(s){const i=s?._online.build();return{_offline:s?._offline.build(i),_online:i}})(r._componentsProvider))}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Wr extends Ru{constructor(e){super(),this.firestore=e}convertBytes(e){return new he(e)}convertReference(e){const t=this.convertDocumentKey(e,this.firestore._databaseId);return new F(this.firestore,null,t)}}class Ot{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class et extends vr{constructor(e,t,n,s,i,a){super(e,t,n,s,a),this._firestore=e,this._firestoreImpl=e,this.metadata=i}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new ur(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const n=this._document.data.field(Vt("DocumentSnapshot.get",e));if(n!==null)return this._userDataWriter.convertValue(n,t.serverTimestamps)}}toJSON(){if(this.metadata.hasPendingWrites)throw new y(p.FAILED_PRECONDITION,"DocumentSnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e=this._document,t={};return t.type=et._jsonSchemaVersion,t.bundle="",t.bundleSource="DocumentSnapshot",t.bundleName=this._key.toString(),!e||!e.isValidDocument()||!e.isFoundDocument()?t:(this._userDataWriter.convertObjectMap(e.data.value.mapValue.fields,"previous"),t.bundle=(this._firestore,this.ref.path,"NOT SUPPORTED"),t)}}et._jsonSchemaVersion="firestore/documentSnapshot/1.0",et._jsonSchema={type:z("string",et._jsonSchemaVersion),bundleSource:z("string","DocumentSnapshot"),bundleName:z("string"),bundle:z("string")};class ur extends et{data(e={}){return super.data(e)}}class Tt{constructor(e,t,n,s){this._firestore=e,this._userDataWriter=t,this._snapshot=s,this.metadata=new Ot(s.hasPendingWrites,s.fromCache),this.query=n}get docs(){const e=[];return this.forEach((t=>e.push(t))),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,t){this._snapshot.docs.forEach((n=>{e.call(t,new ur(this._firestore,this._userDataWriter,n.key,n,new Ot(this._snapshot.mutatedKeys.has(n.key),this._snapshot.fromCache),this.query.converter))}))}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new y(p.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=(function(s,i){if(s._snapshot.oldDocs.isEmpty()){let a=0;return s._snapshot.docChanges.map((o=>{H(s._snapshot.query)?ds(s._snapshot.query):Ss(s.query._query);const u=new ur(s._firestore,s._userDataWriter,o.doc.key,o.doc,new Ot(s._snapshot.mutatedKeys.has(o.doc.key),s._snapshot.fromCache),s.query.converter);return o.doc,{type:"added",doc:u,oldIndex:-1,newIndex:a++}}))}{let a=s._snapshot.oldDocs;return s._snapshot.docChanges.filter((o=>i||o.type!==3)).map((o=>{const u=new ur(s._firestore,s._userDataWriter,o.doc.key,o.doc,new Ot(s._snapshot.mutatedKeys.has(o.doc.key),s._snapshot.fromCache),s.query.converter);let c=-1,l=-1;return o.type!==0&&(c=a.indexOf(o.doc.key),a=a.delete(o.doc.key)),o.type!==1&&(a=a.add(o.doc),l=a.indexOf(o.doc.key)),{type:Gd(o.type),doc:u,oldIndex:c,newIndex:l}}))}})(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}toJSON(){if(this.metadata.hasPendingWrites)throw new y(p.FAILED_PRECONDITION,"QuerySnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e={};e.type=Tt._jsonSchemaVersion,e.bundleSource="QuerySnapshot",e.bundleName=ws.newId(),this._firestore._databaseId.database,this._firestore._databaseId.projectId;const t=[],n=[],s=[];return this.docs.forEach((i=>{i._document!==null&&(t.push(i._document),n.push(this._userDataWriter.convertObjectMap(i._document.data.value.mapValue.fields,"previous")),s.push(i.ref.path))})),e.bundle=(this._firestore,this.query._query,e.bundleName,"NOT SUPPORTED"),e}}function Gd(r){switch(r){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return A(61501,{type:r})}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */Tt._jsonSchemaVersion="firestore/querySnapshot/1.0",Tt._jsonSchema={type:z("string",Tt._jsonSchemaVersion),bundleSource:z("string","QuerySnapshot"),bundleName:z("string"),bundle:z("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xu(r){if(r.limitType==="L"&&r.explicitOrderBy.length===0)throw new y(p.UNIMPLEMENTED,"limitToLast() queries require specifying at least one orderBy() clause")}class wi{}class Ii extends wi{}function om(r,e,...t){let n=[];e instanceof wi&&n.push(e),n=n.concat(t),(function(i){const a=i.filter((u=>u instanceof Vi)).length,o=i.filter((u=>u instanceof Ai)).length;if(a>1||a>0&&o>0)throw new y(p.INVALID_ARGUMENT,"InvalidQuery. When using composite filters, you cannot use more than one filter at the top level. Consider nesting the multiple filters within an `and(...)` statement. For example: change `query(query, where(...), or(...))` to `query(query, and(where(...), or(...)))`.")})(n);for(const s of n)r=s._apply(r);return r}class Ai extends Ii{constructor(e,t,n){super(),this._field=e,this._op=t,this._value=n,this.type="where"}static _create(e,t,n){return new Ai(e,t,n)}_apply(e){const t=this._parse(e);return bu(e._query,t),new Qe(e.firestore,e.converter,as(e._query,t))}_parse(e){const t=$s(e.firestore);return(function(i,a,o,u,c,l,h){let d;if((function(C,P){if(typeof C=="number"&&isNaN(C)&&P!=="=="&&P!=="!="&&P!=="array-contains")throw new Error("Invalid query. You can only perform '==' and '!=' comparisons on NaN.");if(C===null&&P!=="=="&&P!=="!="&&P!=="array-contains")throw new Error("Invalid query. You can only perform '==' and '!=' comparisons on Null.")})(h,l),c.isKeyField()){if(l==="array-contains"||l==="array-contains-any")throw new y(p.INVALID_ARGUMENT,`Invalid Query. You can't perform '${l}' queries on documentId().`);if(l==="in"||l==="not-in"){Pa(h,l);const T=[];for(const C of h)T.push(Ra(u,i,C));d={arrayValue:{values:T}}}else d=Ra(u,i,h)}else l!=="in"&&l!=="not-in"&&l!=="array-contains-any"||Pa(h,l),d=Bl(o,a,h,l==="in"||l==="not-in");return K.create(c,l,d)})(e._query,"where",t,e.firestore._databaseId,this._field,this._op,this._value)}}class Vi extends wi{constructor(e,t){super(),this.type=e,this._queryConstraints=t}static _create(e,t){return new Vi(e,t)}_parse(e){const t=this._queryConstraints.map((n=>n._parse(e))).filter((n=>n.getFilters().length>0));return t.length===1?t[0]:be.create(t,this._getOperator())}_apply(e){const t=this._parse(e);return t.getFilters().length===0?e:((function(s,i){let a=s;const o=i.getFlattenedFilters();for(const u of o)bu(a,u),a=as(a,u)})(e._query,t),new Qe(e.firestore,e.converter,as(e._query,t)))}_getQueryConstraints(){return this._queryConstraints}_getOperator(){return this.type==="and"?"and":"or"}}class vi extends Ii{constructor(e,t){super(),this._field=e,this._direction=t,this.type="orderBy"}static _create(e,t){return new vi(e,t)}_apply(e){const t=(function(s,i,a){if(s.startAt!==null)throw new y(p.INVALID_ARGUMENT,"Invalid query. You must not call startAt() or startAfter() before calling orderBy().");if(s.endAt!==null)throw new y(p.INVALID_ARGUMENT,"Invalid query. You must not call endAt() or endBefore() before calling orderBy().");return new bn(i,a)})(e._query,this._field,this._direction);return new Qe(e.firestore,e.converter,Dc(e._query,t))}}function um(r,e="asc"){const t=e,n=Vt("orderBy",r);return vi._create(n,t)}class Ri extends Ii{constructor(e,t,n){super(),this.type=e,this._limit=t,this._limitType=n}static _create(e,t,n){return new Ri(e,t,n)}_apply(e){return new Qe(e.firestore,e.converter,yr(e._query,this._limit,this._limitType))}}function cm(r){return Ri._create("limit",r,"F")}function Ra(r,e,t){if(typeof(t=Pe(t))=="string"){if(t==="")throw new y(p.INVALID_ARGUMENT,"Invalid query. When querying with documentId(), you must provide a valid document ID, but it was an empty string.");if(!fo(e)&&t.indexOf("/")!==-1)throw new y(p.INVALID_ARGUMENT,`Invalid query. When querying a collection by documentId(), you must provide a plain document ID, but '${t}' contains a '/' character.`);const n=e.path.child(L.fromString(t));if(!V.isDocumentKey(n))throw new y(p.INVALID_ARGUMENT,`Invalid query. When querying a collection group by documentId(), the value provided must result in a valid document path, but '${n}' is not because it has an odd number of segments (${n.length}).`);return $i(r,new V(n))}if(t instanceof F)return $i(r,t._key);throw new y(p.INVALID_ARGUMENT,`Invalid query. When querying with documentId(), you must provide a valid string or a DocumentReference, but it was: ${Rr(t)}.`)}function Pa(r,e){if(!Array.isArray(r)||r.length===0)throw new y(p.INVALID_ARGUMENT,`Invalid Query. A non-empty array is required for '${e.toString()}' filters.`)}function bu(r,e){const t=(function(s,i){for(const a of s)for(const o of a.getFlattenedFilters())if(i.indexOf(o.op)>=0)return o.op;return null})(r.filters,(function(s){switch(s){case"!=":return["!=","not-in"];case"array-contains-any":case"in":return["not-in"];case"not-in":return["array-contains-any","in","not-in","!="];default:return[]}})(e.op));if(t!==null)throw t===e.op?new y(p.INVALID_ARGUMENT,`Invalid query. You cannot use more than one '${e.op.toString()}' filter.`):new y(p.INVALID_ARGUMENT,`Invalid query. You cannot use '${e.op.toString()}' filters with '${t.toString()}' filters.`)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xa(r){return(function(t,n){if(typeof t!="object"||t===null)return!1;const s=t;for(const i of n)if(i in s&&typeof s[i]=="function")return!0;return!1})(r,["next","error","complete"])}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Kd={maxAttempts:5};function on(r,e){if((r=Pe(r)).firestore!==e)throw new y(p.INVALID_ARGUMENT,"Provided document reference is from a different Firestore instance.");return r}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Wd=class{constructor(e,t){this._firestore=e,this._transaction=t,this._dataReader=$s(e)}get(e){const t=on(e,this._firestore),n=new zd(this._firestore);return this._transaction.lookup([t._key]).then((s=>{if(!s||s.length!==1)return A(24041);const i=s[0];if(i.isFoundDocument())return new vr(this._firestore,n,i.key,i,t.converter);if(i.isNoDocument())return new vr(this._firestore,n,t._key,null,t.converter);throw A(18433,{doc:i})}))}set(e,t,n){const s=on(e,this._firestore),i=Pu(s.converter,t,n),a=Mo(this._dataReader,"Transaction.set",s._key,i,s.converter!==null,n);return this._transaction.set(s._key,a),this}update(e,t,n,...s){const i=on(e,this._firestore);let a;return a=typeof(t=Pe(t))=="string"||t instanceof Dr?ql(this._dataReader,"Transaction.update",i._key,t,n,s):Fl(this._dataReader,"Transaction.update",i._key,t),this._transaction.update(i._key,a),this}delete(e){const t=on(e,this._firestore);return this._transaction.delete(t._key),this}};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Qd extends Wd{constructor(e,t){super(e,t),this._firestore=e}get(e){const t=on(e,this._firestore),n=new Wr(this._firestore);return super.get(e).then((s=>new et(this._firestore,n,t._key,s._document,new Ot(!1,!1),t.converter)))}}function hm(r,e,t){r=we(r,ht);const n={...Kd,...t};(function(a){if(a.maxAttempts<1)throw new y(p.INVALID_ARGUMENT,"Max attempts must be at least 1")})(n);const s=en(r);return Bd(s,(i=>e(new Qd(r,i))),n)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function fm(r){r=we(r,F);const e=we(r.firestore,ht),t=en(e);return vu(t,r._key).then((n=>Pi(e,r,n)))}function dm(r){r=we(r,F);const e=we(r.firestore,ht),t=en(e);return vu(t,r._key,{source:"server"}).then((n=>Pi(e,r,n)))}function mm(r){r=we(r,Qe);const e=we(r.firestore,ht),t=en(e),n=new Wr(e);return xu(r._query),Fd(t,r._query).then((s=>new Tt(e,n,r,s)))}function pm(r,e,t){r=we(r,F);const n=we(r.firestore,ht),s=Pu(r.converter,e,t),i=$s(n);return Hd(n,[Mo(i,"setDoc",r._key,s,r.converter!==null,t).toMutation(r._key,le.none())])}function _m(r,...e){r=Pe(r);let t={includeMetadataChanges:!1,source:"default"},n=0;typeof e[n]!="object"||xa(e[n])||(t=e[n++]);const s={includeMetadataChanges:t.includeMetadataChanges,source:t.source};if(xa(e[n])){const c=e[n];e[n]=c.next?.bind(c),e[n+1]=c.error?.bind(c),e[n+2]=c.complete?.bind(c)}let i,a,o;if(r instanceof F)a=we(r.firestore,ht),o=Cr(r._key.path),i={next:c=>{e[n]&&e[n](Pi(a,r,c))},error:e[n+1],complete:e[n+2]};else{const c=we(r,Qe);a=we(c.firestore,ht),o=c._query;const l=new Wr(a);i={next:h=>{e[n]&&e[n](new Tt(a,l,c,h))},error:e[n+1],complete:e[n+2]},xu(r._query)}const u=en(a);return Ud(u,o,s,i)}function Hd(r,e){const t=en(r);return qd(t,e)}function Pi(r,e,t){const n=t.docs.get(e._key),s=new Wr(r);return new et(r,s,e._key,n,new Ot(t.hasPendingWrites,t.fromCache),e.converter)}const ba="@firebase/firestore",Ca="4.18.0";(function(e,t=!0){Yu(Hu),Wu(new Qu("firestore",((n,{instanceIdentifier:s,options:i})=>{const a=n.getProvider("app").getImmediate(),o=new ht(new hl(n.getProvider("auth-internal")),new ml(a,n.getProvider("app-check-internal")),ic(a,s),a);return i={useFetchStreams:t,...i},o._setSettings(i),o}),"PUBLIC").setMultipleInstances(!0)),Ci(ba,Ca,e),Ci(ba,Ca,"esm2020")})();export{he as B,mm as a,nm as b,em as c,tm as d,_m as e,am as f,fm as g,Ll as h,dm as i,cm as l,um as o,om as q,hm as r,pm as s};

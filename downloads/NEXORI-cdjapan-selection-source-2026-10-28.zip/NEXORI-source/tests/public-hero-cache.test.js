import test from 'node:test';
import assert from 'node:assert/strict';
import { createPublicHeroCache } from '../src/public-hero-cache.js';
const config={projectId:'demo-hero',appId:'demo-app'};
const ref='spark:published/11111111-1111-1111-1111-111111111111/22222222-2222-2222-2222-222222222222';
const bytes=new Uint8Array([...new TextEncoder().encode('RIFF0000WEBP'),1,2,3]);
const images=new Map([[ref,{mime:'image/webp',bytes}]]);
const payload={version:1,changes:{blocks:{hero:{image:ref,lead:'Published title',imageAlt:'Complete artwork'}}}};
function storage(){const data=new Map();globalThis.localStorage={getItem:k=>data.get(k)??null,setItem:(k,v)=>data.set(k,v),removeItem:k=>data.delete(k)};return data;}
test('a published hero survives reload with original bytes and a separate project namespace',()=>{
 storage();const cache=createPublicHeroCache(config);assert(cache.remember(payload,images));
 const read=createPublicHeroCache(config).read();assert.equal(read.changes.blocks.hero.lead,'Published title');
 assert.deepEqual(new Uint8Array(Buffer.from(read.changes.blocks.hero.image.split(',')[1],'base64')),bytes);
 assert.equal(createPublicHeroCache({...config,projectId:'demo-other'}).read(),null);
});
test('draft references, private notes and unverified bytes never replace the public hero',()=>{
 storage();const cache=createPublicHeroCache(config);assert(cache.remember(payload,images));
 assert.equal(cache.remember({version:1,changes:{blocks:{hero:{image:ref.replace('published','drafts/owner')}}}},images),false);
 assert.equal(cache.remember({...payload,changes:{...payload.changes,products:{anything:{editorNotes:'PRIVATE'}}}},images),false);
 assert.equal(cache.remember(payload,new Map([[ref,{mime:'image/webp',bytes:new Uint8Array(20)}]])),false);
 assert.equal(cache.read().changes.blocks.hero.lead,'Published title');
});
test('a published reset removes the startup hero',()=>{
 storage();const cache=createPublicHeroCache(config);cache.remember(payload,images);
 assert(cache.remember({version:1,changes:{}},images));assert.equal(cache.read(),null);
});
test('corrupt cache and extra fields are ignored',()=>{
 const data=storage(),cache=createPublicHeroCache(config);cache.remember(payload,images);const key=[...data.keys()][0];
 const value=JSON.parse(data.get(key));value.changes.blocks.hero.editorNotes='PRIVATE';data.set(key,JSON.stringify(value));assert.equal(cache.read(),null);
 data.set(key,'{broken');assert.equal(cache.read(),null);
 data.set(key,'x'.repeat(300001));assert.equal(cache.read(),null);
});
test('blocked browser storage is optional',()=>{
 globalThis.localStorage={getItem(){throw new Error('blocked')},setItem(){throw new Error('quota')},removeItem(){throw new Error('blocked')}};
 const cache=createPublicHeroCache(config);assert.equal(cache.read(),null);assert.equal(cache.remember(payload,images),false);
});

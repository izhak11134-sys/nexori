// Local UI only. Firebase configuration is replaced with null before app startup.
const assert=require('node:assert/strict');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const base=process.env.SITE_URL||'http://127.0.0.1:5199';
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const errors=[];
 async function configure(context){
  await context.route(/^https?:/,route=>['localhost','127.0.0.1'].includes(new URL(route.request().url()).hostname)?route.continue():route.abort());
  await context.route('**/src/firebase-config.js*',route=>route.fulfill({contentType:'application/javascript',body:'export function firebaseConfiguration(){return null;}'}));
 }
 async function custom(page){
  await page.evaluate(async()=>{
   const {applyContentDraft}=await import('/src/content.js');
   const canvas=document.createElement('canvas');canvas.width=700;canvas.height=393;
   const ctx=canvas.getContext('2d'),g=ctx.createLinearGradient(0,0,700,393);g.addColorStop(0,'#15245d');g.addColorStop(1,'#af64da');ctx.fillStyle=g;ctx.fillRect(0,0,700,393);
   ctx.strokeStyle='#f2dbff';ctx.lineWidth=2;for(let x=35;x<700;x+=50){ctx.beginPath();ctx.moveTo(x,25);ctx.lineTo(x,365);ctx.stroke();}
   ctx.font='bold 36px sans-serif';ctx.fillStyle='#fff';ctx.fillText('NEXORI / TILT PREVIEW',60,200);
   applyContentDraft({version:1,changes:{blocks:{hero:{image:canvas.toDataURL('image/webp',.9)}}}});window.dispatchEvent(new Event('nexori:content-update'));
  });
  await page.locator('.has-custom-banner .cinematic-background').evaluate(image=>image.decode());
 }
 const state=page=>page.locator('[data-banner-tilt]').evaluate(stage=>{
  const image=stage.querySelector('img'),copy=stage.closest('.cinematic-hero').querySelector('.hero-copy');
  return {active:stage.hasAttribute('data-tilt-active'),x:stage.style.getPropertyValue('--banner-tilt-x'),y:stage.style.getPropertyValue('--banner-tilt-y'),matrix:getComputedStyle(stage.querySelector('.banner-tilt-card')).transform,width:image.offsetWidth,height:image.offsetHeight,nw:image.naturalWidth,nh:image.naturalHeight,copyTransform:getComputedStyle(copy).transform,overflow:document.documentElement.scrollWidth>innerWidth};
 });
 async function waitActive(page){await page.waitForFunction(()=>document.querySelector('[data-banner-tilt]')?.hasAttribute('data-tilt-active'));}
 try{
  const context=await browser.newContext({viewport:{width:1440,height:1000}});await configure(context);
  const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));await page.goto(base);await page.locator('[data-banner-tilt]').waitFor();
  // Full-background default mode preserves its existing text overlay and click targets.
  await page.mouse.move(1180,350);await waitActive(page);assert.notEqual((await state(page)).matrix,'none');assert.equal((await state(page)).copyTransform,'none');
  await page.locator('.hero-buttons a').first().click();await page.locator('#collection-grid').waitFor();await page.locator('.header .brand').click();
  await page.mouse.move(5,5);await custom(page);
  const rest=await state(page);assert.equal(rest.nw,700);assert.equal(rest.nh,393);assert.ok(Math.abs(rest.width/rest.height-700/393)<.01);assert.ok(rest.width<=875);
  let rect=await page.locator('[data-banner-tilt]').boundingBox();
  await page.mouse.move(rect.x+rect.width*.9,rect.y+rect.height*.22);await waitActive(page);const tilted=await state(page);
  assert.ok(parseFloat(tilted.x)>0&&parseFloat(tilted.y)>0);assert.ok(Math.abs(parseFloat(tilted.x))<=5.5&&Math.abs(parseFloat(tilted.y))<=5.5);
  assert.equal(tilted.width,rest.width);assert.equal(tilted.height,rest.height);assert.equal(tilted.copyTransform,'none');assert.equal(tilted.overflow,false);
  await page.waitForTimeout(220);await page.locator('.cinematic-hero').screenshot({path:'/tmp/nexori-tilt-desktop.png'});
  await page.mouse.move(5,5);assert.equal((await state(page)).active,false);assert.equal((await state(page)).x,'0deg');
  // Both OS and site preferences disable the enhancement immediately.
  await page.emulateMedia({reducedMotion:'reduce'});await page.mouse.move(rect.x+rect.width*.8,rect.y+rect.height*.2);assert.equal((await state(page)).matrix,'none');assert.equal((await state(page)).active,false);
  await page.emulateMedia({reducedMotion:'no-preference'});await page.locator('.ribbon-motion').click();await page.evaluate(()=>scrollTo(0,0));rect=await page.locator('[data-banner-tilt]').boundingBox();await page.mouse.move(rect.x+rect.width*.8,rect.y+rect.height*.2);assert.equal((await state(page)).matrix,'none');assert.equal((await state(page)).active,false);
  await page.locator('.ribbon-motion').click();await page.evaluate(()=>scrollTo(0,0));await page.mouse.move(5,5);rect=await page.locator('[data-banner-tilt]').boundingBox();await page.mouse.move(rect.x+rect.width*.8,rect.y+rect.height*.3);await waitActive(page);await page.evaluate(()=>window.dispatchEvent(new Event('blur')));assert.equal((await state(page)).active,false);
  // Rerender/navigation must dispose the old handlers, not accumulate effects.
  await page.evaluate(()=>window.__oldTilt=document.querySelector('[data-banner-tilt]'));
  await page.locator('.header a[href="/collection"]').first().click();
  await page.evaluate(()=>window.__oldTilt.dispatchEvent(new PointerEvent('pointermove',{pointerType:'mouse',isPrimary:true,clientX:600,clientY:300,bubbles:true})));
  assert.equal(await page.evaluate(()=>window.__oldTilt.hasAttribute('data-tilt-active')),false);
  for(let i=0;i<3;i++){await page.locator('.header .brand').click();await custom(page);assert.equal(await page.locator('[data-banner-tilt]').count(),1);await page.locator('.header a[href="/collection"]').first().click();}
  await page.locator('.header .brand').click();await custom(page);
  for(const width of [320,390,850,1024,1440,1920]){await page.setViewportSize({width,height:1000});await page.mouse.move(1,1);await page.waitForTimeout(50);const st=await state(page);assert.equal(st.overflow,false);assert.ok(Math.abs(st.width/st.height-700/393)<.015);assert.ok(st.width<=875);}
  console.log('PASS desktop tilt bounded, image sizing unchanged, text/links stable, leave/blur reset, OS/site reduced motion, rerender cleanup, six widths.');
  await context.close();
  const touch=await browser.newContext({viewport:{width:390,height:844},hasTouch:true,isMobile:true});await configure(touch);
  const mobile=await touch.newPage();mobile.on('pageerror',e=>errors.push(e.message));await mobile.goto(base);await mobile.locator('[data-banner-tilt]').waitFor();await custom(mobile);
  const cdp=await touch.newCDPSession(mobile);const box=await mobile.locator('[data-banner-tilt]').boundingBox();const x=Math.round(box.x+box.width*.8),y=Math.round(box.y+box.height*.45);
  await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y}]});await waitActive(mobile);const first=await state(mobile);assert.ok(Math.abs(parseFloat(first.x))<=3.5&&Math.abs(parseFloat(first.y))<=3.5);
  await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x+3,y:y+2}]});await mobile.waitForTimeout(60);assert.notEqual((await state(mobile)).x,first.x);
  await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await mobile.waitForFunction(()=>!document.querySelector('[data-banner-tilt]').hasAttribute('data-tilt-active'));
  // Native vertical scrolling is deliberately not prevented by the banner.
  await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y}]});
  for(let dy=20;dy<=140;dy+=20){await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x,y:y-dy}]});await mobile.waitForTimeout(35);}
  await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await mobile.waitForTimeout(100);
  assert.ok(await mobile.evaluate(()=>scrollY>20),'native touch scroll must continue');assert.equal((await state(mobile)).active,false);assert.equal((await state(mobile)).overflow,false);
  await mobile.evaluate(()=>scrollTo(0,0));await mobile.screenshot({path:'/tmp/nexori-tilt-mobile.png'});
  await mobile.emulateMedia({reducedMotion:'reduce'});await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x,y}]});assert.equal((await state(mobile)).matrix,'none');assert.equal((await state(mobile)).active,false);await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
  console.log('PASS real touch events tilt gently, update with movement, reset on release/cancel, preserve native scrolling and respect reduced motion.');
  assert.deepEqual(errors,[]);console.log('PASS no page errors; no production Firebase requests or writes.');
  await touch.close();
 }finally{await browser.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});

// Real browser codecs; no production Firebase reads or writes.
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 try{
  const page=await browser.newPage({viewport:{width:1440,height:1000}});
  await page.route(/https:\/\//,r=>r.abort());await page.goto((process.env.SITE_URL||'http://127.0.0.1:5173')+'/admin');await page.locator('#admin-login-form').waitFor();await page.locator('.header .brand').click();
  const result=await page.evaluate(async()=>{
   const {compressSparkImage,sparkImageProfile}=await import('/src/spark-images.js');
   const {imageEntries,sparkImageLimit}=await import('/src/spark-content.js');
   const canvas=document.createElement('canvas');canvas.width=3840;canvas.height=2160;
   const ctx=canvas.getContext('2d');const gradient=ctx.createLinearGradient(0,0,3840,2160);gradient.addColorStop(0,'#211437');gradient.addColorStop(.5,'#c595ed');gradient.addColorStop(1,'#4e8ea5');ctx.fillStyle=gradient;ctx.fillRect(0,0,3840,2160);
   ctx.strokeStyle='#f4d5ff';for(let x=0;x<3840;x+=40){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x+500,2160);ctx.stroke();}
   ctx.fillStyle='#fff';ctx.font='100px sans-serif';ctx.fillText('NEXORI — original wide artwork',160,500);
   const input=canvas.toDataURL('image/jpeg',.94);
   const details=async bytes=>{const image=await createImageBitmap(new Blob([bytes],{type:'image/webp'}));const d={width:image.width,height:image.height,bytes:bytes.length};image.close();return d;};
   const bannerBytes=await compressSparkImage(input,{profile:'banner'});
   const banner=await details(bannerBytes),product=await details(await compressSparkImage(input));
   const data=await new Promise(resolve=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.readAsDataURL(new Blob([bannerBytes],{type:'image/webp'}));});
   const again=await compressSparkImage(data,{profile:'banner'});
   const identical=bannerBytes.length===again.length&&bannerBytes.every((v,i)=>v===again[i]);
   canvas.width=800;canvas.height=450;ctx.fillStyle='#9d78b5';ctx.fillRect(0,0,800,450);
   const small=await details(await compressSparkImage(canvas.toDataURL(),{profile:'banner'}));
   canvas.width=2048;canvas.height=1152;const noise=ctx.createImageData(2048,1152);let seed=42;
   for(let i=0;i<noise.data.length;i+=4){seed=(Math.imul(seed,1664525)+1013904223)>>>0;noise.data[i]=seed&255;noise.data[i+1]=(seed>>>8)&255;noise.data[i+2]=(seed>>>16)&255;noise.data[i+3]=255;}ctx.putImageData(noise,0,0);
   let blocked='';try{await compressSparkImage(canvas.toDataURL('image/jpeg',.5),{profile:'banner'});}catch(e){blocked=e.message;}
   const profiles=imageEntries({changes:{blocks:{hero:{image:input}},products:{'midnight-ronin':{image:input}},worlds:{'one-piece':{pageImage:input,cardImage:input}}}}).map(e=>[e.group,e.id,e.field,sparkImageProfile(e)]);
   return{banner,product,small,identical,blocked,profiles,limit:sparkImageLimit,inputBytes:Math.floor(input.length*.75)};
  });
  assert(result.banner.width>=1920&&result.banner.width<=2560);assert.equal(result.product.width,1600);assert(result.banner.width>result.product.width);
  assert(result.banner.bytes<=result.limit);assert(result.product.bytes<=result.limit);
  assert.deepEqual([result.small.width,result.small.height],[800,450]);assert(result.identical,'efficient banner WebP must remain byte identical');
  assert.match(result.blocked,/192KB/);assert.match(result.blocked,/התמונה הקודמת/);
  assert.deepEqual(result.profiles.map(p=>p[3]),['banner','product','banner','product']);
  // Actual custom hero render and scroll: preserve image, remove enlargement/parallax.
  await page.evaluate(async()=>{const m=await import('/src/content.js');const c=document.createElement('canvas');c.width=700;c.height=393;c.getContext('2d').fillRect(0,0,800,450);m.applyContentDraft({version:1,changes:{blocks:{hero:{image:c.toDataURL()}}}});window.dispatchEvent(new Event('nexori:content-update'));});
  await page.locator('.has-custom-banner').waitFor();await page.locator('.has-custom-banner img.cinematic-background').evaluate(image=>image.decode());
  for(const width of [360,390,850,1024,1440,1920,2560]){
   await page.setViewportSize({width,height:900});await page.evaluate(()=>scrollTo(0,220));await page.waitForTimeout(80);
   const state=await page.locator('.has-custom-banner').evaluate(el=>{
    const image=el.querySelector('.cinematic-background'),box=image.getBoundingClientRect(),copy=el.querySelector('.hero-copy').getBoundingClientRect();
    return {transform:getComputedStyle(el.querySelector('.banner-scene')).transform,fit:getComputedStyle(image).objectFit,drift:el.style.getPropertyValue('--banner-drift'),overflow:document.documentElement.scrollWidth>innerWidth,width:box.width,height:box.height,naturalWidth:image.naturalWidth,naturalHeight:image.naturalHeight,separate:box.right<=copy.left+1||box.left>=copy.right-1||box.bottom<=copy.top+1||box.top>=copy.bottom-1};
   });
   assert.equal(state.transform,'none');assert.equal(state.drift,'0px');assert.equal(state.overflow,false);
   assert.equal(state.fit,'contain');assert(state.width<=state.naturalWidth*1.25+1&&state.height<=state.naturalHeight*1.25+1,'uploaded artwork enlargement must be bounded');
   assert(Math.abs(state.width/state.height-state.naturalWidth/state.naturalHeight)<.01,'preserve entire aspect ratio');
   assert(state.separate,'headline and artwork must not overlap');
  }
  console.log('PASS banner resolution, byte budget, WebP passthrough, no upscaling, explicit quality rejection, field profiles and custom hero on mobile/desktop.',JSON.stringify(result));
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exit(1)});

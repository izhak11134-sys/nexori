const assert=require('node:assert/strict');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 try{
 const context=await browser.newContext({viewport:{width:1440,height:1000}}),errors=[];
 await context.route(/^https?:/,r=>['127.0.0.1','localhost'].includes(new URL(r.request().url()).hostname)?r.continue():r.abort());
 await context.route('**/src/firebase-config.js*',r=>r.fulfill({contentType:'application/javascript',body:'export function firebaseConfiguration(){return null;}'}));
 const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
 const base=process.env.SITE_URL||'http://127.0.0.1:5199',standalone=base.endsWith('.html');
 const go=async path=>{await page.goto(standalone?base+'#'+path:base+path);await page.locator('#main').waitFor();};
 await go('/');await page.getByRole('heading',{name:'Fresh finds from Japan.'}).waitFor();assert.equal(await page.locator('.cdjapan-section .product-card').count(),8);assert.equal(await page.locator('.world-card').count(),14);
 await page.locator('.cdjapan-section .section-heading a').click();await page.locator('#collection-retailer').waitFor();assert.equal(await page.locator('#collection-retailer').inputValue(),'cdjapan');assert.equal(await page.locator('.product-card').count(),40);assert.match(await page.locator('#result-count').innerText(),/^40 finds/);
 const bad=await page.locator('.product-card img').evaluateAll(async imgs=>(await Promise.all(imgs.map(async img=>{try{img.loading='eager';await img.decode();return img.naturalWidth?null:img.src;}catch{return img.src;}}))).filter(Boolean));assert.deepEqual(bad,[]);
 const labels=await page.locator('.product-card-bottom>span').allTextContents();assert(labels.every(t=>/^JPY/.test(t)));assert((await page.locator('.product-card-info>.tiny-label').allTextContents()).every(t=>t.endsWith(' · CDJapan')));
 await page.locator('#collection-world').selectOption('one-piece');await page.waitForFunction(()=>document.querySelectorAll('.product-card').length===4);
 await page.locator('[data-category="style"]').click();await page.locator('.empty-state').waitFor();assert.equal(await page.locator('.product-card').count(),0);
 await page.locator('[data-reset]').click();await page.waitForFunction(()=>document.querySelectorAll('.product-card').length===1082);
 await page.locator('#collection-retailer').selectOption('ebay');await page.waitForFunction(()=>document.querySelectorAll('.product-card').length===1042);
 await go('/product/cdjapan-neogds-937972');const buy=page.locator('.retail-offer a.button');await buy.waitFor();assert.equal(await buy.getAttribute('href'),'https://www.cdjapan.co.jp/product/NEOGDS-937972');assert(!/sponsored/.test(await buy.getAttribute('rel')));assert.equal(await page.locator('.affiliate-disclosure').count(),0);assert.match(await page.locator('.retail-price').innerText(),/JPY\s*5,100/);assert.match(await page.locator('.retail-offer').innerText(),/no affiliate commission from this link/);assert.match(await page.locator('.retail-offer').innerText(),/2026-10-28/);
 for(const [id,type] of [['cdjapan-neogds-1035511','Plush collectible'],['cdjapan-neogds-1016446','Clear file / stationery'],['cdjapan-neogds-965677','Happi coat']]){await go('/product/'+id);await buy.waitFor();assert.match(await page.locator('.detail-info>.eyebrow').innerText(),new RegExp(type,'i'));}
 await go('/collection?retailer=cdjapan');await page.setViewportSize({width:390,height:844});await page.locator('.product-card').first().waitFor();assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);await page.screenshot({path:'/tmp/nexori-cdjapan-mobile.png'});
 await page.setViewportSize({width:1440,height:1000});await page.screenshot({path:'/tmp/nexori-cdjapan-desktop.png'});
 assert.deepEqual(errors,[]);console.log('PASS '+(standalone?'portable':'source')+': homepage picks, 40 decoded photos, JPY pricing, combined retailer filters and reset, 1042 eBay preserved, regular CDJapan destinations, correct types, mobile layout and no page errors.');
 await context.close();
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});

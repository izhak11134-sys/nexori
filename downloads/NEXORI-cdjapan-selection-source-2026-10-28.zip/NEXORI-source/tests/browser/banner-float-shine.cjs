// Local UI verification; no production Firebase traffic.
const assert=require('node:assert/strict');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 try{
 const context=await browser.newContext({viewport:{width:1440,height:1000}});
 await context.route(/^https?:/,r=>['127.0.0.1','localhost'].includes(new URL(r.request().url()).hostname)?r.continue():r.abort());
 await context.route('**/src/firebase-config.js*',r=>r.fulfill({contentType:'application/javascript',body:'export function firebaseConfiguration(){return null;}'}));
 const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(process.env.SITE_URL||'http://127.0.0.1:5199');
 const banner=page.locator('.banner-tilt-card');await banner.waitFor();
 const float=await banner.evaluate(el=>{const a=el.getAnimations().find(a=>a.animationName==='nexori-banner-float');if(!a)return null;a.pause();a.currentTime=0;const first=getComputedStyle(el).translate;a.currentTime=3500;return {first,mid:getComputedStyle(el).translate};});
 assert.ok(float);assert.notEqual(float.first,float.mid);assert.ok(float.mid.includes('-8px'));
 const cards=page.locator('.world-card');assert.equal(await cards.count(),14);
 const links=await cards.evaluateAll(list=>list.map(c=>c.getAttribute('href')));assert.equal(new Set(links).size,14);
 for(let i=0;i<14;i++){
  const card=cards.nth(i);await card.hover({position:{x:30,y:40}});
  await page.waitForFunction(i=>document.querySelectorAll('.world-card')[i].hasAttribute('data-world-shining'),i);
  const first=await card.evaluate(el=>el.style.getPropertyValue('--world-shine-x'));
  await card.hover({position:{x:90,y:60}});
  await page.waitForFunction(({i,first})=>document.querySelectorAll('.world-card')[i].style.getPropertyValue('--world-shine-x')!==first,{i,first});
  assert.equal(await page.locator('[data-world-shining]').count(),1);
  assert.equal(await card.evaluate(el=>getComputedStyle(el,'::after').pointerEvents),'none');
 }
 await page.mouse.move(1,1);await page.waitForFunction(()=>!document.querySelector('[data-world-shining]'));
 await page.emulateMedia({reducedMotion:'reduce'});
 assert.equal(await banner.evaluate(el=>getComputedStyle(el).animationName),'none');
 await cards.first().hover();assert.equal(await cards.first().evaluate(el=>getComputedStyle(el,'::after').display),'none');
 assert.equal(await page.locator('[data-world-shining]').count(),0);
 await page.emulateMedia({reducedMotion:'no-preference'});
 await page.locator('.ribbon-motion').click();assert.equal(await banner.evaluate(el=>getComputedStyle(el).animationName),'none');
 await cards.first().hover();assert.equal(await cards.first().evaluate(el=>getComputedStyle(el,'::after').display),'none');
 await page.locator('.ribbon-motion').click();
 await page.evaluate(()=>window.__oldGrid=document.querySelector('.worlds-grid'));
 await cards.first().click();await page.locator('.header .brand').click();await cards.first().waitFor();
 assert.equal(await page.evaluate(()=>window.__oldGrid.querySelector('[data-world-shining]')!==null),false);
 await page.evaluate(()=>{history.pushState({},'', '/worlds');dispatchEvent(new PopStateEvent('popstate'));});
 await cards.first().waitFor();assert.equal(await cards.count(),14);await cards.first().hover();await page.waitForFunction(()=>!!document.querySelector('[data-world-shining]'));
 await page.screenshot({path:'/tmp/nexori-world-shine.png',fullPage:false});
 assert.deepEqual(errors,[]);
 console.log('PASS floating banner at animation endpoints; all 14 distinct anime links shine and follow pointer; one active highlight; links/navigation preserved; OS/site reduced motion; disposed grid reset; /worlds supported; no page errors.');
 await context.close();
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});

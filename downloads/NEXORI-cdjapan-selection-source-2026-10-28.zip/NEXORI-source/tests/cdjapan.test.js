import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,access} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {products} from '../src/data.js';
import {cdjapanProducts} from '../src/cdjapan-products.js';
import {retailerDestination} from '../src/affiliate-links.js';
import {catalogDefaults,selectCatalogProducts,readCatalogFilters,catalogHref,validateCatalog} from '../src/catalog.js';
import {applyContentDraft,contentRecord} from '../src/content.js';
const evidence=JSON.parse(await readFile(new URL('../docs/cdjapan-2026-10-28/product-evidence.json',import.meta.url)));

test('40 unique CDJapan products match actual product-page evidence, stock, price, maker and image permission',async()=>{
 assert.equal(cdjapanProducts.length,40);assert.equal(new Set(cdjapanProducts.map(p=>p.id)).size,40);validateCatalog(cdjapanProducts);
 for(const p of cdjapanProducts){
  const r=evidence.find(r=>r.code===p.catalogNo);assert(r);assert.equal(r.sourceUrl,p.sourceUrl);assert.equal(r.priceJPY,Number(p.price));assert.equal(r.manufacturer,p.manufacturer);assert.equal(r.availability,p.availability);assert.deepEqual(r.issues,[]);
  assert.equal(p.currency,'JPY');assert.equal(p.photoPermission,'cdjapan-affiliate-program');assert.equal(p.stockCheckedOn,'2026-10-28');assert.match(p.availability,/in stock/i);
  assert.equal(new URL(p.sourceUrl).origin,'https://www.cdjapan.co.jp');assert.equal(new URL(p.sourceUrl).pathname,'/product/'+p.catalogNo);
  assert.equal(retailerDestination(p).url,p.sourceUrl);assert.equal(retailerDestination(p).affiliate,false);assert.equal(new URL(retailerDestination(p).url).search,'');
  await access(new URL('../public'+p.productPhoto,import.meta.url));
 }
 assert(cdjapanProducts.some(p=>p.typeId==='plush-toys'));assert(cdjapanProducts.some(p=>p.typeId==='stationery'));assert(cdjapanProducts.some(p=>p.category==='style'));
});

test('all 1042 original eBay records remain byte-equivalent as JSON',async()=>{
 const old=JSON.parse(await readFile(new URL('./fixtures/ebay-preservation.json',import.meta.url)));
 const ebay=products.filter(p=>p.retailer==='eBay');assert.equal(ebay.length,old.count);
 assert.equal(createHash('sha256').update(JSON.stringify(ebay)).digest('hex'),old.sha256);
});

test('retailer filters combine with category/world/search and round-trip through URLs',()=>{
 const filters={...catalogDefaults,retailer:'cdjapan'};assert.equal(selectCatalogProducts(products,filters).length,40);
 assert.equal(selectCatalogProducts(products,{...filters,world:'one-piece'}).length,4);
 assert.equal(selectCatalogProducts(products,{...filters,category:'desk'}).length,9);
 assert.equal(selectCatalogProducts(products,{...filters,world:'one-piece',category:'style'}).length,0);
 const shared={...filters,category:'figures',query:'Luffy & Nami',sort:'az'};assert.deepEqual(readCatalogFilters(new URL(catalogHref(shared),'https://example.test').searchParams),shared);
 assert.equal(readCatalogFilters(new URLSearchParams('retailer=other')).retailer,'all');
});

test('new CDJapan products support normal owner content editing without changing native currency',()=>{
 const id=cdjapanProducts[0].id;
 applyContentDraft({version:1,changes:{products:{[id]:{name:'Edited selection',price:'5200',priceCheckedOn:'2026-10-28'}}}});
 assert.equal(contentRecord('products',id).name,'Edited selection');assert.equal(contentRecord('products',id).currency,'JPY');assert.equal(contentRecord('products',id).price,'5200');
 applyContentDraft({version:1,changes:{}});assert.equal(contentRecord('products',id).name,'Luffy Gear 4 — Figuarts ZERO Extra Battle');
});

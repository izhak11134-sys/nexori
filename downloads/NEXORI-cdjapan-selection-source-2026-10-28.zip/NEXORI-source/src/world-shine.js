// One delegated pointer controller for all anime cards in the current grid.
export function mountWorldShine(root,{media=window.matchMedia('(prefers-reduced-motion: reduce)'),paused=false}={}) {
  if(!root)return {setPaused(){},dispose(){}};
  const doc=root.ownerDocument,win=doc.defaultView,events=new AbortController();
  let active=null,pending=null,frame=0,touching=false,disposed=false;
  const blocked=()=>disposed||paused||media.matches||doc.hidden;
  for(const card of root.querySelectorAll('.world-card')){
    const color=card.querySelector('.world-symbol')?.style.getPropertyValue('--world-color');
    if(color)card.style.setProperty('--world-shine-color',color);
  }
  function reset(){
    if(frame)win.cancelAnimationFrame(frame);
    frame=0;pending=null;touching=false;
    if(active){active.removeAttribute('data-world-shining');active.style.removeProperty('--world-shine-x');active.style.removeProperty('--world-shine-y');active=null;}
  }
  function syncMotion(){root.classList.toggle('world-shine-disabled',Boolean(paused||media.matches));if(blocked())reset();}
  function paint(){
    frame=0;if(blocked()||!pending)return reset();
    const {card,x,y}=pending;pending=null;if(!card.isConnected)return reset();
    if(active&&active!==card){active.removeAttribute('data-world-shining');active.style.removeProperty('--world-shine-x');active.style.removeProperty('--world-shine-y');}
    active=card;const rect=card.getBoundingClientRect();if(!rect.width||!rect.height)return;
    const clamp=value=>Math.min(100,Math.max(0,value));
    card.style.setProperty('--world-shine-x',`${clamp((x-rect.left)/rect.width*100).toFixed(1)}%`);
    card.style.setProperty('--world-shine-y',`${clamp((y-rect.top)/rect.height*100).toFixed(1)}%`);
    card.setAttribute('data-world-shining','');
  }
  function move(event){
    if(blocked()||event.isPrimary===false||(event.pointerType==='touch'&&!touching))return;
    const card=event.target.closest?.('.world-card');if(!card||!root.contains(card))return;
    pending={card,x:event.clientX,y:event.clientY};if(!frame)frame=win.requestAnimationFrame(paint);
  }
  const on=(target,type,handler)=>target.addEventListener(type,handler,{passive:true,signal:events.signal});
  on(root,'pointerover',event=>{if(event.pointerType!=='touch')move(event);});
  on(root,'pointerdown',event=>{if(event.isPrimary===false)return;touching=event.pointerType==='touch';move(event);});
  on(root,'pointermove',move);
  on(root,'pointerout',event=>{const card=active||pending?.card;if(card&&(!event.relatedTarget||!card.contains(event.relatedTarget)))reset();});
  on(root,'pointerleave',reset);on(root,'pointercancel',reset);
  on(win,'pointerup',event=>{if(event.pointerType==='touch')reset();});
  on(win,'blur',reset);on(win,'scroll',()=>{if(touching)reset();});
  on(doc,'visibilitychange',()=>{if(doc.hidden)reset();});
  media.addEventListener('change',syncMotion);syncMotion();
  return {setPaused(value){paused=Boolean(value);syncMotion();},dispose(){if(disposed)return;reset();disposed=true;events.abort();media.removeEventListener('change',syncMotion);}};
}

// Pointer-only enhancement: no device-motion permissions, timers, or scroll interception.
export function mountBannerTilt(stage,{surface=stage,media=window.matchMedia('(prefers-reduced-motion: reduce)'),paused=false}={}) {
  if(!stage||!surface)return {setPaused(){},dispose(){}};
  const doc=stage.ownerDocument,win=doc.defaultView,events=new AbortController();
  let frame=0,pending=null,touching=false,disposed=false;
  const blocked=()=>disposed||paused||media.matches||doc.hidden;
  const clamp=(value,min,max)=>Math.min(max,Math.max(min,value));
  function reset(){
    if(frame)win.cancelAnimationFrame(frame);
    frame=0;pending=null;touching=false;
    stage.removeAttribute('data-tilt-active');
    stage.style.setProperty('--banner-tilt-x','0deg');
    stage.style.setProperty('--banner-tilt-y','0deg');
    stage.style.setProperty('--banner-tilt-light-x','50%');
    stage.style.setProperty('--banner-tilt-light-y','50%');
    stage.style.setProperty('--banner-tilt-shadow-x','0px');
  }
  function syncMotion(){
    stage.classList.toggle('banner-tilt-disabled',Boolean(paused||media.matches));
    if(blocked())reset();
  }
  function paint(){
    frame=0;
    if(blocked()||!pending||!stage.isConnected)return reset();
    const {x,y,type}=pending;pending=null;
    const rect=stage.getBoundingClientRect();if(!rect.width||!rect.height)return;
    const nx=clamp((x-rect.left)/rect.width,0,1),ny=clamp((y-rect.top)/rect.height,0,1);
    const strength=type==='touch'?3.5:5.5;
    stage.style.setProperty('--banner-tilt-x',`${((.5-ny)*2*strength).toFixed(2)}deg`);
    stage.style.setProperty('--banner-tilt-y',`${((nx-.5)*2*strength).toFixed(2)}deg`);
    stage.style.setProperty('--banner-tilt-light-x',`${(nx*100).toFixed(1)}%`);
    stage.style.setProperty('--banner-tilt-light-y',`${(ny*100).toFixed(1)}%`);
    stage.style.setProperty('--banner-tilt-shadow-x',`${((.5-nx)*20).toFixed(1)}px`);
    stage.setAttribute('data-tilt-active','');
  }
  function move(event){
    if(event.isPrimary===false||blocked()||(event.pointerType==='touch'&&!touching))return;
    pending={x:event.clientX,y:event.clientY,type:event.pointerType};
    if(!frame)frame=win.requestAnimationFrame(paint);
  }
  const on=(target,type,handler)=>target.addEventListener(type,handler,{passive:true,signal:events.signal});
  on(surface,'pointerenter',event=>{if(event.pointerType!=='touch')move(event);});
  on(surface,'pointerdown',event=>{if(event.isPrimary===false)return;touching=event.pointerType==='touch';move(event);});
  on(surface,'pointermove',move);
  on(surface,'pointerleave',reset);
  on(surface,'pointercancel',reset);
  on(win,'pointerup',event=>{if(event.pointerType==='touch')reset();});
  on(win,'blur',reset);
  on(win,'scroll',()=>{if(touching)reset();});
  on(doc,'visibilitychange',()=>{if(doc.hidden)reset();});
  media.addEventListener('change',syncMotion);
  syncMotion();
  return {
    setPaused(value){paused=Boolean(value);syncMotion();},
    dispose(){if(disposed)return;reset();disposed=true;events.abort();media.removeEventListener('change',syncMotion);},
  };
}

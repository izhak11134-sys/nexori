import { doc, getDoc, getDocFromServer, setDoc, runTransaction, serverTimestamp, onSnapshot, collection, query, orderBy, limit, getDocs, Bytes } from 'firebase/firestore';
import { sparkContent, publicContent, imageEntries, sparkImagePath, sparkImageLimit, emptyContent, schemaChunks, schemaChunkRecords, receiptChunks, rootChunks, receiptRecords } from './spark-content.js';

function conflict(target='draft',expected,actual) {return Object.assign(new Error('זוהתה גרסה לא מעודכנת. יש לסנכרן את התוכן לפני המשך הפעולה.'),{code:'firestore/aborted',conflictTarget:target,expectedRevision:expected,actualRevision:actual});}
function sameRevision(snapshot, expected, target='draft') {const actual=snapshot.data()?.revision??0;if(actual!==expected)throw conflict(target,expected,actual);}
export function createSparkStore(db, currentUid) {
  const draftRef=doc(db,'cms','draft'),publicRef=doc(db,'public','site');
  let draftRevision=0,publishedRevision=0;
  const uid=()=>{const value=currentUid();if(!value)throw Object.assign(new Error('יש להתחבר למנהל.'),{code:'firestore/unauthenticated'});return value;};
  async function image(value) {
    const snapshot=await getDoc(doc(db,sparkImagePath(value)));
    if (!snapshot.exists()) throw new Error('תמונה חסרה. העלה אותה מחדש.');
    const data=snapshot.data();
    if (data.mime!=='image/webp' || !(data.bytes instanceof Bytes) || data.bytes.toUint8Array().length>sparkImageLimit) throw new Error('תמונה אינה בפורמט הנתמך.');
    const bytes=data.bytes.toUint8Array();
    if (bytes.length<12 || String.fromCharCode(...bytes.slice(0,4))!=='RIFF' || String.fromCharCode(...bytes.slice(8,12))!=='WEBP') throw new Error('קובץ התמונה אינו תקין.');
    return data;
  }
  // Stage independent immutable documents with a bounded number of writes in
  // flight. Await every phase before creating proofs or committing the release.
  async function stage(path,payload,groups,recordsFor) {
    for(let offset=0;offset<groups.length;offset+=6)await Promise.all(groups.slice(offset,offset+6).map(async group=>{
      try{await setDoc(doc(db,path,group.id),{records:recordsFor(payload,group),createdAt:serverTimestamp()});}
      catch(error){error.sparkChunk=group.id;throw error;}
    }));
  }
  async function commitRelease(payload,revisionId,expected,draftExpected=null) {
    await stage(`publishedContent/${revisionId}/groups`,payload,schemaChunks,schemaChunkRecords);
    await stage(`publishedContent/${revisionId}/proofs`,payload,receiptChunks,receiptRecords);
    await stage(`publishedContent/${revisionId}/proofs`,payload,rootChunks,receiptRecords);
    return runTransaction(db,async tx=>{
      const current=await tx.get(publicRef);
      sameRevision(current,expected,'public');
      if (draftExpected!==null) {const draft=await tx.get(draftRef);sameRevision(draft,draftExpected);if(!draft.exists())throw new Error('שמור טיוטה לפני החלת שינויים.');}
      const revision=expected+1;
      if(!current.exists())tx.set(doc(db,'revisions','initial'),{payload:emptyContent(),revision:0,createdAt:serverTimestamp(),kind:'initial'});
      tx.set(doc(db,'revisions',revisionId),{payload,revision,createdAt:serverTimestamp(),kind:draftExpected===null?'restore':'publish'});
      tx.set(doc(db,'mediaReleases',revisionId),{revision,createdAt:serverTimestamp()});
      tx.set(publicRef,{payload,revision,revisionId,updatedAt:serverTimestamp()});
      return {revision,revisionId,payload};
    });
  }
  return {
    subscribePublic(fn,onError) {return onSnapshot(publicRef,snapshot=>{const data=snapshot.data();publishedRevision=Math.max(publishedRevision,data?.revision??0);fn(data?.payload??emptyContent(),{fromCache:snapshot.metadata.fromCache,exists:snapshot.exists(),revision:data?.revision??0});},onError);},
    async confirmPublished(release) {
      const snapshot=await getDocFromServer(publicRef),current=snapshot.data();
      if(!snapshot.exists()||current.revision!==release.revision||current.revisionId!==release.revisionId)throw conflict('confirmation',release.revision,current?.revision);
      publishedRevision=Math.max(publishedRevision,current.revision);
      const payload=sparkContent(current.payload,undefined,true);
      const canonical=value=>value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().map(key=>[key,canonical(value[key])])):value;
      if(JSON.stringify(canonical(payload))!==JSON.stringify(canonical(release.payload)))throw new Error('הגרסה הציבורית לא תואמת לשינויים שנשלחו. לא ניתן לאשר שהשינויים הוחלו.');
      return payload;
    },
    async loadDraft() {const snapshot=await getDocFromServer(draftRef);draftRevision=snapshot.data()?.revision??0;return sparkContent(snapshot.exists()?snapshot.data().payload:await this.published(),uid());},
    async save(input) {
      const ownerUid=uid(),payload=sparkContent(input,ownerUid),expected=draftRevision,draftId=crypto.randomUUID();
      await stage(`draftContent/${ownerUid}/versions/${draftId}/groups`,payload,schemaChunks,schemaChunkRecords);
      await stage(`draftContent/${ownerUid}/versions/${draftId}/proofs`,payload,receiptChunks,receiptRecords);
      await stage(`draftContent/${ownerUid}/versions/${draftId}/proofs`,payload,rootChunks,receiptRecords);
      const revision=await runTransaction(db,async tx=>{
        const snapshot=await tx.get(draftRef);sameRevision(snapshot,expected);
        tx.set(draftRef,{payload,revision:expected+1,draftId,updatedBy:ownerUid,updatedAt:serverTimestamp()});return expected+1;
      });
      draftRevision=revision;return payload;
    },
    async uploadImage(bytes) {
      if(!(bytes instanceof Uint8Array)||!bytes.length||bytes.length>sparkImageLimit)throw new Error('התמונה גדולה מדי לאחר הקטנה.');
      const ownerUid=uid(),id=crypto.randomUUID();
      await setDoc(doc(db,`draftImages/${ownerUid}/images/${id}`),{bytes:Bytes.fromUint8Array(bytes),mime:'image/webp',createdAt:serverTimestamp()});
      return `spark:drafts/${ownerUid}/${id}`;
    },
    image,
    async publish() {
      const ownerUid=uid(),draftExpected=draftRevision;
      // The public listener can lag behind a server read. Establish a fresh
      // public baseline now, then protect it inside the final transaction.
      const [draft,current]=await Promise.all([getDocFromServer(draftRef),getDocFromServer(publicRef)]);
      sameRevision(draft,draftExpected,'draft');
      const expected=current.data()?.revision??0;
      publishedRevision=expected;
      if(!draft.exists())throw new Error('שמור טיוטה לפני החלת שינויים.');
      const payload=publicContent(sparkContent(draft.data().payload,ownerUid)),id=crypto.randomUUID(),copies=new Map();
      for(const entry of imageEntries(payload)) {
        if(entry.value.startsWith('spark:published/'))continue;
        if(!copies.has(entry.value)) {
          const source=await image(entry.value),imageId=crypto.randomUUID();
          await setDoc(doc(db,`publishedImages/${id}/images/${imageId}`),{bytes:source.bytes,mime:source.mime,sourceId:entry.value.split('/').at(-1),createdAt:serverTimestamp()});
          copies.set(entry.value,`spark:published/${id}/${imageId}`);
        }
        entry.patch[entry.field]=copies.get(entry.value);
      }
      return commitRelease(sparkContent(payload,undefined,true),id,expected,draftExpected);
    },
    async restore(revisionId) {
      uid();const expected=publishedRevision;
      if(revisionId!=='initial'&&!/^[a-f0-9-]{36}$/.test(revisionId))throw new Error('גרסה אינה תקינה.');
      const snapshot=await getDoc(doc(db,'revisions',revisionId));if(!snapshot.exists())throw new Error('הגרסה לא נמצאה.');
      return commitRelease(sparkContent(snapshot.data().payload,undefined,true),crypto.randomUUID(),expected);
    },
    async revisions(){const result=await getDocs(query(collection(db,'revisions'),orderBy('createdAt','desc'),limit(20)));return result.docs.map(snapshot=>({id:snapshot.id,...snapshot.data()}));},
    async published(){const current=await getDocFromServer(publicRef);publishedRevision=current.data()?.revision??0;return sparkContent(current.data()?.payload??emptyContent(),undefined,true);},
    clear(){draftRevision=0;},
  };
}

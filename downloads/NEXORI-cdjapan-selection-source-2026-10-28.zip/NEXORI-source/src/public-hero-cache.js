import { validateContentDraft } from './content.js';
const prefix='nexori-public-hero-v1:',limit=300000;
const fields=['lead','accent','ending','description','imageAlt'];
export function createPublicHeroCache(config){
  const key=config?.projectId&&config?.appId?`${prefix}${config.projectId}:${config.appId}`:null;
  return {
    read(){
      if(!key)return null;
      try{
        const text=localStorage.getItem(key);if(!text||text.length>limit)return null;
        const payload=JSON.parse(text),hero=payload?.changes?.blocks?.hero;
        if(Object.keys(payload.changes??{}).join()!=='blocks'||Object.keys(payload.changes.blocks??{}).join()!=='hero')return null;
        if(!hero||!/^data:image\/webp;base64,[A-Za-z0-9+/]+={0,2}$/.test(hero.image))return null;
        if(Object.keys(hero).some(f=>!['image',...fields].includes(f)))return null;
        return validateContentDraft(payload);
      }catch{return null;}
    },
    remember(payload,images){
      if(!key)return false;
      try{
        if(Object.values(payload.changes?.products??{}).some(p=>'editorNotes' in p||'retailerUrl' in p))return false;
        const hero=payload.changes?.blocks?.hero;
        if(!hero?.image){localStorage.removeItem(key);return true;}
        if(!/^spark:published\/[a-f0-9-]{36}\/[a-f0-9-]{36}$/.test(hero.image))return false;
        const image=images.get(hero.image),bytes=image?.bytes;
        if(image?.mime!=='image/webp'||!(bytes instanceof Uint8Array)||bytes.length<12||bytes.length>192*1024)return false;
        if(String.fromCharCode(...bytes.slice(0,4))!=='RIFF'||String.fromCharCode(...bytes.slice(8,12))!=='WEBP')return false;
        let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
        const next={image:`data:image/webp;base64,${btoa(binary)}`};
        for(const field of fields)if(typeof hero[field]==='string')next[field]=hero[field];
        const value={version:1,changes:{blocks:{hero:next}}};validateContentDraft(value);
        const text=JSON.stringify(value);if(text.length>limit)return false;
        localStorage.setItem(key,text);return true;
      }catch{return false;}
    },
  };
}

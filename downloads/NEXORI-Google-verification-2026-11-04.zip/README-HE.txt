העלו ל-Netlify את כל תיקיית NEXORI-upload כולל assets.
אחרי ההעלאה חזרו ל-Google Search Console ולחצו אמת תחת תג HTML.
אין צורך בשינוי כללי Firebase.
השינוי היחיד באתר הוא הוספת תג האימות ל-head.

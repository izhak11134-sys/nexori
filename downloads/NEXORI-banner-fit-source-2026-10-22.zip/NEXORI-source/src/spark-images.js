import { sparkImageLimit } from './spark-content.js';

// Wide backgrounds need a separate quality floor; product thumbnails keep their existing policy.
export function sparkImageProfile({group,field}) {
  return group === 'blocks' || group === 'pages' || (group === 'worlds' && field === 'pageImage') ? 'banner' : 'product';
}

export async function compressSparkImage(dataUrl, {profile='product'} = {}) {
  const blob=await(await fetch(dataUrl)).blob();
  if(blob.size>2*1024*1024||!['image/png','image/jpeg','image/webp'].includes(blob.type))throw new Error('יש לבחור PNG, JPEG או WebP בגודל עד 2MB.');
  const bitmap=await createImageBitmap(blob);
  try {
    if(bitmap.width>8000||bitmap.height>8000)throw new Error('ממדי התמונה גדולים מדי.');
    const longEdge=Math.max(bitmap.width,bitmap.height);
    const banner=profile==='banner';
    // Retain an already efficient WebP without another lossy encoding.
    if(banner && blob.type==='image/webp' && blob.size<=sparkImageLimit)return new Uint8Array(await blob.arrayBuffer());
    let size=Math.min(1,(banner?2560:1600)/longEdge);
    const minimumSize=Math.min(1,1920/longEdge);
    const canvas=document.createElement('canvas');
    for(let attempt=0;attempt<5;attempt++) {
      canvas.width=Math.max(1,Math.round(bitmap.width*size));canvas.height=Math.max(1,Math.round(bitmap.height*size));
      const context=canvas.getContext('2d');
      context.imageSmoothingEnabled=true;context.imageSmoothingQuality='high';
      context.drawImage(bitmap,0,0,canvas.width,canvas.height);
      for(const quality of (banner?[.94,.90,.86,.84]:[.86,.74,.62])) {
        const result=await new Promise(resolve=>canvas.toBlob(resolve,'image/webp',quality));
        if(!result||result.type!=='image/webp')throw new Error('הדפדפן אינו תומך בהכנת תמונת WebP. נסה דפדפן עדכני.');
        if(result.size<=sparkImageLimit)return new Uint8Array(await result.arrayBuffer());
      }
      if(banner && size<=minimumSize)break;
      size=banner?Math.max(minimumSize,size*.9):size*.8;
    }
    if(banner)throw new Error('לא ניתן לשמור את הבאנר בחדות מספקת בתוך מגבלת האחסון הקיימת (192KB לתמונה). התמונה לא נשמרה. נסה קובץ WebP מותאם לרוחב הבאנר או תמונה עם פחות פרטים; התמונה הקודמת נשארה ללא שינוי.');
    throw new Error('התמונה גדולה מדי למסלול החינמי גם לאחר הקטנה. בחר תמונה פשוטה יותר.');
  } finally {bitmap.close();}
}

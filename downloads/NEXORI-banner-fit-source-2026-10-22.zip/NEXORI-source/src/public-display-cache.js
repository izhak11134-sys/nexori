// Only published content is stored here. Private drafts and authentication never
// enter this cache. One atomic record replaces the previous public revision.
const databaseName='nexori-public-display-v1',maxBytes=24*1024*1024;
function validImage(data){
  const bytes=data?.bytes;
  return data?.mime==='image/webp' && bytes instanceof Uint8Array && bytes.length>=12 && bytes.length<=192*1024
    && String.fromCharCode(...bytes.slice(0,4))==='RIFF' && String.fromCharCode(...bytes.slice(8,12))==='WEBP';
}
export function createPublicDisplayCache(namespace){
  let loaded,connection;
  function database(){
    if(!connection)connection=new Promise(resolve=>{
      let settled=false;const finish=value=>{if(settled){value?.close();return;}settled=true;clearTimeout(timer);resolve(value);};
      const timer=setTimeout(()=>finish(null),1200);
      try{
        const request=indexedDB.open(databaseName,1);
        request.onupgradeneeded=()=>request.result.createObjectStore('public');
        request.onsuccess=()=>finish(request.result);
        request.onerror=request.onblocked=()=>finish(null);
      }catch{finish(null);}
    });
    return connection;
  }
  async function load(){
    if(!loaded)loaded=(async()=>{
      const db=await database();if(!db)return null;
      return new Promise(resolve=>{
        const timer=setTimeout(()=>resolve(null),1200);
        const finish=value=>{clearTimeout(timer);resolve(value);};
        try{const request=db.transaction('public').objectStore('public').get(namespace);request.onsuccess=()=>finish(request.result??null);request.onerror=()=>finish(null);}catch{finish(null);}
      });
    })();
    return loaded;
  }
  return {
    load,
    async image(reference){
      if(!reference.startsWith('spark:published/'))return null;
      const data=(await load())?.images?.[reference];return validImage(data)?data:null;
    },
    async remember(payload,images){
      const next={payload:structuredClone(payload),images:{}};let total=JSON.stringify(payload).length;
      for(const group of Object.values(payload.changes))for(const patch of Object.values(group))for(const [field,reference] of Object.entries(patch)){
        if(!/image$/i.test(field)||!reference)continue;
        // Reject incomplete or private snapshots rather than persisting them.
        if(!reference.startsWith('spark:published/'))return false;
        if(Object.hasOwn(next.images,reference))continue;
        const data=images.get(reference);if(!validImage(data))return false;
        total+=data.bytes.length;if(total>maxBytes)return false;
        next.images[reference]=data;
      }
      if(Object.values(payload.changes.products??{}).some(patch=>'editorNotes' in patch||'retailerUrl' in patch))return false;
      const db=await database();if(!db)return false;
      return new Promise(resolve=>{
        try{const tx=db.transaction('public','readwrite');tx.objectStore('public').put(next,namespace);tx.oncomplete=()=>{loaded=Promise.resolve(next);resolve(true);};tx.onerror=tx.onabort=()=>resolve(false);}catch{resolve(false);}
      });
    },
  };
}

window.NEXORI_CLOUD_SITE = true;
document.documentElement.classList.add('nexori-public-pending');

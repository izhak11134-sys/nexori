const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const assert=require('node:assert/strict');
const base=process.env.NEXORI_TEST_URL||'http://127.0.0.1:5184';
const ref=n=>`spark:published/11111111-1111-1111-1111-111111111111/${String(n).padStart(8,'0')}-2222-2222-2222-222222222222`;
const stub=`export function createSparkStore(){
 window.__cloud={images:0,callback:null};
 return {clear(){},subscribePublic(fn){fn({version:1,changes:{}},{fromCache:true,exists:false});window.__cloud.callback=fn;const timer=setTimeout(()=>fn({version:1,changes:{blocks:{hero:{image:window.__refs[0]}},worlds:{'one-piece':{cardImage:window.__refs[0]}}}}),window.__delay??2200);return()=>clearTimeout(timer);},
 async image(reference){window.__cloud.images++;await new Promise(r=>setTimeout(r,reference===window.__refs[1]?500:20));return {mime:'image/webp',bytes:new Uint8Array(window.__webp)};}};}`;
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 try{
  const context=await browser.newContext({viewport:{width:1440,height:1000}}),page=await context.newPage(),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.route('**/src/firebase-config.js*',route=>route.fulfill({contentType:'application/javascript',body:`export function firebaseConfiguration(){return {apiKey:'demo-key',projectId:'demo-nexori-display',authDomain:'demo-nexori-display.firebaseapp.com',appId:'demo-display'};}`}));
  await page.route('**/src/firebase-spark-store.js*',route=>route.fulfill({contentType:'application/javascript',body:stub}));
  await page.addInitScript(refs=>{
    window.__refs=refs;
    const canvas=document.createElement('canvas');canvas.width=48;canvas.height=24;const ctx=canvas.getContext('2d');ctx.fillStyle='#7e4da0';ctx.fillRect(0,0,48,24);
    window.__webp=Array.from(Uint8Array.from(atob(canvas.toDataURL('image/webp').split(',')[1]),c=>c.charCodeAt(0)));
  },[ref(1),ref(2),ref(3)]);
  await page.goto(base);await page.locator('.hero').waitFor();
  assert.equal(await page.locator('html').evaluate(el=>el.classList.contains('nexori-public-pending')),true);
  assert.equal(await page.locator('.banner-scene').evaluate(el=>getComputedStyle(el).visibility),'hidden');
  assert.equal(await page.getByRole('link',{name:'Explore collection',exact:true}).first().isVisible(),true);
  await page.waitForFunction(()=>!document.documentElement.classList.contains('nexori-public-pending'));
  assert.match(await page.locator('.cinematic-background').getAttribute('src'),/^blob:/);
  assert.match(await page.locator('[data-content-id="one-piece"]').getAttribute('style'),/blob:/);
  await page.waitForFunction(async()=>new Promise(resolve=>{const r=indexedDB.open('nexori-public-display-v1',1);r.onsuccess=()=>{const db=r.result,q=db.transaction('public').objectStore('public').get('demo-nexori-display:demo-display');q.onsuccess=()=>{resolve(!!q.result);db.close();};};}));
  await page.addInitScript(()=>{window.__delay=4000;});
  const started=Date.now();await page.reload();await page.waitForFunction(()=>!document.documentElement.classList.contains('nexori-public-pending'));
  assert.ok(Date.now()-started<2500,'cached display must appear before the delayed public snapshot');
  assert.match(await page.locator('.cinematic-background').getAttribute('src'),/^blob:/);
  assert.equal(await page.evaluate(()=>window.__cloud.images),0,'cached public photos should not be downloaded again');
  await page.waitForTimeout(4200);
  assert.equal(await page.evaluate(()=>window.__cloud.images),0);
  // Overlapping server updates must keep the newest revision.
  await page.evaluate(()=>{
    window.__cloud.callback({version:1,changes:{blocks:{hero:{image:window.__refs[1],lead:'Older update'}}}});
    window.__cloud.callback({version:1,changes:{blocks:{hero:{image:window.__refs[2],lead:'Newest update'}}}});
  });
  await page.waitForFunction(()=>document.querySelector('h1')?.textContent.includes('Newest update'));
  await page.waitForTimeout(600);assert.match(await page.locator('h1').textContent(),/Newest update/);
  // Cached storage is optional and cannot store private draft references/notes.
  assert.equal(await page.evaluate(async()=>{
    const {createPublicDisplayCache}=await import('/src/public-display-cache.js');const cache=createPublicDisplayCache('privacy-test');
    const privateImage=await cache.remember({version:1,changes:{blocks:{hero:{image:'spark:drafts/owner/11111111-1111-1111-1111-111111111111'}}}},new Map());
    const privateNotes=await cache.remember({version:1,changes:{products:{'midnight-ronin':{editorNotes:'PRIVATE'}}}},new Map());
    return privateImage===false&&privateNotes===false&&(await cache.load())===null;
  }),true);
  for(const width of [390,1440]){await page.setViewportSize({width,height:900});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));}
  const blocked=await browser.newContext();await blocked.addInitScript(()=>Object.defineProperty(window,'indexedDB',{get(){throw new DOMException('Blocked','SecurityError');}}));
  const b=await blocked.newPage();await b.goto(base);assert.equal(await b.evaluate(async()=>{const {createPublicDisplayCache}=await import('/src/public-display-cache.js');return (await createPublicDisplayCache('blocked').load())===null;}),true);await blocked.close();
  assert.deepEqual(errors,[]);
  console.log('PASS: first-visit artwork gate, visible navigation, atomic banner/world pictures, cached refresh before delayed server, no repeated image reads, newest update wins, no private cache, optional blocked storage, 2 widths. Public Firestore reads were mocked.');
 }finally{await browser.close();}
})().catch(error=>{console.error(error);process.exit(1);});

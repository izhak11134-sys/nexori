// Run against the production preview, or SITE_URL=http://.../NEXORI.html SINGLE_HTML=1.
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const assert=require('node:assert/strict');

(async()=>{
  const {products,categories,franchises}=await import('../../src/data.js');
  const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
  const base=process.env.SITE_URL||'http://127.0.0.1:4175';
  const url=route=>process.env.SINGLE_HTML?`${base}#${route}`:`${base}${route}`;
  const context=await browser.newContext({viewport:{width:1440,height:900},reducedMotion:'reduce'});
  // No production Firebase writes or merchant requests are needed for this visitor check.
  await context.route(/https:\/\//,r=>r.abort());
  const page=await context.newPage(),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  try {
    await page.goto(url('/'));
    await page.locator('#home-edit-grid .product-card').first().waitFor();
    const featuredIds=await page.locator('#home-edit-grid .product-card').evaluateAll(cards=>cards.map(c=>c.dataset.contentId));
    assert.equal(featuredIds.length,8);
    assert.ok(new Set(featuredIds.map(id=>products.find(p=>p.id===id).worldId)).size>=6,'home previews a varied selection of anime worlds');
    assert.equal(await page.locator('.worlds-grid .world-card').count(),franchises.length,'all anime worlds remain discoverable on the homepage');
    for(const category of categories){
      await page.locator(`[data-edit="${category.id}"]`).click();
      assert.equal(await page.locator('#home-edit-grid .product-card').count(),8);
      await page.locator('.home-collection-link a').click();
      assert.equal(await page.locator('#collection-grid .product-card').count(),products.filter(p=>p.category===category.id).length,'category CTA reaches complete collection');
      await page.goBack();await page.locator('[data-edit="all"]').waitFor();
    }
    await page.goto(url('/collection'));
    await page.waitForFunction(expected=>document.querySelectorAll('#collection-grid .product-card').length===expected,products.length);
    const broken=await page.evaluate(async()=>{
      const photos=[...document.querySelectorAll('#collection-grid .retail-photo')];
      photos.forEach(image=>image.loading='eager');
      return (await Promise.all(photos.map(async image=>{try{await image.decode();return null;}catch{return image.src.slice(0,180);}}))).filter(Boolean);
    });
    assert.deepEqual(broken,[],'all catalog photos decode');
    const first=products[0];
    await page.locator(`[data-save="${first.id}"]`).click();
    await page.locator('.header-actions .saved-link').click();
    assert.equal(await page.locator('.product-card').count(),1);
    await page.reload();await page.locator(`[data-save="${first.id}"]`).waitFor();
    await page.locator('.art-link').click();await page.locator('.retail-offer').waitFor();
    assert.equal(await page.locator('.retail-offer a').getAttribute('href'),first.sourceUrl);
    await page.goBack();await page.locator(`[data-save="${first.id}"]`).waitFor();
    await page.locator(`[data-save="${first.id}"]`).click();
    assert.equal(await page.locator('.product-card').count(),0);

    for(const world of franchises){
      await page.goto(url(`/worlds/${world.id}`));
      await page.locator('.product-card').first().waitFor();
      assert.equal(await page.locator('.product-card').count(),125,world.id);
      for(const category of categories){
        await page.goto(url(`/collection?world=${world.id}&category=${category.id}`));
        await page.locator('#collection-grid .product-card').first().waitFor();
        assert.equal(await page.locator('#collection-grid .product-card').count(),25,`${world.id}/${category.id}`);
        assert.doesNotMatch(await page.locator('#catalog-plan').textContent(),/listings have not been added yet/);
      }
    }

    await page.goto(url('/collection'));
    await page.locator('#collection-world').selectOption('one-piece');
    await page.locator('[data-category="props"]').click();
    assert.equal(await page.locator('#collection-grid .product-card').count(),25);
    await page.locator('#collection-sort').selectOption('az');
    const names=await page.locator('#collection-grid h3').allTextContents();
    assert.deepEqual(names,[...names].sort((a,b)=>a.localeCompare(b)));
    await page.reload();await page.locator('#collection-sort').waitFor();
    assert.equal(await page.locator('#collection-world').inputValue(),'one-piece');
    assert.equal(await page.locator('#collection-sort').inputValue(),'az');
    await page.locator('[data-reset]').click();
    assert.equal(await page.locator('#collection-grid .product-card').count(),products.length);
    await page.locator('#collection-search').fill('no-such-product-zzzz');
    assert.equal(await page.locator('#collection-grid .product-card').count(),0);
    assert.match(await page.locator('#collection-grid').textContent(),/Try another search/);

    for(const width of [320,390,768,1440]){
      await page.setViewportSize({width,height:900});
      await page.goto(url('/'));await page.locator('[data-search]').waitFor();
      assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),`home overflow at ${width}`);
      if(width<=700){
        await page.locator('[data-menu]').click();assert.equal(await page.locator('#mobile-nav').isVisible(),true);
        await page.keyboard.press('Escape');assert.equal(await page.locator('#mobile-nav').isVisible(),false);
      }
      await page.locator('[data-search]').click();
      assert.equal(await page.locator('.search-result').count(),12,'quick search stays bounded');
      await page.locator('#global-search').fill('Naruto');
      assert.equal(await page.locator('.search-result').count(),12);
      await page.locator('.search-view-all').click();
      assert.equal(await page.locator('#collection-grid .product-card').count(),125);
      assert.equal(await page.locator('#collection-search').inputValue(),'Naruto');
      assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),`collection overflow at ${width}`);
      await page.locator('.art-link').first().click();await page.locator('.detail-art img').waitFor();
      assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),`detail overflow at ${width}`);
      await page.locator('[data-search]').click();await page.keyboard.press('Escape');
      assert.equal(await page.locator('[data-search]').evaluate(node=>node===document.activeElement),true);
    }
    const special=products.find(p=>p.name.includes('&'));
    if(special){
      await page.locator('[data-search]').click();await page.locator('#global-search').fill(special.name);
      assert.ok((await page.locator('.search-result strong').allTextContents()).includes(special.name),'literal ampersand search');
      await page.keyboard.press('Escape');
    }
    await page.goto(url('/admin'));await page.locator('#firebase-admin-page').waitFor();
    assert.ok(await page.locator('#firebase-admin-page').textContent());
    assert.deepEqual(errors,[]);
    console.log('PASS: '+products.length+' photos decode; '+(franchises.length*categories.length)+' anime/category combinations; saved finds survive reload and removal; retailer destinations; filters/sort/reload/empty state; bounded quick search and all results; mobile menu and keyboard focus; 4 widths; admin route; zero page exceptions.');
  } finally {await browser.close();}
})().catch(error=>{console.error(error);process.exit(1);});

import java.nio.file.*;
import com.google.firebase.rules.lang.*;
import com.google.firebase.rules.v1.*;
class NexoriRulesSize {
 public static void main(String[] args)throws Exception {
  for(String path:args){
   var source=Source.newBuilder().addFiles(com.google.firebase.rules.v1.File.newBuilder().setName("firestore.rules").setContent(Files.readString(Path.of(path)))).build();
   var result=FirebaseRulesProtoCompiler.createStandalone(com.google.firebase.rules.lang.common.FirebaseRulesLangOptions.builder().allowLetBindings(true).allowTernaryOperator(true).build()).compile(source);
   System.out.println(path+" errors="+result.hasCompilationError()+" ASTbytes="+result.getRulesetAst().getSerializedSize());
   for(var issue:result.getIssues())System.out.println(issue.getSeverity()+": "+issue.getDescription());
   if(result.hasCompilationError() || result.getRulesetAst().getSerializedSize()>245000)throw new IllegalStateException("Local compiled rules exceed the safety budget or failed compilation");
  }
 }
}

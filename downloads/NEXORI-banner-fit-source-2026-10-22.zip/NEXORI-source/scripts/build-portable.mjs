import {readFile,readdir,mkdir,copyFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {buildFirebaseHtml} from './build-firebase-html.mjs';
import {products} from '../src/data.js';
import {optimizedArtwork} from '../src/optimized-artwork.js';
const root=fileURLToPath(new URL('../',import.meta.url)),dest=path.join(root,`.firebase/portable-${products.length}`);
await mkdir(path.join(dest,'assets'),{recursive:true});
const art={};let bytes=0;
for(const name of await readdir(path.join(root,'public/assets'))){
 const ext=path.extname(name);if(!['.svg','.png','.jpg','.jpeg','.webp'].includes(ext))continue;
 const key=path.basename(name,ext),optimized=optimizedArtwork[key];
 const source=optimized?path.join(root,'public',optimized.src.slice(1)):path.join(root,'public/assets',name);
 const filename=key+path.extname(source);art[key]='assets/'+filename;
 await copyFile(source,path.join(dest,'assets',filename));bytes+=(await readFile(source)).length;
}
const html=await buildFirebaseHtml(await readFile(path.join(root,'index.html'),'utf8'),art);
if(!html.includes('nexori-development')||html.includes('nexori-2a8e1'))throw new Error('Incorrect public Firebase project');
await writeFile(path.join(dest,`NEXORI-${products.length}-products.html`),html);
console.log(JSON.stringify({folder:dest,htmlBytes:Buffer.byteLength(html),images:Object.keys(art).length,imageBytes:bytes}));

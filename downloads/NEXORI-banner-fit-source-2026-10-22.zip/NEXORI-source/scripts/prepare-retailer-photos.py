"""Download exact retailer photos for local review; publication permission is separate."""
from pathlib import Path
import json
import urllib.request
import urllib.parse
import sys

root = Path(__file__).resolve().parent.parent
records = json.loads((root / 'docs/retailer-image-sources.json').read_text())
failed = []
for record in records:
    url = urllib.parse.urlparse(record['image_url'])
    if url.scheme != 'https' or url.hostname not in {'cdn.media.amplience.net', 'i.ebayimg.com'} or url.username or url.password:
        raise SystemExit('Unexpected image host')
    name = record['file']
    if Path(name).name != name or not name.startswith('retail-') or not name.endswith('.jpg'):
        raise SystemExit('Unexpected image path')
    path = root / 'public/assets' / name
    if path.exists():
        print(record['id'], 'retained existing local photo')
        continue
    try:
        request = urllib.request.Request(record['image_url'], headers={'User-Agent': 'Mozilla/5.0', 'Accept': 'image/jpeg'})
        with urllib.request.urlopen(request, timeout=25) as response:
            data = response.read(8 * 1024 * 1024 + 1)
        if not data.startswith(b'\xff\xd8\xff') or len(data) > 8 * 1024 * 1024:
            raise ValueError('Expected JPEG image smaller than 8 MiB')
        path.write_bytes(data)
        print(record['id'], 'downloaded local photo')
    except Exception as error:
        failed.append(record['id'])
        print(record['id'], str(error), file=sys.stderr)
if failed:
    raise SystemExit(1)

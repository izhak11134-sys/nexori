import './style.css';
import './enhancements.css';
import './professional.css';
import { categories, products, franchises, guides } from './data.js';
import { catalogTypes, catalogWorlds, catalogDefaults, readCatalogFilters, catalogHref, selectCatalogProducts } from './catalog.js';
import { initialiseContent, contentRecord, contentBlocks, contentDraft } from './content.js';
import { policies as info, contactLink, policyDate, previewNotice, franchiseNotice } from './policies.js';
import { optimizedArtwork } from './optimized-artwork.js';

initialiseContent();

const icons = {
  arrow: '<path d="M4 12h15m-6-6 6 6-6 6"/>',
  up: '<path d="M12 20V5m-6 6 6-6 6 6"/>',
  external: '<path d="M14 4h6v6m0-6L10 14m-3-9H4v15h15v-3"/>',
  search: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/>',
  heart: '<path d="M20.5 5.5a5 5 0 0 0-7 0L12 7l-1.5-1.5a5 5 0 0 0-7 7L12 21l8.5-8.5a5 5 0 0 0 0-7Z"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>', close: '<path d="m6 6 12 12M6 18 18 6"/>',
  chevron: '<path d="m8 10 4 4 4-4"/>', check: '<path d="m5 12 4 4L19 6"/>',
  cube: '<path d="m12 3 9 5v9l-9 5-9-5V8Zm0 9v10M3 8l9 4 9-4M7.5 5.5l9 5v5"/>',
  shirt: '<path d="m8 3-6 4 3 5 3-2v11h8V10l3 2 3-5-6-4a4 4 0 0 1-8 0Z"/>',
  monitor: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8m-4-4v4"/>',
  sword: '<path d="m6 18 12-12 3-3v5L9 20m-4-5 5 5m-4-2-3 3"/>',
  shield: '<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6Z"/><path d="m8 12 3 3 5-6"/>',
  spark: '<path d="m12 3 3 6 6 3-6 3-3 6-3-6-6-3 6-3Z"/>',
  book: '<path d="M12 6C8 3 3 4 3 4v15s5-1 9 2c4-3 9-2 9-2V4s-5-1-9 2Zm0 0v15"/>',
  filter: '<path d="M4 6h16M7 12h10m-7 6h4"/>', back: '<path d="M20 12H5m6-6-6 6 6 6"/>',
};
const icon = (name, cls = '') => `<svg class="icon ${cls}" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name] || icons.spark}</svg>`;
const escape = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[c]));
const standalone = Boolean(window.NEXORI_ART || window.NEXORI_OWNER_MODE);
const currentUrl = () => standalone
  ? new URL(location.hash.startsWith('#/') ? location.hash.slice(1) : '/', 'https://nexori.example')
  : new URL(location.href);
const pageHref = href => standalone ? `#${href}` : href;
const setPageUrl = (href, replace = false) => history[replace ? 'replaceState' : 'pushState']({}, '', pageHref(href));
const localRetailPhoto = p => p.status === 'retailer-preview' ? `/assets/${p.art}.${p.photoExtension || 'jpg'}` : '';
const assetUrl = name => window.NEXORI_ART?.[name] || optimizedArtwork[name]?.src || `/assets/${name}.${name === 'hero-banner' ? 'png' : 'svg'}`;
const featuredProducts = () => [...franchises.map(f=>products.find(p=>p.worldId===f.id&&p.category==='figures')),products.find(p=>p.worldId==='one-piece'&&p.category==='props'),products.find(p=>p.worldId==='naruto'&&p.category==='style')].filter(Boolean);
const homeCategoryProducts = category => [0,1].flatMap(index=>franchises.map(f=>products.filter(p=>p.worldId===f.id&&p.category===category)[index])).filter(Boolean).slice(0,8);
const storageKey = 'nexori.saved.v1';
const motionStorageKey = 'nexori.motion.v1';
let motionPaused = false;
try { motionPaused = localStorage.getItem(motionStorageKey) === 'reduce'; } catch {}
document.body.classList.toggle('motion-paused', motionPaused);
let saved = [];
try { const value = JSON.parse(localStorage.getItem(storageKey) || '[]'); if (Array.isArray(value)) saved = value.filter(id => products.some(p => p.id === id)); } catch {}
let filters = {...catalogDefaults};
let searchTrigger;
const contentAttrs = (kind,id) => `data-content-kind="${kind}" data-content-id="${id}"`;
const imageBackdrop = image => image ? `style="background-image:linear-gradient(135deg,#090810cf,#09081080),url('${escape(image)}');background-size:cover;background-position:center"` : '';
const linkedContentAttrs = (href,cls) => {
  const url=new URL(href,'https://nexori.example');
  if(cls.split(' ').includes('world-card')) return contentAttrs('worlds',url.pathname.split('/').at(-1));
  if(cls.split(' ').includes('category-card')) return contentAttrs('categories',url.searchParams.get('category'));
  if(cls.split(' ').includes('catalog-type-card')) return contentAttrs('types',url.searchParams.get('type'));
  return '';
};
const link = (href, text, cls = '', label = '') => `<a href="${pageHref(href)}" class="${cls}" ${linkedContentAttrs(href,cls)} ${cls.split(' ').includes('active') ? 'aria-current="page"' : ''} ${label ? `aria-label="${escape(label)}"` : ''} data-link>${text}</a>`;
const categoryName = id => categories.find(c => c.id === id)?.label || 'Collection';
const artwork = (product, cls = '', eager = false, sizes = '') => {
  const optimized = !product.image && !window.NEXORI_ART ? optimizedArtwork[product.art] : null;
  const responsive = optimized?.small ? `srcset="${optimized.small} ${optimized.smallWidth}w, ${optimized.src} ${optimized.width}w" sizes="${sizes || (eager ? '(max-width:700px) calc(100vw - 40px), 560px' : '(max-width:700px) calc((100vw - 53px) / 2), (max-width:1100px) 30vw, 300px')}"` : '';
  const alt = product.imageAlt || `${product.status === 'retailer-preview' ? 'Product photo' : product.image ? 'Image' : 'Original illustration'} of ${product.name || product.title}`;
  return `<img class="${cls}${product.status === 'retailer-preview' ? ' retail-photo' : ''}" src="${escape(product.image || window.NEXORI_ART?.[product.art] || optimized?.src || localRetailPhoto(product) || product.productPhoto || assetUrl(product.art))}" ${responsive} alt="${escape(alt)}" ${eager ? 'fetchpriority="high"' : 'loading="lazy"'} decoding="async" width="600" height="640" />`;
};
const blockArtwork = (id,fallback,cls='') => artwork({...fallback,image:contentBlocks[id].image || fallback.image,imageAlt:contentBlocks[id].imageAlt || fallback.imageAlt},cls);
const brand = () => `<a class="brand" href="${pageHref('/')}" aria-label="NEXORI home" data-link><img src="${assetUrl('mark')}" alt="" width="30" height="30"/><span>NEXORI<span class="brand-dot">.</span></span></a>`;

function header() {
  const active = currentUrl().pathname;
  return `<div class="announcement"><span>For the fans. For the collection.</span><span class="announcement-right">An independent anime discovery platform ${icon('spark')}</span></div>
  <header class="header"><div class="container header-inner">${brand()}
    <nav class="desktop-nav" aria-label="Main navigation">
      ${link('/collection', 'Explore collection', active.startsWith('/collection') || active.startsWith('/product') ? 'active' : '')}
      ${link('/worlds', 'Anime worlds', active.startsWith('/worlds') ? 'active' : '')}
      ${link('/guides', 'The journal', active.startsWith('/guides') ? 'active' : '')}
      ${link('/about', 'Our story', active === '/about' ? 'active' : '')}
    </nav>
    <div class="header-actions"><button class="icon-button" data-search aria-label="Search collection">${icon('search')}</button>${link('/saved', `${icon('heart')}<span class="saved-count" ${saved.length ? '' : 'hidden'}>${saved.length}</span>`, 'icon-button saved-link', 'Your saved finds')}
    <button class="icon-button menu-button" aria-label="Open navigation" aria-expanded="false" aria-controls="mobile-nav" data-menu>${icon('menu')}</button></div>
  </div><nav class="mobile-nav" id="mobile-nav" aria-label="Mobile navigation" hidden>${link('/collection', 'Explore collection', active.startsWith('/collection') || active.startsWith('/product') ? 'active' : '')}${link('/worlds', 'Anime worlds', active.startsWith('/worlds') ? 'active' : '')}${link('/guides', 'The journal', active.startsWith('/guides') ? 'active' : '')}${link('/about', 'Our story', active === '/about' ? 'active' : '')}${link('/saved', 'Your saved finds', active === '/saved' ? 'active' : '')}</nav></header>`;
}

function footer() {
  return `<footer class="footer"><div class="container footer-top"><div class="footer-brand">${brand()}<p>A little fandom. A lot of possibility.<br>Your next obsession starts here.</p><span class="footer-note">Made for the love of anime.</span></div>
  <div><h3>Discover</h3>${link('/collection', 'The collection')}${link('/worlds', 'Anime worlds')}${link('/guides', 'Buying guides')}${link('/saved', 'Saved finds')}</div>
  <div><h3>Get to know us</h3>${link('/about', 'Our story')}${link('/about#selection', 'How we select')}${link('/disclosure', 'Affiliate disclosure')}${link('/contact', 'Contact')}${link('/rights', 'Content & franchise references')}</div>
  <div class="footer-transparency"><span class="tiny-label">A NOTE ON TRANSPARENCY</span><p>This is a design preview with no active affiliate purchase links. When affiliate links are added, we may earn a commission from qualifying purchases.</p>${link('/disclosure', `Learn more ${icon('arrow')}`, 'text-link')}</div></div>
  <div class="container footer-bottom"><span>© ${new Date().getFullYear()} NEXORI</span><span>Independent. Fan-inspired. Thoughtfully selected.</span><div>${link('/privacy', 'Privacy')}${link('/terms', 'Terms')}${link('/accessibility', 'Accessibility')}${window.NEXORI_CLOUD_SITE ? link('/admin', 'Owner sign-in') : ''}</div><button class="motion-toggle" data-motion aria-pressed="${motionPaused}">Reduce visual motion <span aria-hidden="true">${motionPaused ? 'On' : 'Off'}</span></button></div></footer>`;
}

function collectionNotice() {
  return `<aside class="collection-notice"><div>${icon('shield')}<p><strong>Preview catalog.</strong> Prices may change. No active affiliate links. Image publication permissions are pending.</p></div><details><summary>About this preview</summary><p>${previewNotice}</p>${link('/rights', 'Artwork & references', 'policy-link')}</details></aside>`;
}

function floatingTools() {
  return `<nav id="floating-tools" class="floating-tools" aria-label="Quick actions" hidden>
    ${link('/saved', `${icon('heart')}<span class="floating-count saved-count" ${saved.length ? '' : 'hidden'}>${saved.length}</span><span class="floating-tooltip">Saved finds</span>`, 'floating-button floating-saved', 'Open your saved finds')}
    <button class="floating-button floating-surprise" data-surprise aria-label="Discover a surprise find">${icon('spark')}<span class="floating-tooltip">Surprise me</span></button>
    <button class="floating-button floating-top" data-top aria-label="Back to top">${icon('up')}<span class="floating-tooltip">Back to top</span></button>
  </nav>`;
}

function priceLabel(p) {
  return p.price ? `${p.priceFrom ? 'From ' : ''}${new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(Number(p.price))}` : 'Check price at retailer';
}
function retailerDetails(p) {
  return `<div class="retail-offer"><span class="tiny-label">${escape(p.retailer)}${p.seller && p.seller !== p.retailer ? ' · '+escape(p.seller) : ''}</span><p class="retail-price">${escape(priceLabel(p))}</p><p class="retail-price-note">Observed ${escape(p.priceCheckedOn || 'date not recorded')}. USD, before shipping and tax. Prices and availability can change.</p>${p.variantNote ? `<p class="retail-variant">${escape(p.variantNote)}</p>` : ''}<a class="button button-primary" href="${escape(p.sourceUrl)}" target="_blank" rel="noopener noreferrer">View listing at ${escape(p.retailer)} ${icon('external')}</a><p class="retail-price-note">Regular retailer link; no affiliate commission is active. Research selection, not a hands-on review.</p></div>`;
}
function productCard(p) {
  const isSaved = saved.includes(p.id);
  return `<article class="product-card" ${contentAttrs('products',p.id)}><div class="product-art" style="--art-color:${p.color}">${link(`/product/${p.id}`, artwork(p), 'art-link')}<span class="concept-badge">${p.status === 'retailer-preview' ? 'RETAILER PICK' : 'CONCEPT'}</span><button class="save-button ${isSaved ? 'is-saved' : ''}" data-save="${p.id}" aria-label="${isSaved ? 'Unsave' : 'Save'} ${escape(p.name)}" aria-pressed="${isSaved}">${icon('heart')}</button></div>
  <div class="product-card-info"><span class="tiny-label">${escape(p.type)}${p.retailer ? ' · '+escape(p.retailer) : ''}</span><h3>${link(`/product/${p.id}`, escape(p.name))}</h3><div class="product-card-bottom"><span>${p.status === 'retailer-preview' ? priceLabel(p) : escape(categoryName(p.category))}</span>${link(`/product/${p.id}`, `Details ${icon('arrow')}`, 'card-arrow card-details', `View ${p.name}`)}</div></div></article>`;
}
function guideCard(g) {
  return `<article class="guide-card" ${contentAttrs('guides',g.id)}>${link(`/guides/${g.id}`, `${artwork(g)}<span class="guide-art-label">NEXORI / JOURNAL</span>`, 'guide-art')}<div class="guide-card-content"><div class="guide-meta"><span>${escape(g.eyebrow)}</span><span>${escape(g.time)}</span></div><h3>${link(`/guides/${g.id}`, escape(g.title))}</h3><p>${escape(g.description)}</p>${link(`/guides/${g.id}`, `Read the story ${icon('arrow')}`, 'text-link')}</div></article>`;
}
function sectionHeading(eyebrow, title, subtitle, href, cta) {
  return `<div class="section-heading"><div><span class="eyebrow">${escape(eyebrow)}</span><h2>${title}</h2>${subtitle ? `<p>${subtitle}</p>` : ''}</div>${href ? link(href, `${cta} ${icon('arrow')}`, 'text-link') : ''}</div>`;
}
function worldsGrid() {
  return `<div class="worlds-grid">${franchises.map(f => link(`/worlds/${f.id}`, `<span class="world-symbol" style="--world-color:${f.color}" aria-hidden="true">${f.symbol}</span><div><h3>${escape(f.cardTitle || f.name)}</h3><p>${escape(f.subtitle)}</p></div>${icon('arrow')}`, 'world-card')).join('')}</div>`;
}

function bannerEffects() {
  return `<svg class="banner-effects" viewBox="0 0 1672 941" fill="none" aria-hidden="true">
    <defs>
      <filter id="blade-soft-light" x="-80%" y="-80%" width="260%" height="260%"><feGaussianBlur stdDeviation="12" /></filter>
      <linearGradient id="shard-face" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#443248"/><stop offset=".48" stop-color="#18121e"/><stop offset="1" stop-color="#070711"/></linearGradient>
      <linearGradient id="shard-edge"><stop stop-color="#dec0ff"/><stop offset=".5" stop-color="#8d4cb0"/><stop offset="1" stop-color="#35233d"/></linearGradient>
    </defs>
    <g class="blade-glow"><path d="M1320 476 1494 803" stroke="#cb82ff" stroke-width="19" stroke-linecap="round" filter="url(#blade-soft-light)"/><path d="M1320 476 1494 803" stroke="#eac5ff" stroke-opacity=".35" stroke-width="4" stroke-linecap="round"/></g>
    <g transform="translate(890 245)"><g class="floating-shard shard-one"><path d="m0-68 32 27-6 71-22 55-23-38-11-82Z" fill="url(#shard-face)" stroke="#775084" stroke-width="1.5"/><path d="m0-68 9 50-5 103 22-55 6-71Z" fill="#30213b"/><path d="m-30-35 30-33 9 50-23 32m23-32 23-23m-46 55 18 71" stroke="url(#shard-edge)" stroke-width="2"/><path d="m-12-31 15 16-7 23m18 7-8 22" stroke="#aa69c3" stroke-opacity=".5"/></g></g>
    <g transform="translate(1530 528)"><g class="floating-shard shard-two"><path d="m-31-42 43-14 22 43-11 59-40 14-22-55Z" fill="url(#shard-face)" stroke="#805884"/><path d="m12-56-9 58 20 44 11-59Z" fill="#39283e"/><path d="m-31-42 43-14-9 58-20 58m20-58 31-15" stroke="url(#shard-edge)" stroke-width="2"/></g></g>
    <g transform="translate(963 689)"><g class="floating-shard shard-three"><path d="m-18-27 31-13 25 19-15 43-35 20-17-41Z" fill="url(#shard-face)" stroke="#886995"/><path d="m13-40-6 39 16 23 15-43Z" fill="#382b43"/><path d="m-18-27 31-13-6 39-19 43m19-43 31-20" stroke="url(#shard-edge)" stroke-width="1.5"/></g></g>
  </svg>`;
}

function home() {
  return `<section class="hero cinematic-hero${contentBlocks.hero.image ? ' has-custom-banner' : ''}" ${contentAttrs('blocks','hero')}><div class="banner-scene"><img class="cinematic-background" src="${escape(contentBlocks.hero.image || assetUrl('hero-banner'))}" alt="${escape(contentBlocks.hero.imageAlt || 'Original anime artwork: a swordsman surrounded by a violet halo, floating temples, and cherry blossoms')}" width="1672" height="941" fetchpriority="high" />${contentBlocks.hero.image ? '' : bannerEffects()}</div><div class="cinematic-shade" aria-hidden="true"></div><div class="hero-grain" aria-hidden="true"></div><div class="ambient-sparks" aria-hidden="true"><span>✧</span><span>✦</span><span>✧</span></div><div class="container hero-inner"><div class="hero-copy"><span class="hero-eyebrow"><span></span> A WORLD WORTH COLLECTING</span><h1 class="neon-title">${escape(contentBlocks.hero.lead)} <br><em>${escape(contentBlocks.hero.accent)}</em> <br><span>${escape(contentBlocks.hero.ending)}</span></h1><p>${escape(contentBlocks.hero.description).replace(/\n/g,'<br>')}</p><div class="hero-buttons">${link('/collection', `Explore the collection ${icon('arrow')}`, 'button button-primary')}${link('/guides', `${icon('book')} Find your inspiration`, 'button button-secondary')}</div><div class="hero-footnote"><span class="small-stars">✧</span> Your fandom. Thoughtfully found.</div></div><div class="cinematic-art-label"><span class="art-label-cross" aria-hidden="true">✦</span><div><span class="tiny-label">THE NEXORI UNIVERSE</span><strong>Beyond the ordinary.</strong><span>Original artwork / Chapter 01</span></div></div><div class="hero-coordinate" aria-hidden="true">N / 001 <span>DISCOVER YOUR WORLD</span></div></div>
  </section>
  <section class="anime-ribbon" aria-label="Anime worlds"><div class="anime-ribbon-window"><div class="anime-ribbon-track">${[false,true].map(duplicate => `<div class="anime-ribbon-set"${duplicate ? ' aria-hidden="true"' : ''}>${franchises.map(world => `<span>${escape(world.name)} <b aria-hidden="true">✦</b></span>`).join('')}</div>`).join('')}</div></div><button class="ribbon-motion" data-motion aria-pressed="${motionPaused}">Reduce motion <span aria-hidden="true">${motionPaused ? 'On' : 'Off'}</span></button></section>
  <section class="trust-strip container" aria-label="Our approach"><div>${icon('spark')}<span>Independent editorial picks</span></div><div>${icon('shield')}<span>Transparency comes first</span></div><div>${icon('heart')}<span>Made with fans in mind</span></div></section>
  <section class="section container worlds-section">${sectionHeading('FIND YOUR UNIVERSE', 'Browse by anime.', 'Start with the stories you love.', '/worlds', 'All anime worlds')}${worldsGrid()}</section>
  <section class="section container collection-edit">${sectionHeading('CURATED FOR YOUR FANDOM', 'Featured finds.', 'Anime collectibles, cosplay props and everyday finds across your favorite worlds.', '/collection', 'Browse all categories')}${collectionNotice()}<div class="edit-controls"><div class="edit-tabs" role="group" aria-label="Choose your collection inspiration"><button class="edit-tab selected" data-edit="all" aria-pressed="true">Featured finds</button>${categories.map(c => `<button class="edit-tab" data-edit="${c.id}" aria-pressed="false">${escape(c.short)}</button>`).join('')}</div><button class="surprise-button" data-surprise>${icon('spark')} Surprise me</button></div><p id="edit-status" class="sr-only" role="status"></p><div class="product-grid" id="home-edit-grid">${featuredProducts().map(productCard).join('')}</div><div class="home-collection-link">${link('/collection', `Explore all ${products.length} finds ${icon('arrow')}`, 'button button-secondary')}</div></section>
  <section class="section container categories-section">${sectionHeading('MAKE IT YOURS', 'Browse categories.', 'From shelf-worthy figures to your next cosplay.', '/collection', 'All categories')}<div class="category-grid">${categories.map(c=>categoryCard(c)).join('')}</div></section>
  <section class="editorial-banner container" ${contentAttrs('blocks','editorial')}><div class="editorial-art">${blockArtwork('editorial',products.find(p=>p.id==='midnight-ronin'))}<span class="editorial-art-word" aria-hidden="true">COLLECT.</span></div><div class="editorial-copy"><span class="eyebrow">LESS GUESSWORK. MORE GOOD FINDS.</span><h2>${escape(contentBlocks.editorial.title).replace(/\n/g,'<br>')}</h2><p>${escape(contentBlocks.editorial.description)}</p>${link('/guides/first-figure', `Read the collector’s guide ${icon('arrow')}`, 'button button-primary')}<span class="editorial-bottom">THE NEXORI JOURNAL <span> / </span> 4 MIN READ</span></div></section>
  <section class="after-hours container" ${contentAttrs('blocks','afterhours')}><div class="after-hours-copy"><span class="eyebrow">THE AFTER-HOURS EDIT</span><h2>${contentBlocks.afterhours.title === 'Make room\nfor your world.' ? 'Make room<br>for <em>your world.</em>' : escape(contentBlocks.afterhours.title).replace(/\n/g,'<br>')}</h2><p>${escape(contentBlocks.afterhours.description)}</p>${link('/collection?category=desk', `Discover desk & room ${icon('arrow')}`, 'button button-secondary')}<span class="after-hours-note">SPACE INSPIRATION / ORIGINAL CONCEPTS</span></div><div class="setup-scene"><div class="setup-orb" aria-hidden="true"></div>${blockArtwork('afterhours',products.find(p=>p.id==='after-hours-desk'),'setup-mat')}<span class="setup-caption"><span class="live-dot" aria-hidden="true"></span> PERSONAL SPACE. MAIN-CHARACTER ENERGY.</span><span class="setup-star" aria-hidden="true">✧</span></div></section>
  <section class="section container">${sectionHeading('THE NEXORI JOURNAL', 'A good collection starts with a good story.', 'Ideas, practical guides, and a little inspiration for your next find.', '/guides', 'Visit the journal')}<div class="guides-grid">${guides.map(guideCard).join('')}</div></section>
  <section class="closing-card container" ${contentAttrs('blocks','closing')} ${imageBackdrop(contentBlocks.closing.image)}><span class="closing-spark" aria-hidden="true">✦</span><span class="eyebrow">YOUR FANDOM DOESN’T NEED A REASON.</span><h2>${escape(contentBlocks.closing.title)}</h2><p>${escape(contentBlocks.closing.description)}</p>${link('/saved', `Your saved finds ${icon('heart')}`, 'button button-secondary')}<span class="closing-watermark" aria-hidden="true">NEXORI</span></section>`;
}

function pageIntro(eyebrow, title, description) {
  return `<div class="page-intro"><span class="eyebrow">${escape(eyebrow)}</span><h1>${escape(title)}</h1><p>${escape(description)}</p></div>`;
}
function categoryCard(c, world = 'all', extraClass = '') {
  return link(catalogHref({category:c.id,world}), `<div class="category-photo" aria-hidden="true"><span class="category-photo-icon">${icon(c.icon)}</span></div><div class="category-copy"><h3>${escape(c.label)}</h3><p>${escape(c.description)}</p><span class="category-link">Browse ${icon('arrow')}</span></div>`, `category-card category-tile ${extraClass}`);
}
function catalogCategoryCards(world = 'all') {
  return `<div class="catalog-category-grid">${categories.map(c=>categoryCard(c,world,'catalog-category-card')).join('')}</div>`;
}
function catalogContext() {
  const category = categories.find(c => c.id === filters.category);
  const world = catalogWorlds.find(w => w.id === filters.world);
  const type = catalogTypes.find(t => t.id === filters.type);
  const title = [world?.name,type?.name || category?.label].filter(Boolean).join(' · ') || 'The collection.';
  const description = category ? `${category.description}${world ? ` Browse this category for ${world.name}.` : ' Choose an anime world to narrow your selection.'}` : 'Browse by product category, then choose an anime world and a product type. Browse retailer selections and clearly labelled original concepts.';
  return pageIntro('A CLEAR PLACE FOR EVERY FIND', title, description);
}
function catalogPlan() {
  const category = categories.find(c => c.id === filters.category);
  const world = catalogWorlds.find(w => w.id === filters.world);
  if (!category) return `<section class="catalog-plan" aria-labelledby="catalog-plan-title"><h2 id="catalog-plan-title">Browse by product category</h2><p>Each category has its own product types. Anime worlds are a separate filter.</p>${catalogCategoryCards(filters.world)}</section>`;
  return `<section class="catalog-plan" aria-labelledby="catalog-plan-title"><h2 id="catalog-plan-title">What belongs in ${escape(category.label.toLowerCase())}?</h2><p>${world && world.id !== 'original' ? `Explore ${escape(category.label.toLowerCase())} for ${escape(world.name)} by product type.` : 'Choose a product type to narrow the collection. Some combinations may not have listings yet.'}</p><div class="catalog-type-grid">${category.types.map(t => link(catalogHref({category:category.id,world:filters.world,type:t.id}), `<h3>${escape(t.name)}</h3><p>${escape(t.examples)}</p><span class="category-link">Browse this type ${icon('arrow')}</span>`, `catalog-type-card${filters.type === t.id ? ' active' : ''}`)).join('')}</div></section>`;
}
function typeOptions() {
  return `<option value="all">All product types</option>${catalogTypes.filter(t => filters.category === 'all' || t.category === filters.category).map(t => `<option value="${t.id}" ${filters.type === t.id ? 'selected' : ''}>${escape(t.name)}</option>`).join('')}`;
}
function collection() {
  filters = readCatalogFilters(currentUrl().searchParams);
  return `<div class="container page-container"><div id="catalog-context">${catalogContext()}</div>${collectionNotice()}<div id="catalog-plan">${catalogPlan()}</div><section class="catalog-browser" aria-labelledby="catalog-browser-title"><div class="catalog-browser-heading"><h2 id="catalog-browser-title">Browse the collection</h2><p>Combine a category, an anime world and a product type.</p></div><div class="collection-toolbar"><div class="filter-tabs" role="group" aria-label="Product category"><button data-category="all" class="filter-tab ${filters.category === 'all' ? 'selected' : ''}" aria-pressed="${filters.category === 'all'}">All finds</button>${categories.map(c => `<button data-category="${c.id}" class="filter-tab ${filters.category === c.id ? 'selected' : ''}" aria-pressed="${filters.category === c.id}">${escape(c.short)}</button>`).join('')}</div><div class="collection-controls"><label class="collection-search">${icon('search')}<input id="collection-search" type="search" placeholder="Search the collection" aria-label="Search the collection" value="${escape(filters.query)}" maxlength="100" /></label><label class="catalog-select"><span>Anime world</span><select id="collection-world"><option value="all">All worlds</option>${catalogWorlds.map(w => `<option value="${w.id}" ${filters.world === w.id ? 'selected' : ''}>${w.name}</option>`).join('')}</select></label><label class="catalog-select"><span>Product type</span><select id="collection-type">${typeOptions()}</select></label><label class="catalog-select"><span>Sort finds</span><select id="collection-sort"><option value="featured" ${filters.sort === 'featured' ? 'selected' : ''}>Editorial order</option><option value="az" ${filters.sort === 'az' ? 'selected' : ''}>Name: A–Z</option></select></label></div></div><div class="collection-result-bar"><p id="result-count" role="status"></p><button class="catalog-reset" data-reset>Clear filters</button></div><div id="collection-grid" class="product-grid"></div></section></div>`;
}
function updateCollection() {
  const grid = document.querySelector('#collection-grid'); if (!grid) return;
  const matches = selectCatalogProducts(products,filters);
  const category = categories.find(c => c.id === filters.category);
  const world = catalogWorlds.find(w => w.id === filters.world);
  const type = catalogTypes.find(t => t.id === filters.type);
  const selection = [world?.name,type?.name || category?.label].filter(Boolean).join(' · ');
  const searching = Boolean(filters.query.trim());
  const emptyTitle = searching ? 'No finds match just yet.' : 'This part of the collection is being prepared.';
  const emptyDescription = searching ? 'Try another search or clear your filters.' : `No ${selection ? `${escape(selection)} ` : ''}listings have been added. ${world && world.id !== 'original' ? 'Original concepts are kept separate from anime merchandise.' : 'The category structure is ready for future product selections.'}`;
  grid.innerHTML = matches.length ? matches.map(productCard).join('') : `<div class="empty-state">${icon('search')}<h2>${emptyTitle}</h2><p>${emptyDescription}</p>${link(catalogHref({category:filters.category}), 'Browse this category across all worlds', 'text-link')}${link('/guides/buying-safely', 'Read the buying checklist', 'text-link')}</div>`;
  applyCardBackgrounds();
  document.dispatchEvent(new Event('nexori:render'));
  document.querySelector('#result-count').textContent = `${matches.length} ${matches.length === 1 ? 'find' : 'finds'}${selection ? ` · ${selection}` : ''}`;
}
function refreshCatalogStructure() {
  document.querySelector('#catalog-context').innerHTML = catalogContext();
  document.title = `NEXORI — ${document.querySelector('#catalog-context h1').textContent}`;
  document.querySelector('#catalog-plan').innerHTML = catalogPlan();
  document.querySelector('#collection-type').innerHTML = typeOptions();
  applyCardBackgrounds();
  document.dispatchEvent(new Event('nexori:render'));
  document.querySelectorAll('[data-category]').forEach(btn => { const selected = btn.dataset.category === filters.category; btn.classList.toggle('selected',selected); btn.setAttribute('aria-pressed',String(selected)); });
}
function syncCatalogUrl(replace = false) {
  const href = catalogHref(filters);
  if (currentUrl().pathname + currentUrl().search !== href) setPageUrl(href,replace);
}
function savedPage() {
  const matches = products.filter(p => saved.includes(p.id));
  return `<div class="container page-container">${pageIntro('A LITTLE INSPIRATION, KEPT CLOSE', 'Your saved finds.', 'Your ideas, all in one place. Saved on this browser — no account needed.')}<div class="product-grid">${matches.length ? matches.map(productCard).join('') : `<div class="empty-state">${icon('heart')}<h2>Something will catch your eye.</h2><p>Tap the heart on any concept to keep it here for later.</p>${link('/collection', `Explore the collection ${icon('arrow')}`, 'button button-primary')}</div>`}</div></div>`;
}
function breadcrumb(label, href = '/collection', parent = 'Collection') {
  return `<nav class="breadcrumb" aria-label="Breadcrumb">${link('/', 'Home')}<span>/</span>${link(href, parent)}<span>/</span><span aria-current="page">${escape(label)}</span></nav>`;
}
function productPage(id) {
  const p = products.find(p => p.id === id); if (!p) return notFound();
  return `<div class="container page-container">${breadcrumb(p.name, catalogHref({category:p.category}), escape(categoryName(p.category)))}<div class="product-detail" ${contentAttrs('products',p.id)}><div class="detail-art">${artwork(p, '', true)}<span class="concept-badge">${p.status === 'retailer-preview' ? 'RETAILER PRODUCT PHOTO' : 'ORIGINAL CONCEPT ILLUSTRATION'}</span></div><div class="detail-info"><span class="eyebrow">${escape(p.type.toUpperCase())}</span><h1>${escape(p.name)}</h1><p class="detail-description">${escape(p.description)}</p>${p.status === 'retailer-preview' ? retailerDetails(p) : `<div class="concept-notice">${icon('spark')}<div><strong>A direction, not a product listing.</strong><p>${previewNotice}</p></div></div>`}<nav class="product-placement" aria-label="Product classification">${link(catalogHref({category:p.category}), escape(categoryName(p.category)))}${link(catalogHref({category:p.category,type:p.typeId}), escape(catalogTypes.find(t => t.id === p.typeId)?.name || p.type))}${link(catalogHref({world:p.worldId}), catalogWorlds.find(w => w.id === p.worldId)?.name || p.series)}</nav><button class="button button-secondary detail-save" data-save="${p.id}" aria-pressed="${saved.includes(p.id)}">${icon('heart')} ${saved.includes(p.id) ? 'Saved to your finds' : 'Save this inspiration'}</button><p class="detail-storage">Your saved finds stay on this browser.</p><div class="detail-checklist"><h2>${p.status === 'retailer-preview' ? 'Before you order' : 'When choosing a similar piece'}</h2><ul>${p.tips.map(t => `<li>${icon('check')} ${escape(t)}</li>`).join('')}</ul></div>${link('/about#selection', `How NEXORI selects products ${icon('arrow')}`, 'text-link')}</div></div><section class="related-section">${sectionHeading('KEEP EXPLORING', 'More from this anime.', '', '/collection', 'See the collection')}<div class="product-grid">${products.filter(x=>x.id!==id&&x.worldId===p.worldId).sort((a,b)=>Number(b.category===p.category)-Number(a.category===p.category)).slice(0,4).map(productCard).join('')}</div></section></div>`;
}
function worldsPage(id) {
  if (!id) return `<div class="container page-container">${pageIntro('FOR THE STORIES YOU LOVE', 'Find your universe.', 'Choose an anime world to explore figures, apparel, desk pieces, cosplay props and accessories.')}${worldsGrid()}<p class="muted world-disclaimer">${franchiseNotice}</p></div>`;
  const f = contentRecord('worlds',id); if (!f) return notFound();
  const picks=products.filter(p=>p.worldId===id);
  const available=categories.filter(c=>picks.some(p=>p.category===c.id));
  return `<div class="container page-container">${breadcrumb(f.name, '/worlds', 'Anime worlds')}<div class="franchise-banner" ${contentAttrs('worlds',f.id)} data-content-scope="page" style="--world-color:${f.color}"><span class="world-symbol" aria-hidden="true">${f.symbol}</span>${pageIntro('YOUR ANIME WORLD', f.pageTitle, f.pageDescription)}</div>
    ${picks.length ? `<div class="filter-tabs world-category-links" aria-label="Browse ${escape(f.name)} categories">${available.map(c=>link(catalogHref({world:id,category:c.id}),escape(c.short),'filter-tab')).join('')}</div>${available.map(c=>`<section class="related-section world-products" aria-labelledby="world-category-${c.id}"><div class="section-heading"><h2 id="world-category-${c.id}">${escape(c.label)}</h2>${link(catalogHref({world:id,category:c.id}),'Browse category '+icon('arrow'),'text-link')}</div><div class="product-grid">${picks.filter(p=>p.category===c.id).map(productCard).join('')}</div></section>`).join('')}` : `<div class="empty-state"><h2>This world’s selection is being prepared.</h2>${link('/collection','Explore the collection','button button-secondary')}</div>`}
    <div class="world-browse-actions">${link(catalogHref({world:id}),`Browse all ${escape(f.name)} finds ${icon('arrow')}`,'button button-secondary')}</div><p class="muted world-disclaimer">${franchiseNotice}</p></div>`;
}
function guidesPage(id) {
  if (!id) return `<div class="container page-container">${pageIntro('A LITTLE KNOW-HOW. A LOT OF FANDOM.', 'The NEXORI journal.', 'Practical guides for thoughtful collecting, better spaces, and finding your own kind of fandom.')}<div class="guides-grid">${guides.map(guideCard).join('')}</div></div>`;
  const g = guides.find(x => x.id === id); if (!g) return notFound();
  return `<div class="container page-container">${breadcrumb(g.title, '/guides', 'The journal')}<article class="article" ${contentAttrs('guides',g.id)}><header><span class="eyebrow">${escape(g.eyebrow)}</span><h1>${escape(g.title)}</h1><p class="article-intro">${escape(g.description)}</p><div class="article-byline"><span class="author-mark">N</span><span>NEXORI Editorial</span><span>·</span><span>${escape(g.time)}</span></div></header><div class="article-art">${artwork(g, '', true)}<span>THE NEXORI JOURNAL</span></div><div class="article-body">${g.sections.map(([h,p],i) => `<section><span class="article-number">0${i+1}</span><h2>${h}</h2><p>${p}</p></section>`).join('')}<aside class="article-note">${icon('shield')}<p>These guides offer general shopping advice. Check the current product details, seller terms, and local requirements before making a purchase.</p></aside>${link('/guides', `${icon('back')} Back to the journal`, 'text-link')}</div></article></div>`;
}
function infoPage(name) {
  const p = info[name];
  return `<div class="container page-container info-page">${pageIntro(p.eyebrow, p.title, p.intro)}<p class="policy-date">Last updated: <time datetime="${policyDate}">10 October 2026</time></p><nav class="policy-nav" aria-label="Website information">${Object.entries(info).map(([id,page]) => link(`/${id}`, page.title.replace(/\.$/, ''), `policy-nav-link${id === name ? ' active' : ''}`)).join('')}</nav><div class="info-content">${p.sections.map(([h,t],i) => {const id=`${name}-${i}`,record=contentRecord('pages',id);return `<section ${contentAttrs('pages',id)}><h2>${escape(record.title)}</h2><p>${Object.hasOwn(contentDraft.changes.pages?.[id]||{},'description') ? escape(record.description).replace(/\n/g,'<br>') : t}</p></section>`;}).join('')}</div>${p.action === 'clear-saved' ? `<section class="privacy-actions"><h2>Your saved finds</h2><p>This removes the saved list from this browser. It does not change correspondence or information held by other services.</p><button class="button button-secondary" data-clear-saved>Clear saved finds</button><p class="privacy-action-status" role="status"></p></section>` : ''}${name !== 'contact' ? `<p class="policy-contact">Questions about this page? ${contactLink}</p>` : ''}</div>`;
}
function aboutCard(id,tag='article',iconName='spark') {
  const p=contentRecord('pages',id);
  return `<${tag} ${contentAttrs('pages',id)}>${icon(iconName)}<h3>${escape(p.title)}</h3><p>${escape(p.description)}</p></${tag}>`;
}
function about() {
  return `<div class="container page-container about-page">${pageIntro('FOR THE LOVE OF THE STORY', 'Fandom, thoughtfully found.', 'NEXORI is a place to discover the things that make your favorite stories part of everyday life.')}<div class="about-feature" ${contentAttrs('pages','about-story')}><span class="about-spark" aria-hidden="true">✦</span><div><span class="eyebrow">OUR STARTING POINT</span><h2>${escape(contentRecord('pages','about-story').title).replace(/\n/g,'<br>')}</h2><p>${escape(contentRecord('pages','about-story').description)}</p></div></div><div id="selection" class="about-principles"><h2>How we’ll select the collection.</h2><div class="category-grid">${aboutCard('about-research','article','search')}${aboutCard('about-explain','article','book')}${aboutCard('about-links','article','shield')}${aboutCard('about-honesty','article','heart')}</div></div><aside class="article-note">${icon('spark')}<p>NEXORI is currently taking shape. The first One Piece retailer selections are being prepared alongside clearly labelled original concepts. Retailer links are regular links; no affiliate commissions are active.</p></aside></div>`;
}
function notFound() { return `<div class="container page-container"><div class="empty-state">${icon('spark')}<span class="eyebrow">404 / A DIFFERENT UNIVERSE</span><h1>This page wandered off.</h1><p>Let’s get you back to something worth discovering.</p>${link('/', `Back to NEXORI ${icon('arrow')}`, 'button button-primary')}</div></div>`; }
function route() {
  const parts = currentUrl().pathname.split('/').filter(Boolean);
  let content, title;
  if (!parts.length) { content = home(); title = [contentBlocks.hero.lead,contentBlocks.hero.accent,contentBlocks.hero.ending].join(' '); }
  else if (parts[0] === 'collection' && parts.length === 1) { content = collection(); title = 'The collection'; }
  else if (parts[0] === 'saved' && parts.length === 1) { content = savedPage(); title = 'Your saved finds'; }
  else if (parts[0] === 'product' && parts.length === 2) { content = productPage(parts[1]); title = products.find(p => p.id === parts[1])?.name || 'Page not found'; }
  else if (parts[0] === 'worlds' && parts.length <= 2) { content = worldsPage(parts[1]); title = franchises.find(f => f.id === parts[1])?.pageTitle || franchises.find(f => f.id === parts[1])?.name || 'Anime worlds'; }
  else if (parts[0] === 'guides' && parts.length <= 2) { content = guidesPage(parts[1]); title = guides.find(g => g.id === parts[1])?.title || 'The journal'; }
  else if (parts[0] === 'about' && parts.length === 1) { content = about(); title = 'Our story'; }
  else if (parts[0] === 'admin' && parts.length === 1 && window.NEXORI_CLOUD_SITE) { content = '<div id="firebase-admin-page"><p class="admin-loading" lang="he">טוען את מסך הניהול…</p></div>'; title = 'Owner sign-in'; }
  else if (info[parts[0]] && parts.length === 1) { content = infoPage(parts[0]); title = info[parts[0]].title.replace(/\.$/, ''); }
  else { content = notFound(); title = 'Page not found'; }
  document.title = `NEXORI — ${title}`;
  document.querySelector('#app').innerHTML = `${header()}<main id="main" data-page="${escape(parts[0] || 'home')}" tabindex="-1">${content}</main>${footer()}${floatingTools()}<dialog id="search-dialog" class="search-dialog" aria-labelledby="search-title"><div class="search-dialog-header"><h2 id="search-title">Find your next obsession.</h2><button class="icon-button" data-close-search aria-label="Close search">${icon('close')}</button></div><label class="dialog-search-input">${icon('search')}<input id="global-search" type="search" placeholder="Try figures, hoodie, desk…" aria-label="Search the collection" maxlength="100" autocomplete="off" /></label><p class="search-hint">Search retailer picks and original concepts</p><div id="search-results" class="search-results" aria-live="polite"></div></dialog>`;
  updateCollection();
  if (parts[0] === 'collection' && parts.length === 1) document.title = `NEXORI — ${document.querySelector('#catalog-context h1').textContent}`;
  applyCardBackgrounds();
  alignBannerEffects();
  scheduleScrollEffects();
  document.dispatchEvent(new Event('nexori:render'));
  if (currentUrl().hash) requestAnimationFrame(() => document.getElementById(currentUrl().hash.slice(1))?.scrollIntoView());
}
function applyCardBackgrounds() {
  document.querySelectorAll('[data-content-kind]').forEach(node => {
    const record=contentRecord(node.dataset.contentKind,node.dataset.contentId);
    const image=node.dataset.contentKind === 'worlds' ? (node.dataset.contentScope === 'page' ? record?.pageImage : record?.cardImage) : record?.image;
    if(node.dataset.contentKind === 'categories' && node.querySelector('.category-photo')) {
      const photo=node.querySelector('.category-photo');
      photo.style.backgroundImage=image ? `url('${image}')` : '';
      photo.querySelector('.category-photo-icon').hidden=Boolean(image);
    } else if(image && ['categories','types','worlds','pages'].includes(node.dataset.contentKind)) {node.style.backgroundImage=`linear-gradient(135deg,#090810db,#09081088),url('${image}')`;node.style.backgroundSize='cover';node.style.backgroundPosition='center';}
  });
}
function navigate(href, push = true) {
  if (standalone && href.startsWith('#/')) href = href.slice(1);
  document.querySelector('#search-dialog')?.close();
  if (push) setPageUrl(href);
  route();
  if (!currentUrl().hash) window.scrollTo({top:0, behavior:'instant'});
  document.querySelector('#main').focus({preventScroll:true});
}
let toastTimer;
function toast(message) { const el = document.querySelector('#toast'); el.textContent = message; el.classList.add('visible'); clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('visible'), 2800); }
function toggleSaved(id) {
  if (!products.some(p => p.id === id)) return;
  const adding = !saved.includes(id);
  saved = adding ? [...saved,id] : saved.filter(x => x !== id);
  let persistent = true;
  try { localStorage.setItem(storageKey, JSON.stringify(saved)); } catch { persistent = false; }
  if (currentUrl().pathname === '/saved') { const pos=scrollY; route(); window.scrollTo(0,pos); }
  else {
    document.querySelectorAll(`[data-save="${id}"]`).forEach(btn => { btn.classList.toggle('is-saved', adding); btn.setAttribute('aria-pressed', String(adding)); if (btn.classList.contains('detail-save')) btn.innerHTML = `${icon('heart')} ${adding ? 'Saved to your finds' : 'Save this inspiration'}`; else btn.setAttribute('aria-label', `${adding ? 'Unsave' : 'Save'} ${products.find(p => p.id === id).name}`); });
    document.querySelectorAll('.saved-count').forEach(count => { count.textContent = saved.length; count.hidden = !saved.length; });
  }
  toast(adding ? persistent ? 'Saved to your finds.' : 'Saved for this visit. Browser storage is unavailable.' : 'Removed from your saved finds.');
}
function searchResults(query) {
  const matches = selectCatalogProducts(products,{...catalogDefaults,query});
  const visible = matches.slice(0,12);
  document.querySelector('#search-results').innerHTML = matches.length ? `<p class="search-hint">${matches.length} ${matches.length === 1 ? 'find' : 'finds'}${matches.length > visible.length ? ` · Showing ${visible.length}` : ''}</p>${visible.map(p => link(`/product/${p.id}`, `${artwork(p,'',false,'58px')}<div><strong>${escape(p.name)}</strong><span>${escape(p.type)} · ${p.status === 'retailer-preview' ? escape(p.retailer) : 'Concept'}</span></div>${icon('arrow')}`, 'search-result')).join('')}${matches.length > visible.length ? link(catalogHref({query}), `See all ${matches.length} finds ${icon('arrow')}`, 'text-link search-view-all') : ''}` : '<p class="search-no-results">No matching finds. Try another name, anime or product type.</p>';
}
document.addEventListener('click', e => {
  if (e.target.closest('.skip-link') && e.button === 0 && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey) {
    e.preventDefault();
    const main = document.querySelector('#main');
    main.focus({preventScroll:true});
    main.scrollIntoView({block:'start',behavior:'instant'});
    return;
  }
  const anchor = e.target.closest('a[data-link]');
  if (anchor && e.button === 0 && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey) { e.preventDefault(); navigate(anchor.getAttribute('href')); return; }
  const save = e.target.closest('[data-save]'); if (save) { toggleSaved(save.dataset.save); return; }
  if (e.target.closest('[data-clear-saved]')) {
    saved = [];
    let cleared = true;
    try { localStorage.removeItem(storageKey); } catch { cleared = false; }
    document.querySelectorAll('.saved-count').forEach(count => { count.textContent = '0'; count.hidden = true; });
    document.querySelector('.privacy-action-status').textContent = cleared ? 'Your saved finds have been cleared from this browser.' : 'Cleared for this visit. Browser storage could not be updated; clear this site’s data in your browser settings.';
    return;
  }
  if (e.target.closest('[data-motion]')) {
    motionPaused = !motionPaused;
    document.body.classList.toggle('motion-paused', motionPaused);
    document.querySelectorAll('[data-motion]').forEach(button => { button.setAttribute('aria-pressed',String(motionPaused)); button.querySelector('span').textContent = motionPaused ? 'On' : 'Off'; });
    let persistent = true;
    try { localStorage.setItem(motionStorageKey, motionPaused ? 'reduce' : 'allow'); } catch { persistent = false; }
    scheduleScrollEffects();
    toast(`Visual motion ${motionPaused ? 'reduced' : 'restored'}.${persistent ? '' : ' This preference could not be saved.'}`);
    return;
  }
  if (e.target.closest('[data-top]')) { window.scrollTo({top:0, behavior:reducedMotion.matches ? 'instant' : 'smooth'}); document.querySelector('#main').focus({preventScroll:true}); return; }
  if (e.target.closest('[data-surprise]')) { navigate(`/product/${products[Math.floor(Math.random() * products.length)].id}`); return; }
  const edit = e.target.closest('[data-edit]');
  if (edit) {
    const selection = edit.dataset.edit;
    const matches = selection === 'all' ? featuredProducts() : homeCategoryProducts(selection);
    document.querySelector('#home-edit-grid').innerHTML = matches.length ? matches.map(productCard).join('') : `<div class="empty-state"><h3>This category is being prepared.</h3><p>${escape(categories.find(c => c.id === selection)?.description || '')}</p>${link(catalogHref({category:selection}), 'Explore the planned product types', 'text-link')}</div>`;
    document.querySelectorAll('[data-edit]').forEach(btn => {const active = btn.dataset.edit === selection; btn.classList.toggle('selected',active); btn.setAttribute('aria-pressed',String(active));});
    applyCardBackgrounds();
    document.dispatchEvent(new Event('nexori:render'));
    document.querySelector('.home-collection-link').innerHTML = link(catalogHref(selection === 'all' ? {} : {category:selection}), `Explore all ${selection === 'all' ? products.length : products.filter(p=>p.category===selection).length} finds ${icon('arrow')}`, 'button button-secondary');
    document.querySelector('#edit-status').textContent = `Showing ${matches.length} ${matches.length === 1 ? 'find' : 'finds'}.`;
  }
  const menu = e.target.closest('[data-menu]'); if (menu) { const nav = document.querySelector('#mobile-nav'); nav.hidden = !nav.hidden; menu.setAttribute('aria-expanded', String(!nav.hidden)); menu.setAttribute('aria-label', nav.hidden ? 'Open navigation' : 'Close navigation'); menu.innerHTML = icon(nav.hidden ? 'menu' : 'close'); }
  if (e.target.closest('[data-search]')) { searchTrigger = e.target.closest('[data-search]'); const dialog = document.querySelector('#search-dialog'); searchResults(''); dialog.showModal(); document.querySelector('#global-search').focus(); }
  if (e.target.closest('[data-close-search]')) { document.querySelector('#search-dialog').close(); searchTrigger?.focus(); }
  if (e.target.id === 'search-dialog') { const rect = e.target.getBoundingClientRect(); if (e.clientX < rect.left || e.clientX > rect.right || e.clientY < rect.top || e.clientY > rect.bottom) e.target.close(); }
  const category = e.target.closest('[data-category]'); if (category) {
    filters.category = category.dataset.category;
    if (!catalogTypes.some(t => t.id === filters.type && (filters.category === 'all' || t.category === filters.category))) filters.type = 'all';
    syncCatalogUrl();
    refreshCatalogStructure();
    updateCollection();
  }
  if (e.target.closest('[data-reset]')) { filters = {...catalogDefaults}; navigate('/collection'); }
});
document.addEventListener('input', e => { if (e.target.id === 'global-search') searchResults(e.target.value); if (e.target.id === 'collection-search') {filters.query = e.target.value; syncCatalogUrl(true); updateCollection();} });
document.addEventListener('change', e => {
  if (e.target.id === 'collection-sort') { filters.sort = e.target.value; syncCatalogUrl(); updateCollection(); }
  if (e.target.id === 'collection-world' || e.target.id === 'collection-type') {
    filters[e.target.id === 'collection-world' ? 'world' : 'type'] = e.target.value;
    syncCatalogUrl();
    refreshCatalogStructure();
    updateCollection();
  }
});
document.addEventListener('keydown', e => {
  const dialog = document.querySelector('#search-dialog[open]');
  if (e.key === 'Tab' && dialog) {
    const focusable = [...dialog.querySelectorAll('a[href],button:not([disabled]),input:not([disabled]),[tabindex="0"]')].filter(element => element.getClientRects().length);
    const first = focusable[0], last = focusable.at(-1);
    if (e.shiftKey && (document.activeElement === first || !dialog.contains(document.activeElement))) { e.preventDefault(); last?.focus(); }
    else if (!e.shiftKey && (document.activeElement === last || !dialog.contains(document.activeElement))) { e.preventDefault(); first?.focus(); }
  }
  if (e.key === 'Escape') {const nav = document.querySelector('#mobile-nav'); if (!nav.hidden) document.querySelector('[data-menu]').click();}
});
document.addEventListener('close', e => { if (e.target.id === 'search-dialog' && searchTrigger?.isConnected) searchTrigger.focus(); }, true);
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
let scrollFrame;
function scheduleScrollEffects() {
  if (scrollFrame) return;
  scrollFrame = requestAnimationFrame(() => {
    scrollFrame = 0;
    const tools = document.querySelector('#floating-tools');
    if (tools) tools.hidden = window.scrollY < 420;
    const hero = document.querySelector('.cinematic-hero');
    if (!hero) return;
    const rect = hero.getBoundingClientRect();
    const mobile = window.innerWidth <= 700;
    const travel = reducedMotion.matches || motionPaused || hero.classList.contains('has-custom-banner') ? 0 : Math.min(mobile ? 620 : 280, Math.max(0, -rect.top) * (mobile ? .66 : .38));
    hero.style.setProperty('--banner-drift', `${travel}px`);
    hero.classList.toggle('is-carrying', travel > 0);
  });
}
function alignBannerEffects() {
  const scene = document.querySelector('.banner-scene');
  const image = scene?.querySelector('.cinematic-background');
  const effects = scene?.querySelector('.banner-effects');
  if (!scene || !image || !effects) return;
  const width = scene.clientWidth, height = scene.clientHeight;
  const scale = Math.max(width / 1672, height / 941);
  const [px, py] = getComputedStyle(image).objectPosition.split(' ').map(value => value === 'top' ? 0 : value === 'center' ? .5 : parseFloat(value) / 100);
  Object.assign(effects.style, {width:`${1672 * scale}px`,height:`${941 * scale}px`,left:`${(width - 1672 * scale) * px}px`,top:`${(height - 941 * scale) * py}px`});
}
window.addEventListener('scroll', scheduleScrollEffects, {passive:true});
window.addEventListener('resize', () => { alignBannerEffects(); scheduleScrollEffects(); }, {passive:true});
reducedMotion.addEventListener('change', scheduleScrollEffects);
window.addEventListener('popstate', () => {const url = currentUrl(); navigate(url.pathname+url.search+url.hash,false);});
window.addEventListener('nexori:content-update',()=>{const position=scrollY;route();scrollTo({top:position,behavior:'instant'});});
window.addEventListener('storage', e => {if (e.key !== storageKey) return; try {const value=JSON.parse(e.newValue || '[]'); saved=Array.isArray(value)?value.filter(id=>products.some(p=>p.id===id)):[];} catch {saved=[];} const pos=scrollY; route(); window.scrollTo(0,pos);});
route();

// Do not substitute unrelated concept art if a retailer photo is unavailable.
document.addEventListener('error', event => {
  const img=event.target;
  if(!(img instanceof HTMLImageElement) || !img.classList.contains('retail-photo'))return;
  img.hidden=true;
  const note=document.createElement('span');note.className='retail-photo-unavailable';note.textContent='Product photo unavailable — view the retailer listing';
  img.after(note);
},true);

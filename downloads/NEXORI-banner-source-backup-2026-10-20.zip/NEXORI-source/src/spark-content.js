import { validateContentDraft, contentGroups } from './content.js';

export const sparkImageLimit = 192 * 1024;
export const sparkPayloadLimit = 600 * 1024;
export const emptyContent = () => ({version:1,changes:{}});
// Small validation leaves feed immutable proof documents. The final write reads
// only the proofs, so a large catalogue stays within Firestore's rule limits.
export const validationChunks=Object.entries(contentGroups).flatMap(([group,{records}])=>{
  const size=group==='products'?8:21;
  return Array.from({length:Math.ceil(records.length/size)},(_,index)=>({group,id:`${group}-${index}`,ids:records.slice(index*size,(index+1)*size).map(record=>record.id)}));
});
export const schemaChunks=validationChunks;
const productChunks=validationChunks.filter(chunk=>chunk.group==='products');
const otherChunks=validationChunks.filter(chunk=>chunk.group!=='products');
export const receiptChunks=[...Array.from({length:Math.ceil(productChunks.length/8)},(_,index)=>({id:`products-proof-${index}`,chunks:productChunks.slice(index*8,(index+1)*8)})),{id:'other-proof-0',chunks:otherChunks}].map(receipt=>({...receipt,groups:[...new Set(receipt.chunks.map(chunk=>chunk.group))]}));
export function schemaChunkRecords(payload,chunk) {return payload.changes[chunk.group]??{};}
export function receiptRecords(payload,receipt) {return Object.fromEntries(receipt.groups.map(group=>[group,payload.changes[group]??{}]));}
export function sparkContent(input, uid, published = false) {
  const next = validateContentDraft(input, {spark:true,ownerUid:published?undefined:uid});
  if (new TextEncoder().encode(JSON.stringify(next)).length > sparkPayloadLimit) throw new Error('הטקסט בטיוטה גדול מדי. התמונות נשמרות בנפרד; קצר את התוכן.');
  for (const records of Object.values(next.changes)) for (const patch of Object.values(records)) for (const [field,value] of Object.entries(patch)) {
    if (/image$/i.test(field) && value && !value.startsWith('spark:')) throw new Error('יש לשמור את התמונה במערכת לפני שמירת הטיוטה.');
  }
  if (published && Object.values(next.changes.products||{}).some(patch=>'editorNotes' in patch || 'retailerUrl' in patch)) throw new Error('אין לכלול שדות פרטיים בתוכן המוצג למבקרים.');
  return next;
}
export function publicContent(input) {
  const next = structuredClone(input);
  for (const patch of Object.values(next.changes.products||{})) {delete patch.editorNotes;delete patch.retailerUrl;}
  return next;
}
export function imageEntries(payload) {
  return Object.entries(payload.changes).flatMap(([group,records])=>Object.entries(records).flatMap(([id,patch])=>Object.entries(patch).filter(([field,value])=>/image$/i.test(field)&&value).map(([field,value])=>({group,id,patch,field,value}))));
}
export function sparkImagePath(value) {
  if (/^spark:published\/[a-f0-9-]{36}\/[a-f0-9-]{36}$/.test(value)) return `publishedImages/${value.slice(16).split('/')[0]}/images/${value.split('/').at(-1)}`;
  if (/^spark:drafts\/[A-Za-z0-9_-]{1,128}\/[a-f0-9-]{36}$/.test(value)) return `draftImages/${value.split('/')[1]}/images/${value.split('/')[2]}`;
  throw new Error('הפניה לתמונה אינה תקינה.');
}

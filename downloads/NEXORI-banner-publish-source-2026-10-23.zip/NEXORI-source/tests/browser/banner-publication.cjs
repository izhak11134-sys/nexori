// Isolated Auth + Firestore emulator workflow. Never uses a production project.
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const assert=require('node:assert/strict');
const base=process.env.SITE_URL||'http://127.0.0.1:5194',project='demo-nexori';
async function json(url,body,method='POST',admin=false){const r=await fetch(url,{method,headers:{'Content-Type':'application/json',...(admin?{Authorization:'Bearer owner'}:{})},body:JSON.stringify(body)});if(!r.ok)throw new Error(await r.text());return r.json();}
(async()=>{
 const cleared=await fetch(`http://127.0.0.1:8080/emulator/v1/projects/${project}/databases/(default)/documents`,{method:'DELETE',headers:{Authorization:'Bearer owner'}});assert.equal(cleared.status,200);
 const email=`banner-${Date.now()}@nexori.test`,password='Banner-test-123!';
 const account=await json(`http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/accounts:signUp?key=demo-key`,{email,password,returnSecureToken:true});
 await json('http://127.0.0.1:9099/identitytoolkit.googleapis.com/v1/accounts:update',{localId:account.localId,emailVerified:true},'POST',true);
 await json(`http://127.0.0.1:8080/v1/projects/${project}/databases/(default)/documents/admins/${account.localId}`,{fields:{active:{booleanValue:true}}},'PATCH',true);
 const b=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const configure=async context=>{
  await context.route(/^https?:/,route=>['localhost','127.0.0.1'].includes(new URL(route.request().url()).hostname)?route.continue():route.abort());
  await context.route('**/src/firebase-config.js*',route=>route.fulfill({contentType:'application/javascript',body:`export function firebaseConfiguration(){return {apiKey:'demo-key',projectId:'${project}',authDomain:'${project}.firebaseapp.com',appId:'demo-banner-publication',useEmulators:true};}`}));
 };
 try{
  const context=await b.newContext({viewport:{width:1440,height:1000}});await configure(context);
  const p=await context.newPage(),errors=[];p.setDefaultTimeout(60000);p.on('pageerror',e=>errors.push(e.message));p.on('dialog',d=>d.accept());
  async function login(){await p.goto(base+'/admin');await p.locator('#admin-login-form').waitFor();await p.locator('[name=email]').fill(email);await p.locator('[name=password]').fill(password);await p.locator('#admin-login-form [type=submit]').click();try{await p.locator('.owner-toolbar').waitFor({timeout:20000});}catch(e){console.log('Login diagnostic:',await p.locator('#firebase-admin-page').innerText());throw e;}await p.locator('.header .brand').click();}
  async function image(color,w,h){return Buffer.from(await p.evaluate(({color,w,h})=>{const c=document.createElement('canvas');c.width=w;c.height=h;c.getContext('2d').fillStyle=color;c.getContext('2d').fillRect(0,0,w,h);return c.toDataURL('image/webp',.95).split(',')[1];},{color,w,h}),'base64');}
  async function edit(lead,buffer){await p.locator('.hero>.owner-edit-button').click();await p.locator('[name=lead]').fill(lead);if(buffer)await p.locator('[data-owner-image="image"]').setInputFiles({name:'banner.webp',mimeType:'image/webp',buffer});}
  async function logout(){await p.locator('[data-admin-logout]').click();await p.locator('.owner-toolbar').waitFor({state:'detached'});}
  await login();const eyes=await image('#b23cc9',700,194),dragon=await image('#2454d9',700,393);
  await edit('Published EYES',eyes);await p.getByRole('button',{name:'שמירה והצגה באתר',exact:true}).click();await p.locator('#owner-editor-dialog').waitFor({state:'hidden'});await p.locator('.owner-status').filter({hasText:'הגרסה הציבורית אומתה'}).waitFor();
  await logout();assert.match(await p.locator('h1').textContent(),/Published EYES/);
  console.log('PASS initial public banner confirmed and visible after logout');
  await login();await edit('Private DRAGON',dragon);await p.getByRole('button',{name:'שמירת טיוטה',exact:true}).click();await p.locator('#owner-editor-dialog').waitFor({state:'hidden'});
  assert.match(await p.locator('h1').textContent(),/Private DRAGON/);
  assert.equal(await p.evaluate(()=>JSON.parse(localStorage.getItem('nexori-public-hero-v1:demo-nexori:demo-banner-publication')).changes.blocks.hero.lead),'Published EYES');
  await logout();assert.match(await p.locator('h1').textContent(),/Published EYES/);
  console.log('PASS private dragon draft stays private and cannot replace visitor cache');
  await login();assert.match(await p.locator('h1').textContent(),/Private DRAGON/);await edit('Published DRAGON');
  await p.getByRole('button',{name:'שמירה והצגה באתר',exact:true}).click();await p.locator('#owner-editor-dialog').waitFor({state:'hidden'});await p.locator('.owner-status').filter({hasText:'הגרסה הציבורית אומתה'}).waitFor();
  await logout();assert.match(await p.locator('h1').textContent(),/Published DRAGON/);
  const state=await p.locator('.cinematic-background').evaluate(i=>({naturalWidth:i.naturalWidth,naturalHeight:i.naturalHeight,w:i.getBoundingClientRect().width,h:i.getBoundingClientRect().height}));assert.equal(state.naturalWidth,700);assert.equal(state.naturalHeight,393);assert(state.w>700&&state.w<=875.1);assert(Math.abs(state.w/state.h-700/393)<.01);
  assert.equal(await p.evaluate(()=>JSON.parse(localStorage.getItem('nexori-public-hero-v1:demo-nexori:demo-banner-publication')).changes.blocks.hero.lead),'Published DRAGON');
  await p.reload();await p.locator('.has-custom-banner .cinematic-background').waitFor();assert.match(await p.locator('h1').textContent(),/Published DRAGON/);
  const visitor=await b.newContext();await configure(visitor);const guest=await visitor.newPage();await guest.goto(base);await guest.waitForFunction(()=>document.querySelector('h1')?.textContent.includes('Published DRAGON'));assert.equal(await guest.locator('.cinematic-background').evaluate(i=>i.naturalWidth),700);assert.equal(await guest.locator('.owner-toolbar').count(),0);
  assert.deepEqual(errors,[]);console.log('PASS confirmed public dragon survives logout, reload, cache and a fresh anonymous browser; larger image preserves aspect ratio. Actual emulator rules and publication transaction used; no production writes.');
 }finally{await b.close()}
})().catch(e=>{console.error(e);process.exit(1)});

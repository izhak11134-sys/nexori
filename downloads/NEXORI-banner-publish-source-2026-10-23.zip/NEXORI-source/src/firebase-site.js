import { firebaseConfiguration } from './firebase-config.js';
import { applyContentDraft } from './content.js';
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let hasPublicDisplay=false;
let service=null,user=null,authorized=false,authReady=false,authGeneration=0,editor=null,publicPayload={version:1,changes:{}},busy=false,connectionError='',adminFailure=null;
function updateSite(payload,preserveLogin=false){
  applyContentDraft(payload,{bucket:service?.bucket});
  // A late public snapshot must not clear credentials while the owner types.
  if(preserveLogin&&document.querySelector('#admin-login-form'))return;
  window.dispatchEvent(new Event('nexori:content-update'));
}
async function acceptRelease(release) {
  const display=release?.display??await service.published();
  validatePublic(display);publicPayload=display;hasPublicDisplay=true;
  if(!editor)updateSite(display,true);
  document.documentElement.classList.remove('nexori-public-pending');
}
function panel() {
  const host=document.querySelector('#firebase-admin-page');if(!host)return;
  let body;
  if(!firebaseConfiguration())body='<h1>ניהול NEXORI</h1><p>מסך הניהול מוכן לחיבור, אך עדיין לא חיברנו פרויקט Firebase שלך. האתר מציג כרגע את התוכן המקורי.</p><p>ניצור יחד חשבון ופרויקט ונגדיר אותם בסביבת הפיתוח. אין צורך להוריד קובץ עריכה נפרד.</p>';
  else if(connectionError)body=`<h1>לא ניתן להתחבר לניהול</h1><p role="alert">${escape(connectionError)}</p><button type="button" data-admin-retry>ניסיון נוסף</button>`;
  else if(!authReady)body='<h1>ניהול NEXORI</h1><p role="status">בודק התחברות והרשאות…</p>';
  else if(!user)body='<h1>כניסה לניהול NEXORI</h1><p>התחבר לחשבון המנהל שלך כדי לערוך את האתר במקום.</p><form id="admin-login-form"><label>כתובת דוא״ל<input name="email" type="email" required autocomplete="username" maxlength="254"></label><label>סיסמה<input name="password" type="password" required autocomplete="current-password" maxlength="256"></label><button type="submit">כניסה לניהול</button><button type="button" data-admin-reset>איפוס סיסמה</button></form>';
  else if(adminFailure)body=`<h1>${adminFailure.stage==='role'?'לא ניתן לאשר את הרשאת המנהל':'לא ניתן לטעון את מערכת הניהול'}</h1><p>${escape(user.email)}</p><p role="alert">${escape(adminFailure.detail)}</p>${adminFailure.code?`<p>קוד התקלה: <code dir="ltr">${escape(adminFailure.code)}</code></p>`:''}<button type="button" data-admin-retry>בדיקה מחדש</button><button type="button" data-admin-logout>התנתקות</button>`;
  else if(!authorized)body=`<h1>החשבון אינו מורשה לעריכה</h1><p>${escape(user.email)}${!user.emailVerified?' — יש לאמת את הדוא״ל ולהיכנס שוב.':' — יש להגדיר לחשבון הרשאת מנהל ב־Firebase Console.'}</p>${!user.emailVerified?'<button type="button" data-admin-verify>שליחת הודעת אימות</button>':''}<button type="button" data-admin-logout>התנתקות</button>`;
  else body='<h1>מצב עריכה פעיל</h1><p>אפשר לעבור לכל עמוד באתר וללחוץ על ״עריכה״ ליד הכרטיסייה. שינוי כותרת ותמונה נעשה בשדות נפרדים.</p><p>״שמירת טיוטה״ שומרת ב־Firebase. ״החלת השינויים באתר״ מעדכנת את הגרסה המוצגת למבקרים. אפשר לשחזר גרסה קודמת מסרגל העריכה.</p><a href="/" data-link>מעבר לאתר ולכפתורי העריכה</a><button type="button" data-admin-logout>התנתקות</button>';
  const details=user&&authReady&&!authorized?`<details class="admin-connection-details" open><summary>פרטי החיבור לבדיקת ההרשאה</summary><dl><dt>פרויקט Firebase</dt><dd><code dir="ltr">${escape(firebaseConfiguration()?.projectId)}</code></dd><dt>מזהה המשתמש (UID)</dt><dd><code dir="ltr">${escape(user.uid)}</code></dd><dt>מסמך ההרשאה במסד (default)</dt><dd><code dir="ltr">admins/${escape(user.uid)}</code></dd></dl></details>`:'';
  const project=firebaseConfiguration()?.projectId;
  host.innerHTML=`<section class="admin-panel" lang="he" dir="rtl">${body}${project?`<p class="admin-project">פרויקט מוגדר: <code dir="ltr">${escape(project)}</code></p>`:''}${details}<p class="admin-status" role="status"></p></section>`;
  host.querySelectorAll('button').forEach(button=>button.disabled=busy);
}
function status(message){const target=document.querySelector('.admin-status');if(target)target.textContent=message;}
function message(error){
  if(error.code?.includes('aborted'))return 'הטיוטה או הגרסה באתר השתנתה ממכשיר אחר. הורד גיבוי של העבודה שלך, ואז רענן לפני המשך העריכה.';
  if(/invalid-credential|wrong-password|user-not-found/.test(error.code||''))return 'לא ניתן להתחבר עם הפרטים האלה. בדוק את הדוא״ל והסיסמה.';
  if(/too-many-requests/.test(error.code||''))return 'בוצעו ניסיונות רבים מדי. נסה שוב מאוחר יותר.';
  if(/network|unavailable/.test(error.code||''))return 'לא ניתן להשלים את הפעולה כרגע. בדוק את החיבור ונסה שוב.';
  if(/unauthenticated/.test(error.code||''))return 'ההתחברות אינה בתוקף. התחבר מחדש לחשבון המנהל.';
  if(/permission-denied/.test(error.code||''))return `Firestore חסם את הפעולה. יש לבדוק את הרשאת המנהל ואת כללי הגישה בפרויקט ${firebaseConfiguration()?.projectId || ''}. קוד: ${error.code}`;
  return error.message||'הפעולה לא הושלמה.';
}
async function enterEditor(generation) {
  const draft=await service.loadDraft();if(generation!==authGeneration)return;
  const {mountOwnerEditor}=await import('./owner-editor.js');await import('./owner-editor.css');if(generation!==authGeneration)return;
  updateSite(draft);document.documentElement.classList.remove('nexori-public-pending');
  editor=mountOwnerEditor({bucket:service.bucket,imageNote:service.imageNote,save:input=>service.save(input),
    saveAndPublish:async input=>{const release=await service.saveAndPublish(input);if(generation!==authGeneration)return;await acceptRelease(release);await revisions();return release.draft;},
    backup:input=>service.backup(input),error:error=>error.draftSaved?'הטיוטה נשמרה, אך ההצגה למבקרים לא אושרה. '+message(error):message(error)});
  const toolbar=document.querySelector('.owner-toolbar');toolbar.classList.add('owner-cloud-toolbar');
  toolbar.querySelector('[data-owner-export]').hidden=true;
  toolbar.querySelector('[data-owner-import]').hidden=true;
  toolbar.querySelector('[data-owner-preview]').textContent='תצוגת הטיוטה';
  const controls=document.createElement('div');controls.className='owner-cloud-actions';
  controls.innerHTML='<button type="button" data-cloud-publish>החלת השינויים באתר</button><button type="button" data-cloud-load-public>טעינת הגרסה המוצגת</button><select aria-label="גרסה קודמת לשחזור" data-cloud-revisions><option value="">בחר גרסה קודמת…</option></select><button type="button" data-cloud-restore>שחזור גרסה</button><button type="button" data-admin-logout>התנתקות</button><span class="owner-cloud-hint">טיוטות נשמרות ב־Firebase. החלת שינויים כאן אינה משיקה אתר שטרם פורסם.</span>';
  toolbar.append(controls);editor.status('מצב מנהל פעיל. ערוך כרטיסיות ושמור טיוטה; המבקרים רואים רק שינויים שהחלת באתר.');
  await revisions();
}
async function revisions(){
  const target=document.querySelector('[data-cloud-revisions]');if(!target)return;
  const records=await service.revisions();if(!target.isConnected)return;
  target.innerHTML='<option value="">בחר גרסה קודמת…</option>'+records.map(record=>`<option value="${escape(record.id)}">${record.revision===0?'האתר המקורי':`גרסה ${record.revision}`} — ${escape(record.createdAt?.toDate().toLocaleString('he-IL')||'')}</option>`).join('');
}
async function authChanged(next) {
  const generation=++authGeneration;editor?.dispose();editor=null;service.clear();user=next;authorized=false;authReady=false;adminFailure=null;
  let stage='role';
  if(hasPublicDisplay)updateSite(publicPayload);panel();
  try{
    if(next)authorized=await service.isOwner(next);if(generation!==authGeneration)return;
    if(authorized){stage='content';await enterEditor(generation);}if(generation!==authGeneration)return;
    authReady=true;panel();
  }catch(error){
    if(generation!==authGeneration)return;
    const detail=error.code?.includes('permission-denied')
      ?stage==='role'?'Firestore חסם את קריאת מסמך הרשאת המנהל. יש לבדוק את כללי הגישה בפרויקט ובמסד שמופיעים למטה.'
        :'הרשאת המנהל נמצאה, אך Firestore חסם את טעינת הטיוטה או ההיסטוריה. יש לבדוק את כללי הגישה בפרויקט ובמסד המתאימים.'
      :message(error);
    adminFailure={stage,detail,code:error.code||''};authorized=false;editor?.dispose();editor=null;authReady=true;updateSite(publicPayload);panel();
  }
}
document.addEventListener('nexori:render',panel);
document.addEventListener('submit',async event=>{
  if(event.target.id!=='admin-login-form')return;event.preventDefault();if(busy||!service)return;
  const form=event.target,data=new FormData(form);busy=true;form.querySelectorAll('button').forEach(button=>button.disabled=true);status('מתחבר…');
  try{await service.login(String(data.get('email')).trim(),String(data.get('password')));}catch(error){status(message(error));}
  finally{busy=false;const password=form.querySelector('[name=password]');if(password)password.value='';document.querySelectorAll('#firebase-admin-page button').forEach(button=>button.disabled=false);}
});
document.addEventListener('click',async event=>{
  if(event.target.closest('[data-admin-retry]')){location.reload();return;}
  const action=event.target.closest('[data-admin-logout],[data-admin-reset],[data-admin-verify],[data-cloud-publish],[data-cloud-restore],[data-cloud-load-public]');
  if(!action||busy||!service)return;
  if(action.hasAttribute('data-cloud-publish')&&!confirm('להחיל את הטיוטה השמורה על הגרסה שמוצגת למבקרים? שינויים שלא נשמרו בחלון עריכה אינם נכללים.'))return;
  if(action.hasAttribute('data-cloud-load-public')&&!confirm('להחליף את הטיוטה בגרסה שמוצגת כרגע למבקרים? מומלץ להוריד גיבוי קודם.'))return;
  const revisionId=document.querySelector('[data-cloud-revisions]')?.value;
  if(action.hasAttribute('data-cloud-restore')&&(!revisionId||!confirm('לשחזר את הגרסה שנבחרה באתר? הטיוטה הנוכחית תישאר כפי שהיא.')))return;
  const generation=authGeneration;busy=true;action.disabled=true;
  try{
    if(action.hasAttribute('data-admin-logout'))await service.logout();
    if(action.hasAttribute('data-admin-reset')){const email=document.querySelector('#admin-login-form [name=email]');if(!email?.reportValidity())return;await service.resetPassword(email.value.trim());status('אם הכתובת רשומה וזכאית לאיפוס, תישלח אליה הודעה.');}
    if(action.hasAttribute('data-admin-verify')){await service.verifyEmail();status('הודעת אימות נשלחה. לאחר האימות, התנתק והתחבר שוב.');}
    if(action.hasAttribute('data-cloud-publish')){const release=await service.publish();if(generation===authGeneration){await acceptRelease(release);editor?.status('השינויים השמורים הוחלו באתר ואומתו בגרסה הציבורית.');await revisions();}}
    if(action.hasAttribute('data-cloud-restore')){const release=await service.restore(revisionId);if(generation===authGeneration){await acceptRelease(release);editor?.status('הגרסה באתר שוחזרה. הטיוטה שלך נשארה ללא שינוי.');await revisions();}}
    if(action.hasAttribute('data-cloud-load-public')){const payload=await service.published();await service.save(payload);if(generation===authGeneration){updateSite(payload);editor?.refresh();editor?.status('הגרסה המוצגת נטענה ונשמרה כטיוטה חדשה.');}}
  }catch(error){if(generation===authGeneration){if(editor)editor.status(message(error));else status(message(error));}}
  finally{busy=false;if(action.isConnected)action.disabled=false;document.querySelectorAll('#firebase-admin-page button').forEach(button=>button.disabled=false);}
});
async function start(){
  panel();const config=firebaseConfiguration();if(!config){authReady=true;document.documentElement.classList.remove('nexori-public-pending');return;}
  try{
    const {createFirebaseService}=await import('./firebase-service.js');
    service=await createFirebaseService(config);
    service.subscribePublic(payload=>{
      try{validatePublic(payload);publicPayload=payload;hasPublicDisplay=true;if(!editor)updateSite(payload,true);document.documentElement.classList.remove('nexori-public-pending');}
      catch{console.error('Published content failed validation; keeping the last valid website.');}
    },error=>{console.error('Published content is unavailable.',error.code);});
    service.observeAuth(authChanged);
  }catch(error){connectionError=message(error);panel();}
}
function validatePublic(payload){
  // Validate without applying: the manager may currently be viewing a private draft.
  if(Object.values(payload.changes?.products||{}).some(patch=>Object.hasOwn(patch,'editorNotes')||Object.hasOwn(patch,'retailerUrl')))throw new Error('Private fields in public content.');
  return validateContentDraft(payload,{bucket:service.bucket});
}
import { validateContentDraft } from './content.js';
start();

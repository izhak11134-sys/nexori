const assert=require('node:assert/strict');
const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
(async()=>{
  const {products,franchises,categories,guides}=await import(pathToFileURL(path.resolve('src/data.js')));
  const {chromium}=await import(process.env.PLAYWRIGHT_MODULE||'/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright/index.mjs');
  const html=fs.readFileSync('dist/index.html');
  const server=http.createServer((req,res)=>{if(req.url!=='/'&&req.url!=='/index.html'){res.writeHead(404).end();return;}res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(html);});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const base=`http://127.0.0.1:${server.address().port}`;
  const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
  try{
    const context=await browser.newContext({viewport:{width:1440,height:1000}});
    await context.addInitScript(()=>{
      localStorage.setItem('nexori.owner-draft.v1',JSON.stringify({version:1,changes:{blocks:{hero:{image:'data:image/png;base64,b2xkLXVuY2xlYXJlZC1pbWFnZQ==',accent:'OLD CLOUD CONTENT'}}}}));
      localStorage.setItem('nexori.saved.v1','["midnight-ronin"]');
      localStorage.setItem('nexori-public-hero-v1:nexori-development','old');
    });
    const page=await context.newPage();const errors=[],external=[],imageRequests=[];
    page.on('pageerror',e=>errors.push(e.message));
    page.on('request',req=>{if(/^https?:/.test(req.url())&&!req.url().startsWith(base))external.push(req.url());if(req.resourceType()==='image'&&/^https?:/.test(req.url()))imageRequests.push(req.url());});
    async function visit(route='/',width=1440){
      await page.setViewportSize({width,height:1000});
      await page.goto(`${base}/#${route}`);await page.locator('main h1').waitFor();
      assert.equal(await page.locator('main h1').count(),1,route);
      assert.equal(await page.locator('body').innerText().then(t=>/OLD CLOUD CONTENT|Image publication permissions are pending|Authentic Anime|Owner sign-in/.test(t)),false,route);
      assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),`overflow ${width} ${route}`);
      assert.equal(await page.locator('img').evaluateAll(imgs=>imgs.every(i=>i.src.startsWith('data:image/svg+xml;base64,'))),true,route);
    }
    await visit();
    assert.equal(await page.locator('.world-card').count(),14);
    assert.deepEqual(await page.evaluate(()=>Object.keys(window.NEXORI_ART).sort()),['editorial','journal-check','journal-collect','journal-space','mark','portal','space']);
    assert.equal(await page.evaluate(()=>Boolean(window.NEXORI_CLOUD_SITE)),false);
    assert.ok(await page.locator('.cinematic-background').evaluate(i=>i.complete&&i.naturalWidth===1000));
    await page.screenshot({path:'desktop-hero.png'});
    for(const width of [320,390,768,1024,1920])await visit('/',width);
    await page.setViewportSize({width:390,height:844});await page.screenshot({path:'mobile-hero.png'});
    console.log('PASS home at six widths; original SVG art; old draft/cache cannot replace public content');
    for(const p of products){
      await visit(`/product/${p.id}`);
      assert.equal(await page.locator('.detail-info h1').innerText(),p.name);
      const link=page.locator('.retail-offer a');assert.equal(await link.getAttribute('href'),p.sourceUrl);
      const u=new URL(p.sourceUrl);assert.equal(u.hostname,'www.hottopic.com');assert.equal(u.protocol,'https:');assert.equal(u.search,'');
      assert.equal(await link.getAttribute('rel'),'noopener noreferrer');
      assert.equal(await page.locator('.detail-art img').count(),0);
    }
    for(const world of franchises){await visit(`/worlds/${world.id}`);assert.equal(await page.locator('.product-card').count(),3);}
    for(const guide of guides){await visit(`/guides/${guide.id}`);assert.ok(await page.locator('.article-body section').count()>=3);}
    for(const route of ['/worlds','/guides','/about','/disclosure','/privacy','/terms','/contact','/rights','/accessibility'])await visit(route);
    assert.equal(products.length,42);assert.equal(categories.length,4);
    console.log('PASS all 42 product details, 14 anime pages, three guides, and information pages');
    await visit('/collection');assert.equal(await page.locator('#collection-grid .product-card').count(),42);
    await page.selectOption('#collection-world','naruto');assert.equal(await page.locator('#collection-grid .product-card').count(),3);
    await page.reload();assert.equal(await page.locator('#collection-grid .product-card').count(),3);
    await page.locator('[data-reset]').click();assert.equal(await page.locator('#collection-grid .product-card').count(),42);
    await page.fill('#collection-search','luffy');await page.waitForTimeout(250);assert.ok(await page.locator('#collection-grid .product-card').count()>=1);
    await page.locator('[data-reset]').click();await page.locator('[data-category="style"]').first().click();assert.equal(await page.locator('#collection-grid .product-card').count(),17);
    await visit();await page.getByRole('button',{name:'Search collection',exact:true}).click();await page.fill('#global-search','naruto');assert.equal(await page.locator('.search-result').count(),3);await page.keyboard.press('Escape');await page.locator('#search-dialog').waitFor({state:'hidden'});assert.equal(await page.locator('#search-dialog').evaluate(d=>d.open),false);
    await visit('/saved');assert.equal(await page.locator('.product-card').count(),0);
    await visit(`/product/${products[0].id}`);await page.locator('.detail-save').click();await visit('/saved');assert.equal(await page.locator('.product-card').count(),1);
    await page.reload();assert.equal(await page.locator('.product-card').count(),1);
    await visit('/privacy');await page.locator('[data-clear-saved]').click();await visit('/saved');assert.equal(await page.locator('.product-card').count(),0);
    await visit();await page.locator('.ribbon-motion').click();await page.reload();assert.equal(await page.locator('body').evaluate(b=>b.classList.contains('motion-paused')),true);
    console.log('PASS filters, search, reloadable URLs, wishlist persistence/clear, and motion preference');
    for(const width of [320,390,768]){
      await visit('/collection',width);await visit(`/product/${products[0].id}`,width);await visit('/privacy',width);
    }
    await visit('/collection?world=one-piece',1440);await page.screenshot({path:'collection.png',fullPage:true});
    await visit('/',1440);
    for(let y=0;y<await page.evaluate(()=>document.body.scrollHeight);y+=700){await page.evaluate(y=>scrollTo(0,y),y);await page.waitForTimeout(40);}
    await page.locator('img').evaluateAll(async imgs=>{await Promise.all(imgs.map(i=>i.decode()));});await page.evaluate(()=>scrollTo(0,0));await page.screenshot({path:'desktop.png',fullPage:true});
    assert.deepEqual(errors,[]);assert.deepEqual(external,[]);assert.deepEqual(imageRequests,[]);
    console.log('PASS no runtime errors, no external requests, no merchant photo requests or Firebase; narrow-screen pages fit');
    await context.close();
  }finally{await browser.close();await new Promise(resolve=>server.close(resolve));}
})().catch(error=>{console.error(error);process.exitCode=1;});

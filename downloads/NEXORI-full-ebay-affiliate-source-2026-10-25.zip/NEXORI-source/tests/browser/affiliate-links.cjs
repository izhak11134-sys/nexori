const assert=require('node:assert/strict');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 try{
 const context=await browser.newContext({viewport:{width:1280,height:900}}),errors=[];
 await context.route(/^https?:/,r=>['127.0.0.1','localhost'].includes(new URL(r.request().url()).hostname)?r.continue():r.abort());
 await context.route('**/src/firebase-config.js*',r=>r.fulfill({contentType:'application/javascript',body:'export function firebaseConfiguration(){return null;}'}));
 const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
 const base=process.env.SITE_URL||'http://127.0.0.1:5199';
 const standalone=base.endsWith('.html');
 const navigate=async path=>{await page.goto(standalone?base+'#'+path:base+path);await page.locator('main').waitFor();};
 await navigate('/product/expand-ebay-197978173286');
 const button=page.locator('.retail-offer a.button');await button.waitFor();
 const first=new URL(await button.getAttribute('href'));
 assert.equal(first.searchParams.get('campid'),'5339230513');assert.equal(first.searchParams.get('customid'),'nexorifirstfigure');
 assert.match(await button.getAttribute('rel'),/\bsponsored\b/);assert.equal(await button.getAttribute('target'),'_blank');
 assert.match(await page.locator('.affiliate-disclosure').innerText(),/may earn a commission/);
 assert(!/affiliate acceptance remain pending|no active affiliate/i.test(await page.locator('main').innerText()));
 // Follow only in an intercepted popup: no real eBay request or self-attribution click.
 const [popup]=await Promise.all([page.waitForEvent('popup'),button.click()]);await popup.waitForLoadState('domcontentloaded').catch(()=>{});await popup.close();
 await navigate('/product/moonlight-blade');await button.waitFor();
 assert.equal(new URL(await button.getAttribute('href')).pathname,'/itm/128113612813');
 const ids=await page.evaluate(async()=>{
  if(location.pathname.endsWith('.html'))return null;
  const {products}=await import('/src/data.js');return {variation:products.find(p=>p.sourceUrl.includes('?var=')),regular:products.find(p=>p.retailer==='Hot Topic')};
 });
 if(ids){
  await navigate('/product/'+ids.variation.id);await button.waitFor();assert.equal(new URL(await button.getAttribute('href')).searchParams.get('var'),new URL(ids.variation.sourceUrl).searchParams.get('var'));
  await navigate('/product/'+ids.regular.id);await button.waitFor();assert.equal(await button.getAttribute('href'),ids.regular.sourceUrl);assert(!/sponsored/.test(await button.getAttribute('rel')));assert.equal(await page.locator('.affiliate-disclosure').count(),0);
 }
 await navigate('/disclosure');await page.getByRole('heading',{name:'Affiliate disclosure.',exact:true}).waitFor();assert.match(await page.locator('main').innerText(),/eBay Partner Network/);
 assert.deepEqual(errors,[]);
 console.log('PASS '+(standalone?'portable':'source')+': affiliate destination, sponsored rel, nearby disclosure, intercepted popup, original listing, policy'+(ids?', variation and unchanged Hot Topic':'')+'; no page errors or real external clicks.');
 await context.close();
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});

import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {products} from '../src/data.js';
import {retailerDestination,productPurchaseTips,ebayCampaign} from '../src/affiliate-links.js';

test('all 1,042 eBay products retain their item and variation with the supplied campaign; 708 Hot Topic URLs stay exact',()=>{
 const before=JSON.stringify(products),customIds=new Set();let affiliates=0,regular=0;
 for(const product of products){
  const result=retailerDestination(product),old=new URL(product.sourceUrl),url=new URL(result.url);
  assert.equal(url.pathname,old.pathname);assert.equal(url.origin,old.origin);
  for(const [key,value] of old.searchParams)assert.equal(url.searchParams.get(key),value);
  if(product.retailer==='eBay'){
   affiliates++;assert.equal(result.affiliate,true);assert.equal(url.searchParams.get('campid'),'5339230513');
   for(const [key,value] of Object.entries(ebayCampaign))assert.equal(url.searchParams.get(key),value);
   assert.equal(url.searchParams.get('customid'),result.customId);assert(!customIds.has(result.customId));customIds.add(result.customId);
   assert(!productPurchaseTips(product).some(t=>t.includes('affiliate acceptance remain pending')));
  }else{regular++;assert.equal(result.affiliate,false);assert.equal(result.url,product.sourceUrl);assert.deepEqual(productPurchaseTips(product),product.tips);}
 }
 assert.equal(affiliates,1042);assert.equal(regular,708);assert.equal(JSON.stringify(products),before);
});

test('the first All For One listing preserves the exact user-generated link',async()=>{
 const supplied=await readFile(new URL('../tests/fixtures/epn-first-link.txt',import.meta.url),'utf8');
 const product=products.find(p=>p.id==='expand-ebay-197978173286');
 assert.equal(retailerDestination(product).url,supplied.trim());
});

test('variation IDs survive and stale tracking is replaced without duplicates or another item token',()=>{
 const product={id:'test-variation',retailer:'eBay',sourceUrl:'https://www.ebay.com/itm/123456789012?var=123&campid=999&campid=888&customid=old&amdata=other-item&foo=a%26b',tips:[]};
 const url=new URL(retailerDestination(product).url);
 assert.equal(url.searchParams.get('var'),'123');assert.equal(url.searchParams.get('foo'),'a&b');
 assert.deepEqual(url.searchParams.getAll('campid'),['5339230513']);assert.equal(url.searchParams.has('amdata'),false);
 assert.equal(retailerDestination({...product,sourceUrl:url.href}).url,url.href);
});

test('lookalike hosts, credentials, non-HTTPS, unsupported markets and non-item pages are not affiliated',()=>{
 for(const sourceUrl of ['https://www.ebay.com.evil.test/itm/123456789012','https://evil-ebay.com/itm/123456789012','https://www.ebay.co.uk/itm/123456789012','https://www.ebay.com/str/store','https://www.hottopic.com/product/test.html'])assert.equal(retailerDestination({sourceUrl,retailer:'eBay',id:'test'}).affiliate,false);
 for(const sourceUrl of ['javascript:alert(1)','http://www.ebay.com/itm/123456789012','https://user:pass@www.ebay.com/itm/123456789012','broken'])assert.equal(retailerDestination({sourceUrl,retailer:'eBay',id:'test'}).url,'');
});
